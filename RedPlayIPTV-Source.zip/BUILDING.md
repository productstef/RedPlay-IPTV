# Building RedPlay IPTV 0.6.3

Requirements: Go 1.23+.

## Windows x64 application

```sh
mkdir -p dist cmd/setup/payload
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags="-H=windowsgui -s -w" -o dist/RedPlayIPTV-0.6.3.exe .
cp dist/RedPlayIPTV-0.6.3.exe cmd/setup/payload/RedPlayIPTV.exe
cp assets/RedPlayIcon.ico cmd/setup/payload/RedPlayIcon.ico
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags="-H=windowsgui -s -w" -o dist/RedPlayIPTV-Setup-0.6.3.exe ./cmd/setup
```

Before release, run:

```sh
go test ./...
go test -race ./...
go vet ./...
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go vet ./...
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go test -c -o dist/redplay-tests-windows.exe .
```

The application downloads the pinned official mpv 0.41.0 Windows x64 archive on first use and verifies its SHA-256 before extraction.
