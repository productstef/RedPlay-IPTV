package main

import (
	"context"
	"fmt"
	"net/http"
	"net/url"
	"path"
	"regexp"
	"sort"
	"strings"
	"time"
)

// LibraryMovie is an on-demand item backed by the same original file that
// participates in a linear/live channel rotation. The live channel keeps its
// existing HLS path; library playback points mpv at the original static file so
// pause/seek work naturally without affecting other viewers.
type LibraryMovie struct {
	Title         string
	DisplayTitle  string
	Year          string
	Description   string
	URL           string
	CandidateURLs []string
	SubtitleURL   string
	Duration      time.Duration
}

type ChannelLibrary struct {
	Title   string
	Channel Channel
	Movies  []LibraryMovie
}

var trailingMovieYear = regexp.MustCompile(`(?s)^\s*(.*?)\s*\((\d{4})\)\s*$`)

func splitLibraryMovieTitle(raw string) (title, year string) {
	raw = strings.TrimSpace(raw)
	if m := trailingMovieYear.FindStringSubmatch(raw); len(m) == 3 {
		return strings.TrimSpace(m[1]), m[2]
	}
	return raw, ""
}

func westernChannelFromPlaylist(pl Playlist) (Channel, bool) {
	for _, c := range pl.Channels {
		joined := strings.ToLower(strings.Join([]string{c.ID, c.Name, c.TVGID, c.TVGName, c.Group}, " "))
		if strings.Contains(joined, "western") {
			return c, true
		}
	}
	return Channel{}, false
}

func directWesternAssetURL(providerURL, fileName string) (string, error) {
	u, err := url.Parse(strings.TrimSpace(providerURL))
	if err != nil {
		return "", err
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return "", fmt.Errorf("Western library requires an HTTP/HTTPS provider URL")
	}
	if u.Host == "" {
		return "", fmt.Errorf("provider URL has no host")
	}
	// This is the layout already used by the user's Oracle/Nginx setup:
	// /var/www/html/videos/western -> http(s)://host/videos/western/...
	u.Path = path.Join("/videos/western", fileName)
	u.RawPath = ""
	u.RawQuery = ""
	u.Fragment = ""
	return u.String(), nil
}

var westernMovieExtensions = []string{".mkv", ".mp4", ".avi", ".m4v", ".mov"}

func directWesternMovieCandidates(providerURL, rawTitle string) ([]string, error) {
	out := make([]string, 0, len(westernMovieExtensions))
	for _, ext := range westernMovieExtensions {
		u, err := directWesternAssetURL(providerURL, rawTitle+ext)
		if err != nil {
			return nil, err
		}
		out = append(out, u)
	}
	return out, nil
}

// libraryAssetExists verifies a candidate without downloading the movie. Nginx
// supports HEAD, but the Range fallback also works with servers that reject HEAD.
func libraryAssetExists(ctx context.Context, rawURL string, headers map[string]string) bool {
	do := func(method string, useRange bool) bool {
		req, err := http.NewRequestWithContext(ctx, method, rawURL, nil)
		if err != nil {
			return false
		}
		req.Header.Set("Accept", "*/*")
		for k, v := range safeHeaders(headers) {
			req.Header.Set(k, v)
		}
		if req.Header.Get("User-Agent") == "" {
			req.Header.Set("User-Agent", "RedPlay-IPTV/0.6.7")
		}
		if useRange {
			req.Header.Set("Range", "bytes=0-0")
		}
		resp, err := netClient.Do(req)
		if err != nil {
			return false
		}
		resp.Body.Close()
		return resp.StatusCode >= 200 && resp.StatusCode < 300
	}

	if do(http.MethodHead, false) {
		return true
	}
	return do(http.MethodGet, true)
}

func resolveLibraryMovieURL(ctx context.Context, movie LibraryMovie, headers map[string]string) (string, error) {
	candidates := movie.CandidateURLs
	if len(candidates) == 0 && strings.TrimSpace(movie.URL) != "" {
		candidates = []string{movie.URL}
	}
	if len(candidates) == 0 {
		return "", fmt.Errorf("no media URL candidates for %s", movie.DisplayTitle)
	}

	probeCtx, cancel := context.WithTimeout(ctx, 12*time.Second)
	defer cancel()
	for _, candidate := range candidates {
		if libraryAssetExists(probeCtx, candidate, headers) {
			return candidate, nil
		}
		if probeCtx.Err() != nil {
			break
		}
	}
	return "", fmt.Errorf("movie file was not found on the server (tried MKV, MP4, AVI, M4V and MOV)")
}

// BuildWesternLibrary turns the existing XMLTV schedule into an on-demand
// catalogue. The Western EPG is generated from the original filenames, so the
// programme title (for example "Day of Anger (1967)") maps directly back to
// "Day of Anger (1967).mkv" and its matching .srt file.
func BuildWesternLibrary(provider Provider, pl Playlist, epg EPGData) (ChannelLibrary, error) {
	ch, ok := westernChannelFromPlaylist(pl)
	if !ok {
		return ChannelLibrary{}, fmt.Errorf("Western Channel was not found in the current provider")
	}
	id := matchEPGChannel(ch, epg)
	if id == "" {
		return ChannelLibrary{}, fmt.Errorf("Western Channel TV guide is not loaded yet")
	}
	programmes := epg.Programmes[id]
	if len(programmes) == 0 {
		return ChannelLibrary{}, fmt.Errorf("Western Channel TV guide contains no movies")
	}

	seen := make(map[string]bool)
	movies := make([]LibraryMovie, 0, 24)
	for _, p := range programmes {
		rawTitle := strings.TrimSpace(p.Title)
		if rawTitle == "" {
			continue
		}
		key := strings.ToLower(rawTitle)
		if seen[key] {
			continue
		}
		seen[key] = true

		candidates, err := directWesternMovieCandidates(provider.URL, rawTitle)
		if err != nil {
			return ChannelLibrary{}, err
		}
		videoURL := candidates[0]
		subURL, _ := directWesternAssetURL(provider.URL, rawTitle+".srt")
		title, year := splitLibraryMovieTitle(rawTitle)
		dur := p.Stop.Sub(p.Start)
		if dur < 0 {
			dur = 0
		}
		desc := strings.TrimSpace(p.Desc)
		if desc == "" {
			desc = "Available on demand from the Western Channel library."
		}
		movies = append(movies, LibraryMovie{
			Title:         rawTitle,
			DisplayTitle:  title,
			Year:          year,
			Description:   desc,
			URL:           videoURL,
			CandidateURLs: candidates,
			SubtitleURL:   subURL,
			Duration:      dur,
		})
	}
	if len(movies) == 0 {
		return ChannelLibrary{}, fmt.Errorf("Western Channel TV guide contains no usable movie titles")
	}

	// A library is easier to browse alphabetically than in the current 24/7
	// rotation order. The live channel itself remains completely unchanged.
	sort.SliceStable(movies, func(i, j int) bool {
		a := strings.ToLower(movies[i].DisplayTitle)
		b := strings.ToLower(movies[j].DisplayTitle)
		if a == b {
			return movies[i].Year < movies[j].Year
		}
		return a < b
	})

	return ChannelLibrary{
		Title:   "Western Channel Library",
		Channel: ch,
		Movies:  movies,
	}, nil
}

func formatLibraryDuration(d time.Duration) string {
	if d <= 0 {
		return ""
	}
	mins := int(d.Round(time.Minute) / time.Minute)
	if mins < 1 {
		mins = 1
	}
	return fmt.Sprintf("%d min", mins)
}
