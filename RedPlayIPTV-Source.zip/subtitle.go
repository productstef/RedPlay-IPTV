package main

import (
	"context"
	"strings"
)

func parseHLSAttrs(s string) map[string]string {
	out := map[string]string{}
	if i := strings.Index(s, ":"); i >= 0 {
		s = s[i+1:]
	}
	var parts []string
	start := 0
	quote := byte(0)
	for i := 0; i < len(s); i++ {
		c := s[i]
		if quote != 0 {
			if c == quote {
				quote = 0
			}
			continue
		}
		if c == '"' || c == '\'' {
			quote = c
			continue
		}
		if c == ',' {
			parts = append(parts, s[start:i])
			start = i + 1
		}
	}
	parts = append(parts, s[start:])
	for _, part := range parts {
		if i := strings.Index(part, "="); i > 0 {
			k := strings.ToLower(strings.TrimSpace(part[:i]))
			v := strings.TrimSpace(part[i+1:])
			v = strings.Trim(v, "\"'")
			out[k] = v
		}
	}
	return out
}

type HLSSubtitle struct {
	Name    string
	Lang    string
	URL     string
	Default bool
	Forced  bool
}

func ParseHLSSubtitleRenditions(text, baseURL string) []HLSSubtitle {
	var out []HLSSubtitle
	for _, raw := range strings.Split(strings.ReplaceAll(text, "\r\n", "\n"), "\n") {
		line := strings.TrimSpace(raw)
		if !strings.HasPrefix(strings.ToUpper(line), "#EXT-X-MEDIA:") {
			continue
		}
		attrs := parseHLSAttrs(line)
		if !strings.EqualFold(attrs["type"], "SUBTITLES") {
			continue
		}
		uri := strings.TrimSpace(attrs["uri"])
		if uri == "" {
			continue
		}
		out = append(out, HLSSubtitle{
			Name: attrs["name"], Lang: attrs["language"], URL: resolveURL(baseURL, uri),
			Default: strings.EqualFold(attrs["default"], "YES"), Forced: strings.EqualFold(attrs["forced"], "YES"),
		})
	}
	return out
}

func DiscoverHLSSubtitles(ctx context.Context, streamURL string, headers map[string]string) []HLSSubtitle {
	low := strings.ToLower(streamURL)
	if !strings.Contains(low, ".m3u8") {
		return nil
	}
	text, err := FetchText(ctx, streamURL, headers, 4<<20)
	if err != nil || !strings.Contains(strings.ToUpper(text), "#EXT-X-MEDIA") {
		return nil
	}
	return ParseHLSSubtitleRenditions(text, streamURL)
}

func isBulgarianLang(s string) bool {
	s = strings.ToLower(strings.TrimSpace(s))
	return s == "bg" || s == "bul" || s == "bgr" || strings.HasPrefix(s, "bg-") || strings.Contains(s, "bulgar")
}

func isEnglishLang(s string) bool {
	s = strings.ToLower(strings.TrimSpace(s))
	return s == "en" || s == "eng" || strings.HasPrefix(s, "en-") || strings.Contains(s, "english")
}
