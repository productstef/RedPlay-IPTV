package main

import (
	"bytes"
	"compress/gzip"
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestFetchPlaylistHeaders(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Referer") != "http://portal/" {
			t.Errorf("referer %q", r.Header.Get("Referer"))
		}
		w.Write([]byte("#EXTM3U\n"))
	}))
	defer srv.Close()
	_, e := FetchText(context.Background(), srv.URL, map[string]string{"Referer": "http://portal/"}, 1024)
	if e != nil {
		t.Fatal(e)
	}
}

func TestOpenURLRawGzip(t *testing.T) {
	var payload bytes.Buffer
	gz := gzip.NewWriter(&payload)
	_, _ = gz.Write([]byte("<tv></tv>"))
	_ = gz.Close()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/gzip")
		_, _ = w.Write(payload.Bytes())
	}))
	defer srv.Close()
	body, err := OpenURL(context.Background(), srv.URL+"/epg.xml.gz", nil)
	if err != nil {
		t.Fatal(err)
	}
	defer body.Close()
	b, err := io.ReadAll(body)
	if err != nil {
		t.Fatal(err)
	}
	if string(b) != "<tv></tv>" {
		t.Fatalf("got %q", b)
	}
}
