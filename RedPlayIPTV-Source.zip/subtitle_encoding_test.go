package main

import "testing"

func TestNormalizeSubtitleTextUTF8(t *testing.T) {
	want := "Здравей, свят!"
	if got := normalizeSubtitleText([]byte(want)); got != want {
		t.Fatalf("utf8 subtitle = %q, want %q", got, want)
	}
}

func TestNormalizeSubtitleTextUTF8BOM(t *testing.T) {
	want := "Български субтитри"
	raw := append([]byte{0xef, 0xbb, 0xbf}, []byte(want)...)
	if got := normalizeSubtitleText(raw); got != want {
		t.Fatalf("utf8 bom subtitle = %q, want %q", got, want)
	}
}

func TestNormalizeSubtitleTextWindows1251(t *testing.T) {
	// "Български" in Windows-1251.
	raw := []byte{0xc1, 0xfa, 0xeb, 0xe3, 0xe0, 0xf0, 0xf1, 0xea, 0xe8}
	if got, want := normalizeSubtitleText(raw), "Български"; got != want {
		t.Fatalf("cp1251 subtitle = %q, want %q", got, want)
	}
}
