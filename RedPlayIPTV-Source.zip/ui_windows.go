//go:build windows

package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

const (
	idProviderCombo   = 1001
	idAddProvider     = 1002
	idRefreshProvider = 1003
	idDeleteProvider  = 1004
	idEditProvider    = 1005
	idGroupCombo      = 1010
	idSearch          = 1011
	idFavoritesOnly   = 1012
	idChannelList     = 1020
	idPlay            = 1030
	idPause           = 1031
	idMute            = 1032
	idVolDown         = 1033
	idVolUp           = 1034
	idAudioCombo      = 1035
	idSubCombo        = 1036
	idFavorite        = 1037
	idFullEPG         = 1038
	idDiagnostics     = 1039
	idFullscreen      = 1040
	idLibrary         = 1043
	idSubSizeDown     = 1041
	idSubSizeUp       = 1042
	idAddName         = 1050
	idAddURL          = 1051
	idAddEPG          = 1052
	idAddSave         = 1053
	idAddCancel       = 1054
	idAddUserAgent    = 1055
	idAddReferer      = 1056
	idCheckUpdate     = 1057

	msgProviderDone = WM_APP + 1
	msgEPGDone      = WM_APP + 2
	msgStatus       = WM_APP + 3
	msgTracksDone   = WM_APP + 4
	msgPlayerError  = WM_APP + 5
	msgEngineDone   = WM_APP + 6
	msgDiagnostics  = WM_APP + 7
	msgFilterDone   = WM_APP + 8
	msgFilterBatch  = WM_APP + 9
	msgHeartbeat    = WM_APP + 10
	msgUpdateCheck  = WM_APP + 11
	msgUpdateDone   = WM_APP + 12
	msgLibrarySeek  = WM_APP + 13
)

type asyncLoadResult struct {
	gen      int64
	provider Provider
	playlist Playlist
	err      error
}
type asyncEPGResult struct {
	gen  int64
	data EPGData
	err  error
	url  string
}
type asyncTracksResult struct {
	gen    int64
	tracks []MPVTrack
	err    error
}
type asyncFilterResult struct {
	gen   int64
	items []channelListItem
}
type asyncUpdateResult struct {
	info updateInfo
	err  error
}
type asyncLibrarySeekResult struct {
	gen      int64
	position float64
	duration float64
}

type App struct {
	hwnd      uintptr
	ctx       context.Context
	cancel    context.CancelFunc
	state     AppState
	player    *MPVPlayer
	engineExe string

	bgBrush, panelBrush, fieldBrush, accentBrush, cardBrush, providerCardBrush, topBrush uintptr
	fontBrand, fontSection, fontBody, fontSmall, fontButton                              uintptr
	fontProviderTitle, fontProviderSubtitle, fontProviderLabel, fontProviderDrop         uintptr

	providerCombo, addProviderBtn, editProviderBtn, refreshProviderBtn, deleteProviderBtn                                           uintptr
	groupCombo, searchEdit, favOnlyCheck, channelList                                                                               uintptr
	videoHost                                                                                                                       uintptr
	playBtn, pauseBtn, muteBtn, volDownBtn, volUpBtn, audioCombo, subCombo, favoriteBtn, epgBtn, diagBtn, fullscreenBtn, libraryBtn uintptr
	subSizeDownBtn, subSizeUpBtn                                                                                                    uintptr
	channelLabel, nowLabel, nextLabel, statusLabel, volumeLabel, subSizeValue                                                       uintptr

	brandLabel, brandPlayLabel, brandIPTVLabel, sidebarNote, providerTitle, providerMetaLabel, searchTitle, categoryTitle, channelsTitle uintptr
	tvGuideTab, channelInfoTab, settingsTab, guideNowLabel, audioTitle, subtitleTitle, subSizeTitle, subSizeHint, streamTitle            uintptr
	streamInfoLabel, statusTitle, currentCardTitle, nextCardTitle, navHomeBtn, navLiveBtn, navMoviesBtn, navSettingsBtn                  uintptr
	versionLabel, updateBtn                                                                                                              uintptr

	providerDialogHwnd                                                                                                                                                     uintptr
	formTitle, formSubtitle, formNameLabel, formNameEdit, formURLLabel, formURLEdit, formEPGLabel, formEPGEdit, formUALabel, formUAEdit, formRefererLabel, formRefererEdit uintptr
	formSave, formCancel, formChooseFile, formClose                                                                                                                        uintptr
	formSelectedFile, formPreservedEPG                                                                                                                                     string
	formPreservedHeaders                                                                                                                                                   map[string]string

	libraryHwnd             uintptr
	libraryPlayBtn          uintptr
	libraryData             ChannelLibrary
	librarySelected         int
	libraryScrollRows       int
	libraryPlaying          *LibraryMovie
	librarySeekHwnd         uintptr
	librarySeekPos          float64
	librarySeekDuration     float64
	librarySeekDragging     bool
	librarySeekDragPos      float64
	librarySeekVisible      bool
	librarySeekHaveMouse    bool
	librarySeekLastMouse    POINT
	librarySeekLastActivity time.Time

	mu                 sync.Mutex
	status             string
	pendingLoad        asyncLoadResult
	pendingEPG         asyncEPGResult
	pendingTracks      asyncTracksResult
	pendingPlayerErr   string
	pendingDiagnostics string
	pendingFilter      asyncFilterResult
	pendingUpdate      asyncUpdateResult
	pendingUpdateErr   string
	pendingLibrarySeek asyncLibrarySeekResult

	loadGen        int64
	epgGen         int64
	playGen        int64
	providerCancel context.CancelFunc
	epgCancel      context.CancelFunc
	playCancel     context.CancelFunc

	currentProvider  int
	editingProvider  int
	providerFormOpen bool
	playlist         Playlist
	epg              EPGData
	epgURL           string
	filtered         []int
	currentChannel   int
	audioTracks      []MPVTrack
	subTracks        []MPVTrack

	// UI responsiveness: playback IPC never runs on the Win32 message thread.
	playerActionSem  chan struct{}
	audioActionGen   int64
	subActionGen     int64
	subSizeActionGen int64
	volumeActionGen  int64
	seekActionGen    int64
	saveGen          int64
	filterGen        int64
	filterLabels     []string
	filterBatchPos   int
	filterDisplayGen int64
	lastUIHeartbeat  int64

	fullscreen    bool
	windowedRect  RECT
	windowedStyle uintptr
}

var gApp *App
var epgWindowEdits = struct {
	sync.Mutex
	m map[uintptr]uintptr
}{m: map[uintptr]uintptr{}}

func (a *App) setStatusAsync(s string) {
	a.mu.Lock()
	a.status = s
	a.mu.Unlock()
	if a.hwnd != 0 {
		post(a.hwnd, msgStatus, 0, 0)
	}
}
func (a *App) setPlayerErrorAsync(s string) {
	a.mu.Lock()
	a.pendingPlayerErr = s
	a.mu.Unlock()
	if a.hwnd != 0 {
		post(a.hwnd, msgPlayerError, 0, 0)
	}
}

func (a *App) getEngineExe() string {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.engineExe
}

func (a *App) setEngineExe(exe string) {
	a.mu.Lock()
	a.engineExe = exe
	a.mu.Unlock()
}

func (a *App) applyFonts() {
	setFont(a.brandLabel, a.fontBrand)
	setFont(a.brandPlayLabel, a.fontBrand)
	setFont(a.brandIPTVLabel, a.fontBrand)
	for _, h := range []uintptr{a.providerTitle, a.searchTitle, a.categoryTitle, a.channelsTitle, a.currentCardTitle, a.nextCardTitle, a.audioTitle, a.subtitleTitle, a.streamTitle, a.statusTitle, a.tvGuideTab, a.channelInfoTab, a.settingsTab} {
		setFont(h, a.fontSection)
	}
	for _, h := range []uintptr{a.providerMetaLabel, a.channelLabel, a.nowLabel, a.nextLabel, a.guideNowLabel, a.streamInfoLabel, a.statusLabel, a.sidebarNote, a.volumeLabel, a.subSizeTitle, a.subSizeValue, a.versionLabel} {
		setFont(h, a.fontBody)
	}
	setFont(a.subSizeHint, a.fontSmall)
	for _, h := range []uintptr{a.formTitle, a.formNameLabel, a.formURLLabel, a.formEPGLabel, a.formUALabel, a.formRefererLabel} {
		setFont(h, a.fontSection)
	}
	for _, h := range []uintptr{a.navHomeBtn, a.navLiveBtn, a.navMoviesBtn, a.navSettingsBtn, a.addProviderBtn, a.editProviderBtn, a.refreshProviderBtn, a.deleteProviderBtn, a.playBtn, a.pauseBtn, a.muteBtn, a.volDownBtn, a.volUpBtn, a.favoriteBtn, a.epgBtn, a.diagBtn, a.fullscreenBtn, a.libraryBtn, a.subSizeDownBtn, a.subSizeUpBtn, a.formSave, a.formCancel, a.updateBtn} {
		setFont(h, a.fontButton)
	}
}

type uiMetrics struct {
	margin, topBarH, navW, leftW, rightW, gap        int
	contentTop, leftX, playerX, playerW, rightX      int
	playerY, videoH, controlY, cardY, cardGap, cardW int
	showNav, showRight, compactControls              bool
}

func calcUIMetrics(w, h int) uiMetrics {
	m := uiMetrics{margin: 12, topBarH: 58, gap: 12}

	// Breakpoints are intentionally conservative: the player gets priority,
	// then the channel browser, while decorative navigation and the detailed
	// info rail collapse first on smaller windows.
	m.showNav = false
	m.showRight = w >= 1120

	if m.showNav {
		m.navW = maxInt(112, minInt(142, w/11))
	}
	if w >= 1400 {
		m.leftW = maxInt(262, minInt(294, w/5))
	} else if w >= 980 {
		m.leftW = 252
	} else if w >= 780 {
		m.leftW = 226
	} else {
		m.leftW = 202
	}
	if m.showRight {
		m.rightW = maxInt(274, minInt(326, w/4))
	}

	m.contentTop = m.topBarH + 12
	m.leftX = m.margin
	if m.showNav {
		m.leftX += m.navW + m.gap
	}
	m.playerX = m.leftX + m.leftW + m.gap
	if m.showRight {
		m.rightX = w - m.margin - m.rightW
	} else {
		m.rightX = w - m.margin
	}
	m.playerW = m.rightX - m.playerX - m.gap
	if m.playerW < 390 {
		// Last-resort compression for very narrow windows. We never make the
		// channel browser unusably tiny, but hand additional width to video.
		need := 390 - m.playerW
		shrink := minInt(need, maxInt(0, m.leftW-180))
		m.leftW -= shrink
		m.playerX -= shrink
		m.playerW += shrink
	}
	m.compactControls = m.playerW < 650

	m.playerY = m.contentTop + 28
	bottomReserve := 250
	if !m.showRight {
		// Audio/subtitle selectors move below the transport controls.
		bottomReserve = 330
	}
	m.videoH = int(float64(m.playerW) * 9.0 / 16.0)
	maxVideoH := h - m.playerY - bottomReserve
	if m.videoH > maxVideoH {
		m.videoH = maxVideoH
	}
	minVideoH := 270
	if h < 760 {
		minVideoH = 220
	}
	if m.videoH < minVideoH {
		m.videoH = minVideoH
	}
	m.controlY = m.playerY + m.videoH + 10
	if m.showRight {
		m.cardY = m.controlY + 44
	} else {
		m.cardY = m.controlY + 112
	}
	m.cardGap = 12
	m.cardW = (m.playerW - m.cardGap) / 2
	return m
}

func (a *App) paintChrome(hwnd uintptr) {
	var ps PAINTSTRUCT
	hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	defer procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))

	var rc RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	w, h := int(rc.Right-rc.Left), int(rc.Bottom-rc.Top)
	m := calcUIMetrics(w, h)

	fillSolid(hdc, rc, rgb(7, 11, 17))
	if a.fullscreen {
		return
	}

	// Top chrome, side rails and content surfaces.
	drawRoundRect(hdc, RECT{Left: 6, Top: 6, Right: int32(w - 6), Bottom: int32(m.topBarH)}, rgb(10, 16, 24), rgb(23, 31, 42), 18)
	if m.showNav {
		drawRoundRect(hdc, RECT{Left: int32(m.margin - 5), Top: int32(m.contentTop - 7), Right: int32(m.margin + m.navW + 5), Bottom: int32(h - m.margin)}, rgb(10, 15, 23), rgb(23, 31, 42), 20)
	}
	drawRoundRect(hdc, RECT{Left: int32(m.leftX - 5), Top: int32(m.contentTop - 7), Right: int32(m.leftX + m.leftW + 5), Bottom: int32(h - m.margin)}, rgb(10, 15, 23), rgb(23, 31, 42), 20)
	drawRoundRect(hdc, RECT{Left: int32(m.playerX - 5), Top: int32(m.contentTop - 7), Right: int32(m.playerX + m.playerW + 5), Bottom: int32(h - m.margin)}, rgb(10, 15, 23), rgb(23, 31, 42), 20)
	if m.showRight {
		drawRoundRect(hdc, RECT{Left: int32(m.rightX - 5), Top: int32(m.contentTop - 7), Right: int32(m.rightX + m.rightW + 5), Bottom: int32(h - m.margin)}, rgb(10, 15, 23), rgb(23, 31, 42), 20)
	}

	// Brand play mark.
	fillSolid(hdc, RECT{Left: int32(m.margin + 7), Top: 20, Right: int32(m.margin + 11), Bottom: 43}, rgb(255, 59, 72))
	fillSolid(hdc, RECT{Left: int32(m.margin + 11), Top: 23, Right: int32(m.margin + 15), Bottom: 40}, rgb(255, 59, 72))
	fillSolid(hdc, RECT{Left: int32(m.margin + 15), Top: 27, Right: int32(m.margin + 19), Bottom: 36}, rgb(255, 59, 72))

	// Search shell.
	searchX := m.playerX
	searchW := minInt(m.playerW, 620)
	drawRoundRect(hdc, RECT{Left: int32(searchX - 7), Top: 13, Right: int32(searchX + searchW + 7), Bottom: 52}, rgb(15, 22, 32), rgb(41, 52, 66), 16)

	// Search icon and provider card.
	if a.fontSection != 0 {
		procSelectObject.Call(hdc, a.fontSection)
	}
	drawTextRect(hdc, RECT{Left: int32(searchX + 5), Top: 18, Right: int32(searchX + 25), Bottom: 45}, "⌕", rgb(150, 164, 180), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)

	// Provider card and action shelf.
	drawRoundRect(hdc, RECT{Left: int32(m.leftX + 7), Top: int32(m.contentTop + 31), Right: int32(m.leftX + m.leftW - 7), Bottom: int32(m.contentTop + 101)}, rgb(14, 21, 30), rgb(35, 47, 61), 16)
	providerInitial := "TV"
	if a.currentProvider >= 0 && a.currentProvider < len(a.state.Providers) {
		r := []rune(strings.TrimSpace(a.state.Providers[a.currentProvider].Name))
		if len(r) > 0 {
			providerInitial = strings.ToUpper(string(r[0]))
		}
	}
	providerBadge := RECT{Left: int32(m.leftX + 15), Top: int32(m.contentTop + 40), Right: int32(m.leftX + 45), Bottom: int32(m.contentTop + 70)}
	drawRoundRect(hdc, providerBadge, rgb(22, 71, 98), rgb(39, 88, 114), 15)
	if a.fontSection != 0 {
		procSelectObject.Call(hdc, a.fontSection)
	}
	drawTextRect(hdc, providerBadge, providerInitial, rgb(235, 242, 247), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)

	// Video frame and lower cards.
	drawRoundRect(hdc, RECT{Left: int32(m.playerX - 2), Top: int32(m.playerY - 2), Right: int32(m.playerX + m.playerW + 2), Bottom: int32(m.playerY + m.videoH + 2)}, rgb(4, 6, 9), rgb(32, 43, 55), 18)
	if a.currentChannel >= 0 && a.currentChannel < len(a.playlist.Channels) && strings.Contains(strings.ToUpper(a.playlist.Channels[a.currentChannel].Name), "HD") {
		hd := RECT{Left: int32(m.playerX + m.playerW - 40), Top: int32(m.contentTop + 3), Right: int32(m.playerX + m.playerW - 7), Bottom: int32(m.contentTop + 24)}
		drawRoundRect(hdc, hd, rgb(18, 24, 33), rgb(105, 119, 135), 7)
		if a.fontSmall != 0 {
			procSelectObject.Call(hdc, a.fontSmall)
		}
		drawTextRect(hdc, hd, "HD", rgb(239, 243, 247), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
	}
	drawRoundRect(hdc, RECT{Left: int32(m.playerX), Top: int32(m.cardY), Right: int32(m.playerX + m.cardW), Bottom: int32(h - m.margin - 2)}, rgb(13, 20, 29), rgb(29, 39, 52), 16)
	drawRoundRect(hdc, RECT{Left: int32(m.playerX + m.cardW + m.cardGap), Top: int32(m.cardY), Right: int32(m.playerX + 2*m.cardW + m.cardGap), Bottom: int32(h - m.margin - 2)}, rgb(13, 20, 29), rgb(29, 39, 52), 16)

	// Programme/channel thumbnails. The app deliberately avoids downloading artwork on
	// the UI thread; these branded tiles use the already-loaded channel metadata.
	badgeText := "TV"
	if a.currentChannel >= 0 && a.currentChannel < len(a.playlist.Channels) {
		name := strings.TrimSpace(a.playlist.Channels[a.currentChannel].Name)
		r := []rune(name)
		if len(r) > 0 {
			if len(r) > 4 {
				r = r[:4]
			}
			badgeText = strings.ToUpper(string(r))
		}
	}
	thumbs := []RECT{}
	if m.cardW >= 260 {
		thumbs = append(thumbs,
			RECT{Left: int32(m.playerX + 16), Top: int32(m.cardY + 45), Right: int32(m.playerX + 108), Bottom: int32(m.cardY + 119)},
			RECT{Left: int32(m.playerX + m.cardW + m.cardGap + 16), Top: int32(m.cardY + 45), Right: int32(m.playerX + m.cardW + m.cardGap + 108), Bottom: int32(m.cardY + 119)},
		)
	}
	if m.showRight {
		thumbs = append(thumbs, RECT{Left: int32(m.rightX + 5), Top: int32(m.contentTop + 42), Right: int32(m.rightX + 92), Bottom: int32(m.contentTop + 126)})
	}
	for _, tr := range thumbs {
		drawRoundRect(hdc, tr, rgb(24, 43, 62), rgb(45, 61, 78), 14)
		if a.fontSection != 0 {
			procSelectObject.Call(hdc, a.fontSection)
		}
		drawTextRect(hdc, tr, badgeText, rgb(233, 241, 247), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
	}

	// Right information sections.
	if m.showRight {
		fillSolid(hdc, RECT{Left: int32(m.rightX), Top: int32(m.contentTop + 27), Right: int32(m.rightX + 88), Bottom: int32(m.contentTop + 30)}, rgb(255, 59, 72))
		fillSolid(hdc, RECT{Left: int32(m.rightX), Top: int32(m.contentTop + 178), Right: int32(m.rightX + m.rightW), Bottom: int32(m.contentTop + 179)}, rgb(30, 40, 52))
		fillSolid(hdc, RECT{Left: int32(m.rightX), Top: int32(m.contentTop + 428), Right: int32(m.rightX + m.rightW), Bottom: int32(m.contentTop + 429)}, rgb(30, 40, 52))
		drawRoundRect(hdc, RECT{Left: int32(m.rightX + 2), Top: int32(m.contentTop + 501), Right: int32(m.rightX + 16), Bottom: int32(m.contentTop + 515)}, rgb(53, 224, 141), rgb(53, 224, 141), 8)
	}
	// Now-playing accent.
	fillSolid(hdc, RECT{Left: int32(m.playerX + 13), Top: int32(m.cardY + 12), Right: int32(m.playerX + 17), Bottom: int32(m.cardY + 34)}, rgb(255, 59, 72))

	// EPG progress and programme badges use only the existing EPG data.
	if a.currentChannel >= 0 && a.currentChannel < len(a.playlist.Channels) {
		cur, nxt := nowNextFor(a.playlist.Channels[a.currentChannel], a.epg, time.Now())
		if cur != nil && cur.Stop.After(cur.Start) {
			progress := float64(time.Since(cur.Start)) / float64(cur.Stop.Sub(cur.Start))
			if progress < 0 {
				progress = 0
			}
			if progress > 1 {
				progress = 1
			}
			barLeft := m.playerX + 126
			if m.cardW < 260 {
				barLeft = m.playerX + 18
			}
			barRight := m.playerX + m.cardW - 18
			barY := m.cardY + 77
			fillSolid(hdc, RECT{Left: int32(barLeft), Top: int32(barY), Right: int32(barRight), Bottom: int32(barY + 4)}, rgb(49, 61, 76))
			fillSolid(hdc, RECT{Left: int32(barLeft), Top: int32(barY), Right: int32(barLeft + int(float64(barRight-barLeft)*progress)), Bottom: int32(barY + 4)}, rgb(255, 59, 72))
			if m.showRight {
				// mirrored progress in the TV Guide panel
				rbL, rbR, rbY := m.rightX+104, m.rightX+m.rightW-12, m.contentTop+146
				fillSolid(hdc, RECT{Left: int32(rbL), Top: int32(rbY), Right: int32(rbR), Bottom: int32(rbY + 4)}, rgb(49, 61, 76))
				fillSolid(hdc, RECT{Left: int32(rbL), Top: int32(rbY), Right: int32(rbL + int(float64(rbR-rbL)*progress)), Bottom: int32(rbY + 4)}, rgb(255, 59, 72))
			}
		}

		// Small category pills at the bottom of Now / Up Next cards.
		pillY := h - m.margin - 36
		drawPill := func(x int, label string) {
			label = strings.TrimSpace(label)
			if label == "" {
				return
			}
			if len([]rune(label)) > 16 {
				label = string([]rune(label)[:16])
			}
			pw := 18 + len([]rune(label))*7
			if pw > 112 {
				pw = 112
			}
			pr := RECT{Left: int32(x), Top: int32(pillY), Right: int32(x + pw), Bottom: int32(pillY + 26)}
			drawRoundRect(hdc, pr, rgb(22, 31, 42), rgb(38, 49, 63), 13)
			if a.fontSmall != 0 {
				procSelectObject.Call(hdc, a.fontSmall)
			}
			drawTextRect(hdc, pr, label, rgb(190, 201, 213), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)
		}
		if cur != nil {
			drawPill(m.playerX+16, firstNonEmpty(cur.Category, "Live"))
		}
		if nxt != nil {
			drawPill(m.playerX+m.cardW+m.cardGap+16, firstNonEmpty(nxt.Category, "Up Next"))
		}
	}

}

func (a *App) drawCustomButton(lParam uintptr) uintptr {
	if lParam == 0 {
		return 0
	}
	var dis DRAWITEMSTRUCT
	procRtlMoveMemory.Call(uintptr(unsafe.Pointer(&dis)), lParam, unsafe.Sizeof(dis))
	if dis.HwndItem == a.channelList {
		return a.drawChannelRow(&dis)
	}
	rc := dis.RcItem
	bg := rgb(19, 25, 34)
	border := rgb(38, 48, 60)
	textColor := rgb(236, 241, 246)
	radius := 14
	selected := (dis.ItemState & ODS_SELECTED) != 0

	switch dis.HwndItem {
	case a.navLiveBtn:
		bg, border = rgb(55, 20, 29), rgb(255, 59, 72)
	case a.navHomeBtn, a.navMoviesBtn, a.navSettingsBtn:
		bg, border = rgb(12, 18, 26), rgb(20, 28, 38)
	case a.addProviderBtn, a.playBtn, a.formSave, a.formChooseFile, a.libraryPlayBtn:
		bg, border = rgb(255, 59, 72), rgb(255, 59, 72)
	case a.libraryBtn:
		bg, border = rgb(16, 22, 31), rgb(255, 59, 72)
	case a.formClose:
		bg, border, textColor, radius = rgb(10, 17, 25), rgb(10, 17, 25), rgb(153, 170, 190), 8
	case a.favoriteBtn:
		bg, border = rgb(16, 22, 31), rgb(255, 59, 72)
	case a.formCancel:
		bg, border = rgb(13, 18, 25), rgb(38, 48, 60)
	default:
		bg, border = rgb(18, 24, 33), rgb(37, 47, 60)
	}
	if selected {
		bg = rgb(30, 36, 46)
		if dis.HwndItem == a.addProviderBtn || dis.HwndItem == a.playBtn || dis.HwndItem == a.formSave || dis.HwndItem == a.formChooseFile || dis.HwndItem == a.libraryPlayBtn || dis.HwndItem == a.navLiveBtn {
			bg = rgb(214, 47, 60)
		}
	}
	drawRoundRect(dis.HDC, rc, bg, border, radius)
	if dis.HwndItem == a.formClose && a.fontProviderTitle != 0 {
		procSelectObject.Call(dis.HDC, a.fontProviderTitle)
	} else if a.fontButton != 0 {
		procSelectObject.Call(dis.HDC, a.fontButton)
	}
	textRc := RECT{Left: rc.Left + 4, Top: rc.Top, Right: rc.Right - 4, Bottom: rc.Bottom}
	drawTextRect(dis.HDC, textRc, getText(dis.HwndItem), textColor, DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)
	return 1
}

func (a *App) drawChannelRow(dis *DRAWITEMSTRUCT) uintptr {
	if dis == nil || dis.ItemID == ^uint32(0) {
		return 1
	}
	rc := dis.RcItem
	selected := (dis.ItemState & ODS_SELECTED) != 0
	rowBg := rgb(12, 18, 26)
	border := rgb(12, 18, 26)
	if selected {
		rowBg = rgb(24, 30, 40)
		border = rgb(255, 59, 72)
	}
	row := RECT{Left: rc.Left + 3, Top: rc.Top + 2, Right: rc.Right - 5, Bottom: rc.Bottom - 2}
	drawRoundRect(dis.HDC, row, rowBg, border, 12)

	idx := int(dis.ItemID)
	channelIdx := -1
	if idx >= 0 && idx < len(a.filtered) {
		channelIdx = a.filtered[idx]
	}
	name := listBoxText(a.channelList, idx)
	group := ""
	favorite := false
	if channelIdx >= 0 && channelIdx < len(a.playlist.Channels) {
		c := a.playlist.Channels[channelIdx]
		name = c.Name
		group = strings.TrimSpace(c.Group)
		favorite = a.favoriteSet()[channelKey(c)]
	}
	if group == "" {
		group = "Live TV"
	}

	// Row number.
	if a.fontSmall != 0 {
		procSelectObject.Call(dis.HDC, a.fontSmall)
	}
	numberRc := RECT{Left: row.Left + 8, Top: row.Top, Right: row.Left + 34, Bottom: row.Bottom}
	drawTextRect(dis.HDC, numberRc, strconv.Itoa(idx+1), rgb(152, 164, 177), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)

	// Lightweight logo badge derived from the channel name (no network/image work on UI thread).
	badge := RECT{Left: row.Left + 38, Top: row.Top + 6, Right: row.Left + 68, Bottom: row.Top + 36}
	badgeBg := rgb(28, 47, 66)
	if selected {
		badgeBg = rgb(36, 74, 96)
	}
	drawRoundRect(dis.HDC, badge, badgeBg, rgb(45, 61, 78), 15)
	initial := "TV"
	runes := []rune(strings.TrimSpace(name))
	if len(runes) > 0 {
		initial = strings.ToUpper(string(runes[0]))
	}
	if a.fontSection != 0 {
		procSelectObject.Call(dis.HDC, a.fontSection)
	}
	drawTextRect(dis.HDC, badge, initial, rgb(238, 244, 248), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)

	// Main text + subtle category line.
	if a.fontBody != 0 {
		procSelectObject.Call(dis.HDC, a.fontBody)
	}
	nameRc := RECT{Left: row.Left + 78, Top: row.Top + 5, Right: row.Right - 34, Bottom: row.Top + 24}
	drawTextRect(dis.HDC, nameRc, name, rgb(237, 242, 247), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)
	if a.fontSmall != 0 {
		procSelectObject.Call(dis.HDC, a.fontSmall)
	}
	groupRc := RECT{Left: row.Left + 78, Top: row.Top + 23, Right: row.Right - 34, Bottom: row.Bottom - 3}
	drawTextRect(dis.HDC, groupRc, group, rgb(128, 143, 158), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)

	if favorite {
		starRc := RECT{Left: row.Right - 28, Top: row.Top + 4, Right: row.Right - 8, Bottom: row.Top + 24}
		drawTextRect(dis.HDC, starRc, "★", rgb(255, 59, 72), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
	} else if selected {
		// Signal bars echo the mockup's live indicator.
		fillSolid(dis.HDC, RECT{Left: row.Right - 23, Top: row.Top + 26, Right: row.Right - 20, Bottom: row.Bottom - 5}, rgb(255, 59, 72))
		fillSolid(dis.HDC, RECT{Left: row.Right - 17, Top: row.Top + 20, Right: row.Right - 14, Bottom: row.Bottom - 5}, rgb(255, 59, 72))
		fillSolid(dis.HDC, RECT{Left: row.Right - 11, Top: row.Top + 14, Right: row.Right - 8, Bottom: row.Bottom - 5}, rgb(255, 59, 72))
	}
	return 1
}

func mainWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	a := gApp
	if a == nil {
		r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
		return r
	}
	switch msg {
	case WM_CREATE:
		a.hwnd = hwnd
		a.createUI()
		return 0
	case WM_SIZE:
		a.layout()
		return 0
	case WM_COMMAND:
		a.onCommand(int(loWord(wParam)), int(hiWord(wParam)))
		return 0
	case WM_TIMER:
		switch wParam {
		case 1:
			a.updateNowNext()
		case 2:
			procKillTimer.Call(a.hwnd, 2)
			a.saveStateAsync(0)
		case 3:
			a.updateLibrarySeekAutoHide()
		}
		return 0
	case WM_PAINT:
		a.paintChrome(hwnd)
		return 0
	case WM_ERASEBKGND:
		return 1
	case WM_DRAWITEM:
		return a.drawCustomButton(lParam)
	case WM_KEYDOWN:
		if wParam == VK_F11 {
			a.toggleFullscreen()
			return 0
		}
		if wParam == VK_ESCAPE && a.fullscreen {
			a.toggleFullscreen()
			return 0
		}
	case msgProviderDone:
		a.finishProviderLoad()
		return 0
	case msgEPGDone:
		a.finishEPGLoad()
		return 0
	case msgStatus:
		a.updateInfoPanel()
		return 0
	case msgTracksDone:
		a.finishTracks()
		return 0
	case msgPlayerError:
		a.mu.Lock()
		s := a.pendingPlayerErr
		a.status = s
		a.mu.Unlock()
		a.updateInfoPanel()
		return 0
	case msgEngineDone:
		return 0
	case msgDiagnostics:
		a.mu.Lock()
		text := a.pendingDiagnostics
		a.mu.Unlock()
		if strings.TrimSpace(text) == "" {
			text = "Player is not running."
		}
		messageBox(a.hwnd, "Playback diagnostics", text, MB_OK|MB_ICONINFORMATION)
		return 0
	case msgFilterDone:
		a.finishChannelFilter()
		return 0
	case msgFilterBatch:
		a.continueChannelFilterBatch()
		return 0
	case msgHeartbeat:
		atomic.StoreInt64(&a.lastUIHeartbeat, time.Now().UnixNano())
		return 0
	case msgUpdateCheck:
		a.finishUpdateCheck()
		return 0
	case msgUpdateDone:
		a.finishUpdateInstall()
		return 0
	case msgLibrarySeek:
		a.finishLibrarySeekUpdate()
		return 0
	case WM_CTLCOLOREDIT, WM_CTLCOLORLISTBOX:
		procSetTextColor.Call(wParam, rgb(232, 237, 242))
		procSetBkColor.Call(wParam, rgb(14, 20, 29))
		return a.fieldBrush
	case WM_CTLCOLORSTATIC:
		color := rgb(218, 225, 233)
		brush := a.panelBrush
		bk := rgb(10, 15, 23)
		switch lParam {
		case a.tvGuideTab, a.currentCardTitle:
			color = rgb(255, 59, 72)
		case a.brandLabel:
			color, brush, bk = rgb(244, 247, 250), a.topBrush, rgb(10, 16, 24)
		case a.brandPlayLabel:
			color, brush, bk = rgb(255, 59, 72), a.topBrush, rgb(10, 16, 24)
		case a.brandIPTVLabel:
			color, brush, bk = rgb(128, 142, 158), a.topBrush, rgb(10, 16, 24)
		case a.sidebarNote:
			color = rgb(139, 151, 165)
		case a.providerMetaLabel:
			color, brush, bk = rgb(139, 151, 165), a.providerCardBrush, rgb(14, 21, 30)
		case a.currentCardTitle, a.nextCardTitle, a.nowLabel, a.nextLabel:
			brush, bk = a.cardBrush, rgb(13, 20, 29)
			if lParam == a.currentCardTitle {
				color = rgb(255, 59, 72)
			}
		case a.statusTitle:
			color = rgb(94, 236, 162)
		}
		procSetTextColor.Call(wParam, color)
		procSetBkColor.Call(wParam, bk)
		return brush
	case WM_CTLCOLORBTN:
		procSetTextColor.Call(wParam, rgb(230, 235, 240))
		procSetBkMode.Call(wParam, TRANSPARENT)
		return a.panelBrush
	case WM_CLOSE:
		a.shutdown()
		procDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func epgWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_SIZE:
		epgWindowEdits.Lock()
		e := epgWindowEdits.m[hwnd]
		epgWindowEdits.Unlock()
		if e != 0 {
			var rc RECT
			procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
			move(e, 8, 8, int(rc.Right-rc.Left)-16, int(rc.Bottom-rc.Top)-16)
		}
		return 0
	case WM_CTLCOLOREDIT:
		if gApp != nil {
			procSetTextColor.Call(wParam, rgb(232, 237, 242))
			procSetBkColor.Call(wParam, rgb(18, 23, 30))
			return gApp.fieldBrush
		}
	case WM_CLOSE:
		procDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		epgWindowEdits.Lock()
		delete(epgWindowEdits.m, hwnd)
		epgWindowEdits.Unlock()
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func (a *App) createUI() {
	base := uintptr(WS_CHILD | WS_VISIBLE | WS_TABSTOP)
	label := uintptr(WS_CHILD | WS_VISIBLE)
	btn := uintptr(WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_OWNERDRAW)

	// Left navigation / brand area.
	a.brandLabel = createControl(0, "STATIC", "Red", label|SS_LEFT, 18, 14, 52, 28, a.hwnd, 0)
	a.brandPlayLabel = createControl(0, "STATIC", "Play", label|SS_LEFT, 70, 14, 58, 28, a.hwnd, 0)
	a.brandIPTVLabel = createControl(0, "STATIC", "IPTV", label|SS_LEFT, 128, 14, 52, 28, a.hwnd, 0)
	a.navHomeBtn = createControl(0, "BUTTON", "⌂  Home", btn, 18, 60, 120, 30, a.hwnd, 0)
	a.navLiveBtn = createControl(0, "BUTTON", "▣  Live TV", btn, 18, 96, 120, 30, a.hwnd, 0)
	a.navMoviesBtn = createControl(0, "BUTTON", "▱  Movies", btn, 18, 132, 120, 30, a.hwnd, 0)
	a.navSettingsBtn = createControl(0, "BUTTON", "⚙  Settings", btn, 18, 168, 120, 30, a.hwnd, 0)
	a.sidebarNote = createControl(0, "STATIC", "Good entertainment\r\n brings us closer", label|SS_LEFT, 18, 690, 120, 48, a.hwnd, 0)

	// Top search.
	a.searchTitle = createControl(0, "STATIC", "Search channels", label|SS_LEFT, 170, 18, 150, 20, a.hwnd, 0)
	a.searchEdit = createControl(0, "EDIT", "", base|ES_AUTOHSCROLL, 170, 40, 620, 32, a.hwnd, idSearch)
	send(a.searchEdit, EM_SETCUEBANNER, 0, uintptr(unsafe.Pointer(utf16p("Search channels..."))))
	send(a.searchEdit, EM_SETMARGINS, EC_LEFTMARGIN|EC_RIGHTMARGIN, makeLong(14, 14))

	// Provider / channels column.
	a.providerTitle = createControl(0, "STATIC", "Playlists / Providers", label|SS_LEFT, 170, 86, 220, 22, a.hwnd, 0)
	a.providerCombo = createControl(0, "COMBOBOX", "", base|CBS_DROPDOWNLIST|WS_VSCROLL, 170, 112, 250, 460, a.hwnd, idProviderCombo)
	a.addProviderBtn = createControl(0, "BUTTON", "+ Add", btn, 426, 110, 62, 30, a.hwnd, idAddProvider)
	a.editProviderBtn = createControl(0, "BUTTON", "Edit", uintptr(WS_CHILD|WS_TABSTOP|BS_OWNERDRAW), 494, 110, 56, 30, a.hwnd, idEditProvider)
	a.refreshProviderBtn = createControl(0, "BUTTON", "Refresh", btn, 556, 110, 70, 30, a.hwnd, idRefreshProvider)
	a.deleteProviderBtn = createControl(0, "BUTTON", "Delete", btn, 632, 110, 62, 30, a.hwnd, idDeleteProvider)
	a.providerMetaLabel = createControl(0, "STATIC", "No provider loaded", label|SS_LEFT, 170, 146, 320, 34, a.hwnd, 0)
	a.categoryTitle = createControl(0, "STATIC", "Category", label|SS_LEFT, 170, 188, 120, 20, a.hwnd, 0)
	a.groupCombo = createControl(0, "COMBOBOX", "", base|CBS_DROPDOWNLIST|WS_VSCROLL, 170, 212, 270, 420, a.hwnd, idGroupCombo)
	a.favOnlyCheck = createControl(0, "BUTTON", "Favorites only", base|BS_AUTOCHECKBOX, 446, 212, 126, 28, a.hwnd, idFavoritesOnly)
	a.channelsTitle = createControl(0, "STATIC", "Channels", label|SS_LEFT, 170, 248, 120, 20, a.hwnd, 0)
	a.channelList = createControl(0, "LISTBOX", "", base|WS_VSCROLL|LBS_NOTIFY|LBS_NOINTEGRALHEIGHT|LBS_OWNERDRAWFIXED|LBS_HASSTRINGS, 170, 274, 300, 470, a.hwnd, idChannelList)

	// Main player area.
	a.channelLabel = createControl(0, "STATIC", "Select a channel", label|SS_LEFT, 492, 86, 520, 24, a.hwnd, 0)
	a.videoHost = createControl(0, "STATIC", "", uintptr(WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS)|SS_BLACKRECT, 492, 112, 760, 430, a.hwnd, 0)
	a.librarySeekHwnd = createControl(0, "RedPlayLibrarySeek", "", uintptr(WS_CHILD|WS_CLIPSIBLINGS), 504, 502, 736, 32, a.hwnd, 0)
	a.playBtn = createControl(0, "BUTTON", "Play", btn, 492, 550, 62, 32, a.hwnd, idPlay)
	a.pauseBtn = createControl(0, "BUTTON", "Pause", btn, 560, 550, 66, 32, a.hwnd, idPause)
	a.muteBtn = createControl(0, "BUTTON", "Mute", btn, 632, 550, 62, 32, a.hwnd, idMute)
	a.volDownBtn = createControl(0, "BUTTON", "Vol -", btn, 700, 550, 62, 32, a.hwnd, idVolDown)
	a.volUpBtn = createControl(0, "BUTTON", "Vol +", btn, 768, 550, 62, 32, a.hwnd, idVolUp)
	a.volumeLabel = createControl(0, "STATIC", "80%", label|SS_CENTER, 838, 556, 52, 22, a.hwnd, 0)
	a.favoriteBtn = createControl(0, "BUTTON", "☆ Favorite", btn, 896, 550, 92, 32, a.hwnd, idFavorite)
	a.libraryBtn = createControl(0, "BUTTON", "Library", btn, 994, 550, 78, 32, a.hwnd, idLibrary)
	a.epgBtn = createControl(0, "BUTTON", "TV Guide", btn, 1078, 550, 88, 32, a.hwnd, idFullEPG)
	a.diagBtn = createControl(0, "BUTTON", "Details", btn, 1088, 550, 80, 32, a.hwnd, idDiagnostics)
	a.fullscreenBtn = createControl(0, "BUTTON", "⛶", btn, 1174, 550, 44, 32, a.hwnd, idFullscreen)

	a.currentCardTitle = createControl(0, "STATIC", "Now Playing", label|SS_LEFT, 492, 594, 150, 22, a.hwnd, 0)
	a.nowLabel = createControl(0, "STATIC", "Now Playing\r\n—", label|SS_LEFT, 492, 620, 360, 118, a.hwnd, 0)
	a.nextCardTitle = createControl(0, "STATIC", "Up Next", label|SS_LEFT, 874, 594, 120, 22, a.hwnd, 0)
	a.nextLabel = createControl(0, "STATIC", "Up Next\r\n—", label|SS_LEFT, 874, 620, 378, 118, a.hwnd, 0)

	// Right information panel.
	a.tvGuideTab = createControl(0, "STATIC", "TV Guide", label|SS_LEFT, 1274, 86, 82, 22, a.hwnd, 0)
	a.channelInfoTab = createControl(0, "STATIC", "Channel Info", uintptr(WS_CHILD)|SS_LEFT, 1362, 86, 92, 22, a.hwnd, 0)
	a.settingsTab = createControl(0, "STATIC", "Settings", uintptr(WS_CHILD)|SS_LEFT, 1460, 86, 74, 22, a.hwnd, 0)
	a.guideNowLabel = createControl(0, "STATIC", "Now on selected channel\r\nChoose a channel to see TV guide data.", label|SS_LEFT, 1274, 118, 290, 146, a.hwnd, 0)
	a.audioTitle = createControl(0, "STATIC", "♫  Audio tracks", label|SS_LEFT, 1274, 272, 120, 20, a.hwnd, 0)
	a.audioCombo = createControl(0, "COMBOBOX", "", base|CBS_DROPDOWNLIST|WS_VSCROLL, 1274, 296, 290, 360, a.hwnd, idAudioCombo)
	a.subtitleTitle = createControl(0, "STATIC", "CC  Subtitles", label|SS_LEFT, 1274, 338, 120, 20, a.hwnd, 0)
	a.subCombo = createControl(0, "COMBOBOX", "", base|CBS_DROPDOWNLIST|WS_VSCROLL, 1274, 362, 290, 360, a.hwnd, idSubCombo)
	a.subSizeTitle = createControl(0, "STATIC", "Subtitle size", label|SS_LEFT, 1274, 396, 100, 20, a.hwnd, 0)
	a.subSizeDownBtn = createControl(0, "BUTTON", "−", btn, 1418, 392, 38, 30, a.hwnd, idSubSizeDown)
	a.subSizeValue = createControl(0, "STATIC", fmt.Sprintf("%d", a.state.Settings.SubtitleSize), label|SS_CENTER|WS_BORDER, 1462, 396, 48, 22, a.hwnd, 0)
	a.subSizeUpBtn = createControl(0, "BUTTON", "+", btn, 1516, 392, 38, 30, a.hwnd, idSubSizeUp)
	a.subSizeHint = createControl(0, "STATIC", "Applies globally", label|SS_LEFT, 1274, 425, 120, 18, a.hwnd, 0)
	a.streamTitle = createControl(0, "STATIC", "ⓘ  Stream information", label|SS_LEFT, 1274, 452, 160, 20, a.hwnd, 0)
	a.streamInfoLabel = createControl(0, "STATIC", "Volume: 80%", label|SS_LEFT, 1274, 476, 290, 126, a.hwnd, 0)
	a.statusTitle = createControl(0, "STATIC", "Status", label|SS_LEFT, 1274, 610, 100, 20, a.hwnd, 0)
	a.statusLabel = createControl(0, "STATIC", "Native player ready", label|SS_LEFT, 1274, 634, 290, 82, a.hwnd, 0)
	a.versionLabel = createControl(0, "STATIC", "Version "+appVersion, label|SS_LEFT, 1274, 726, 130, 20, a.hwnd, 0)
	a.updateBtn = createControl(0, "BUTTON", "Check for updates", btn, 1406, 718, 158, 30, a.hwnd, idCheckUpdate)

	a.applyFonts()
	send(a.channelList, LB_SETITEMHEIGHT, 0, 44)
	for _, h := range []uintptr{a.providerCombo, a.groupCombo, a.audioCombo, a.subCombo, a.searchEdit, a.channelList, a.favOnlyCheck} {
		setDarkTheme(h)
	}
	a.showProviderForm(false)
	send(a.audioCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p("Stream audio"))))
	send(a.audioCombo, CB_SETCURSEL, 0, 0)
	send(a.subCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p("Subtitles: Off"))))
	send(a.subCombo, CB_SETCURSEL, 0, 0)
	procSetTimer.Call(a.hwnd, 1, 30000, 0)
	a.updateInfoPanel()
}

func (a *App) nonVideoControls() []uintptr {
	return []uintptr{
		a.brandLabel, a.brandPlayLabel, a.brandIPTVLabel, a.searchTitle, a.searchEdit,
		a.navHomeBtn, a.navLiveBtn, a.navMoviesBtn, a.navSettingsBtn, a.sidebarNote,
		a.providerTitle, a.providerCombo, a.providerMetaLabel, a.addProviderBtn, a.refreshProviderBtn, a.deleteProviderBtn,
		a.channelsTitle, a.channelList, a.favOnlyCheck, a.categoryTitle, a.groupCombo,
		a.channelLabel, a.playBtn, a.pauseBtn, a.muteBtn, a.volDownBtn, a.volUpBtn, a.volumeLabel, a.librarySeekHwnd,
		a.favoriteBtn, a.libraryBtn, a.epgBtn, a.diagBtn, a.fullscreenBtn, a.currentCardTitle, a.nowLabel, a.nextCardTitle, a.nextLabel,
		a.tvGuideTab, a.guideNowLabel, a.audioTitle, a.audioCombo,
		a.subtitleTitle, a.subCombo, a.subSizeTitle, a.subSizeDownBtn, a.subSizeValue, a.subSizeUpBtn, a.subSizeHint, a.streamTitle, a.streamInfoLabel, a.statusTitle, a.statusLabel, a.versionLabel, a.updateBtn,
	}
}

func (a *App) toggleFullscreen() {
	if a.hwnd == 0 || a.videoHost == 0 {
		return
	}
	if !a.fullscreen {
		var wr RECT
		if ok, _, _ := procGetWindowRect.Call(a.hwnd, uintptr(unsafe.Pointer(&wr))); ok == 0 {
			return
		}
		mon, ok := nearestMonitorRect(a.hwnd)
		if !ok {
			return
		}
		a.showProviderForm(false)
		a.windowedRect = wr
		a.windowedStyle = getWindowStyle(a.hwnd)
		a.fullscreen = true
		borderless := a.windowedStyle &^ uintptr(WS_CAPTION|WS_THICKFRAME|WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_SYSMENU)
		setWindowStyle(a.hwnd, borderless)
		setWindowPos(a.hwnd, int(mon.Left), int(mon.Top), int(mon.Right-mon.Left), int(mon.Bottom-mon.Top), SWP_FRAMECHANGED|SWP_NOOWNERZORDER)
		setText(a.fullscreenBtn, "↙")
	} else {
		a.fullscreen = false
		if a.windowedStyle != 0 {
			setWindowStyle(a.hwnd, a.windowedStyle)
		}
		r := a.windowedRect
		if r.Right > r.Left && r.Bottom > r.Top {
			setWindowPos(a.hwnd, int(r.Left), int(r.Top), int(r.Right-r.Left), int(r.Bottom-r.Top), SWP_FRAMECHANGED|SWP_NOOWNERZORDER)
		}
		setText(a.fullscreenBtn, "⛶")
	}
	a.layout()
}

func (a *App) layout() {
	if a.hwnd == 0 {
		return
	}
	var rc RECT
	procGetClientRect.Call(a.hwnd, uintptr(unsafe.Pointer(&rc)))
	w, h := int(rc.Right-rc.Left), int(rc.Bottom-rc.Top)
	if w <= 0 || h <= 0 {
		return
	}

	if a.fullscreen {
		for _, c := range a.nonVideoControls() {
			show(c, false)
		}
		show(a.videoHost, true)
		show(a.fullscreenBtn, true)
		move(a.videoHost, 0, 0, w, h)
		if a.libraryPlaying != nil && a.librarySeekVisible {
			show(a.librarySeekHwnd, true)
			move(a.librarySeekHwnd, 24, maxInt(20, h-56), maxInt(220, w-96), 34)
			raiseWindow(a.librarySeekHwnd)
		} else {
			show(a.librarySeekHwnd, false)
		}
		move(a.fullscreenBtn, maxInt(8, w-60), maxInt(8, h-52), 46, 38)
		// Keep the exit button above the video surface.
		setWindowPos(a.fullscreenBtn, maxInt(8, w-60), maxInt(8, h-52), 46, 38, 0)
		procInvalidateRect.Call(a.hwnd, 0, 1)
		return
	}

	m := calcUIMetrics(w, h)
	ultraCompact := m.playerW < 500

	// Restore normal controls after fullscreen, then apply responsive visibility.
	for _, c := range []uintptr{
		a.brandLabel, a.brandPlayLabel, a.brandIPTVLabel, a.searchEdit,
		a.providerTitle, a.providerCombo, a.providerMetaLabel, a.addProviderBtn, a.refreshProviderBtn, a.deleteProviderBtn,
		a.channelsTitle, a.channelList, a.favOnlyCheck, a.categoryTitle, a.groupCombo,
		a.channelLabel, a.playBtn, a.pauseBtn, a.muteBtn, a.volDownBtn, a.volUpBtn, a.volumeLabel,
		a.libraryBtn, a.epgBtn, a.fullscreenBtn, a.currentCardTitle, a.nowLabel, a.nextCardTitle, a.nextLabel,
		a.audioTitle, a.audioCombo, a.subtitleTitle, a.subCombo, a.subSizeDownBtn, a.subSizeValue, a.subSizeUpBtn,
	} {
		show(c, true)
	}
	show(a.searchTitle, false)
	show(a.navHomeBtn, m.showNav)
	show(a.navLiveBtn, m.showNav)
	show(a.navMoviesBtn, m.showNav)
	show(a.navSettingsBtn, m.showNav)
	show(a.sidebarNote, m.showNav)

	// Less-essential player actions collapse on narrow player widths.
	show(a.favoriteBtn, !m.compactControls)
	show(a.diagBtn, !m.compactControls)
	show(a.volDownBtn, !ultraCompact)
	show(a.volUpBtn, !ultraCompact)
	show(a.volumeLabel, !ultraCompact)

	for _, c := range []uintptr{a.tvGuideTab, a.guideNowLabel, a.subSizeTitle, a.subSizeHint, a.streamTitle, a.streamInfoLabel, a.statusTitle, a.statusLabel, a.versionLabel, a.updateBtn} {
		show(c, m.showRight)
	}

	// Top bar.
	move(a.brandLabel, m.margin+28, 15, 46, 30)
	move(a.brandPlayLabel, m.margin+70, 15, 54, 30)
	move(a.brandIPTVLabel, m.margin+120, 16, 52, 30)
	searchW := minInt(m.playerW, 620)
	move(a.searchEdit, m.playerX+26, 18, maxInt(170, searchW-26), 28)

	// Left navigation rail: only the sections that have a useful place in this app.
	if m.showNav {
		btnY := m.contentTop + 8
		for _, c := range []uintptr{a.navHomeBtn, a.navLiveBtn, a.navMoviesBtn, a.navSettingsBtn} {
			move(c, m.margin+5, btnY, m.navW-10, 38)
			btnY += 44
		}
		move(a.sidebarNote, m.margin+10, h-74, m.navW-20, 48)
	}

	// Provider and channel browser.
	move(a.providerTitle, m.leftX+10, m.contentTop+7, maxInt(100, m.leftW-92), 24)
	move(a.addProviderBtn, m.leftX+m.leftW-70, m.contentTop+3, 58, 30)
	move(a.providerCombo, m.leftX+52, m.contentTop+39, maxInt(100, m.leftW-66), 260)
	move(a.providerMetaLabel, m.leftX+52, m.contentTop+72, maxInt(100, m.leftW-66), 28)
	actionY := m.contentTop + 109
	actionGap := 7
	actionW := maxInt(42, (m.leftW-28-actionGap)/2)
	move(a.refreshProviderBtn, m.leftX+14, actionY, actionW, 31)
	move(a.deleteProviderBtn, m.leftX+14+actionW+actionGap, actionY, actionW, 31)
	move(a.channelsTitle, m.leftX+14, m.contentTop+151, m.leftW-28, 22)
	listTop := m.contentTop + 177
	listBottom := h - 103
	if listBottom < listTop+120 {
		listBottom = listTop + 120
	}
	move(a.channelList, m.leftX+10, listTop, m.leftW-20, listBottom-listTop)
	move(a.favOnlyCheck, m.leftX+14, h-96, m.leftW-28, 24)
	move(a.categoryTitle, m.leftX+14, h-67, 100, 18)
	move(a.groupCombo, m.leftX+10, h-47, m.leftW-20, 220)

	// Main player and transport controls.
	move(a.channelLabel, m.playerX+5, m.contentTop+4, m.playerW-10, 22)
	move(a.videoHost, m.playerX, m.playerY, m.playerW, m.videoH)
	if a.libraryPlaying != nil && a.librarySeekVisible {
		show(a.librarySeekHwnd, true)
		move(a.librarySeekHwnd, m.playerX+12, m.playerY+m.videoH-38, maxInt(220, m.playerW-24), 32)
		raiseWindow(a.librarySeekHwnd)
	} else {
		show(a.librarySeekHwnd, false)
	}
	x := m.playerX
	transport := []struct {
		h  uintptr
		ww int
	}{{a.playBtn, 64}, {a.pauseBtn, 68}, {a.muteBtn, 62}, {a.volDownBtn, 58}, {a.volUpBtn, 58}}
	if m.compactControls {
		transport = []struct {
			h  uintptr
			ww int
		}{{a.playBtn, 50}, {a.pauseBtn, 54}, {a.muteBtn, 50}, {a.volDownBtn, 46}, {a.volUpBtn, 46}}
	}
	if ultraCompact {
		transport = []struct {
			h  uintptr
			ww int
		}{{a.playBtn, 50}, {a.pauseBtn, 54}, {a.muteBtn, 50}}
	}
	for _, c := range transport {
		move(c.h, x, m.controlY, c.ww, 32)
		x += c.ww + 5
	}
	volumeW := 46
	if m.compactControls {
		volumeW = 38
	}
	if !ultraCompact {
		move(a.volumeLabel, x, m.controlY+5, volumeW, 22)
		x += volumeW + 6
	}

	// Right-aligned action cluster. Library is a real on-demand catalogue, not
	// a decorative navigation item, so it remains available beside TV Guide.
	fsW, epgW, libraryW := 46, 82, 76
	clusterRight := m.playerX + m.playerW
	move(a.fullscreenBtn, clusterRight-fsW, m.controlY, fsW, 32)
	move(a.epgBtn, clusterRight-fsW-6-epgW, m.controlY, epgW, 32)
	libraryX := clusterRight - fsW - 6 - epgW - 6 - libraryW
	move(a.libraryBtn, libraryX, m.controlY, libraryW, 32)
	if !m.compactControls {
		detailW, favW := 78, 88
		move(a.diagBtn, libraryX-6-detailW, m.controlY, detailW, 32)
		move(a.favoriteBtn, libraryX-6-detailW-6-favW, m.controlY, favW, 32)
	}

	// Audio/subtitle controls move beneath transport when the right rail collapses.
	if m.showRight {
		move(a.tvGuideTab, m.rightX+4, m.contentTop+5, minInt(110, m.rightW-8), 22)
		move(a.guideNowLabel, m.rightX+5, m.contentTop+38, m.rightW-10, 132)
		move(a.audioTitle, m.rightX+5, m.contentTop+190, m.rightW-10, 20)
		move(a.audioCombo, m.rightX+5, m.contentTop+214, m.rightW-10, 300)
		move(a.subtitleTitle, m.rightX+5, m.contentTop+255, m.rightW-10, 20)
		move(a.subCombo, m.rightX+5, m.contentTop+279, m.rightW-10, 300)
		move(a.subSizeTitle, m.rightX+5, m.contentTop+318, 96, 20)
		clusterX := m.rightX + m.rightW - 141
		move(a.subSizeDownBtn, clusterX, m.contentTop+313, 38, 30)
		move(a.subSizeValue, clusterX+44, m.contentTop+317, 48, 22)
		move(a.subSizeUpBtn, clusterX+98, m.contentTop+313, 38, 30)
		move(a.subSizeHint, m.rightX+5, m.contentTop+346, m.rightW-10, 18)
		move(a.streamTitle, m.rightX+5, m.contentTop+375, m.rightW-10, 20)
		move(a.streamInfoLabel, m.rightX+5, m.contentTop+400, m.rightW-10, 92)
		move(a.statusTitle, m.rightX+23, m.contentTop+498, m.rightW-28, 20)
		updateY := h - m.margin - 34
		versionW := 106
		buttonW := maxInt(120, m.rightW-versionW-22)
		move(a.versionLabel, m.rightX+5, updateY+7, versionW, 20)
		move(a.updateBtn, m.rightX+versionW+10, updateY, buttonW, 30)
		statusBottom := updateY - 10
		move(a.statusLabel, m.rightX+5, m.contentTop+524, m.rightW-10, maxInt(50, statusBottom-(m.contentTop+524)))
	} else {
		trackGap := 12
		trackW := (m.playerW - trackGap) / 2
		trackTitleY := m.controlY + 43
		move(a.audioTitle, m.playerX, trackTitleY, trackW, 18)
		move(a.audioCombo, m.playerX, trackTitleY+20, trackW, 260)
		subX := m.playerX + trackW + trackGap
		move(a.subtitleTitle, subX, trackTitleY, maxInt(70, trackW-114), 18)
		move(a.subCombo, subX, trackTitleY+20, trackW, 260)
		move(a.subSizeDownBtn, subX+trackW-108, trackTitleY-3, 30, 24)
		move(a.subSizeValue, subX+trackW-74, trackTitleY, 38, 18)
		move(a.subSizeUpBtn, subX+trackW-32, trackTitleY-3, 30, 24)
	}

	// Programme cards adapt when width is tight by dropping the thumbnail gutter.
	thumbGutter := 122
	if m.cardW < 260 {
		thumbGutter = 18
	}
	move(a.currentCardTitle, m.playerX+24, m.cardY+11, maxInt(90, m.cardW-36), 24)
	move(a.nowLabel, m.playerX+thumbGutter, m.cardY+45, maxInt(70, m.cardW-thumbGutter-16), maxInt(60, h-m.cardY-60))
	move(a.nextCardTitle, m.playerX+m.cardW+m.cardGap+18, m.cardY+11, maxInt(90, m.cardW-30), 24)
	move(a.nextLabel, m.playerX+m.cardW+m.cardGap+thumbGutter, m.cardY+45, maxInt(70, m.cardW-thumbGutter-16), maxInt(60, h-m.cardY-60))

	procInvalidateRect.Call(a.hwnd, 0, 1)
}

func (a *App) onCommand(id, notify int) {
	switch id {
	case idAddProvider:
		if notify == BN_CLICKED {
			a.editingProvider = -1
			a.showProviderForm(true)
		}
	case idEditProvider:
		if notify == BN_CLICKED {
			a.openEditProviderForm()
		}
	case idAddCancel:
		if notify == BN_CLICKED {
			a.showProviderForm(false)
		}
	case idAddSave:
		if notify == BN_CLICKED {
			a.saveNewProvider()
		}
	case idProviderCombo:
		if notify == CBN_SELCHANGE {
			idx := int(send(a.providerCombo, CB_GETCURSEL, 0, 0))
			if idx >= 0 {
				a.loadProvider(idx)
			}
		}
	case idRefreshProvider:
		if notify == BN_CLICKED && a.currentProvider >= 0 {
			a.loadProvider(a.currentProvider)
		}
	case idDeleteProvider:
		if notify == BN_CLICKED {
			a.deleteProvider()
		}
	case idGroupCombo:
		if notify == CBN_SELCHANGE {
			a.rebuildChannelList()
		}
	case idSearch:
		if notify == EN_CHANGE {
			a.rebuildChannelList()
		}
	case idFavoritesOnly:
		if notify == BN_CLICKED {
			a.rebuildChannelList()
		}
	case idChannelList:
		if notify == LB_SELCHANGE {
			a.selectChannelFromList(false)
		}
		if notify == LB_DBLCLK {
			a.selectChannelFromList(true)
		}
	case idPlay:
		if notify == BN_CLICKED {
			a.playSelectedChannel()
		}
	case idPause:
		if notify == BN_CLICKED {
			a.runPlayerAction("Pause", a.player.TogglePause)
		}
	case idMute:
		if notify == BN_CLICKED {
			a.runPlayerAction("Mute", a.player.ToggleMute)
		}
	case idVolDown:
		if notify == BN_CLICKED {
			a.changeVolume(-5)
		}
	case idVolUp:
		if notify == BN_CLICKED {
			a.changeVolume(5)
		}
	case idAudioCombo:
		if notify == CBN_SELCHANGE {
			a.changeAudioTrack()
		}
	case idSubCombo:
		if notify == CBN_SELCHANGE {
			a.changeSubtitleTrack()
		}
	case idSubSizeDown:
		if notify == BN_CLICKED {
			a.changeSubtitleSize(-subtitleSizeStep)
		}
	case idSubSizeUp:
		if notify == BN_CLICKED {
			a.changeSubtitleSize(subtitleSizeStep)
		}
	case idFavorite:
		if notify == BN_CLICKED {
			a.toggleFavorite()
		}
	case idLibrary:
		if notify == BN_CLICKED {
			a.openLibraryWindow()
		}
	case idFullEPG:
		if notify == BN_CLICKED {
			a.openEPGWindow()
		}
	case idFullscreen:
		if notify == BN_CLICKED {
			a.toggleFullscreen()
		}
	case idDiagnostics:
		if notify == BN_CLICKED {
			go func() {
				text := a.player.Diagnostics()
				if strings.TrimSpace(text) == "" {
					text = "Player is not running."
				}
				a.mu.Lock()
				a.pendingDiagnostics = text
				a.mu.Unlock()
				post(a.hwnd, msgDiagnostics, 0, 0)
			}()
		}
	case idCheckUpdate:
		if notify == BN_CLICKED {
			a.checkForUpdates()
		}
	}
}

func (a *App) saveNewProvider() {
	name := strings.TrimSpace(getText(a.formNameEdit))
	remote := strings.TrimSpace(getText(a.formURLEdit))
	selectedFile := strings.TrimSpace(a.formSelectedFile)
	if remote == "" && selectedFile == "" {
		messageBox(a.providerDialogOwner(), "RedPlay IPTV", "Enter an M3U/M3U8 playlist URL or choose an M3U file.", MB_OK|MB_ICONERROR)
		return
	}

	idx := a.editingProvider
	providerID := "provider-" + strconv.FormatInt(time.Now().UnixNano(), 10)
	oldURL := ""
	createdAt := time.Now().Unix()
	epg := ""
	headers := map[string]string{}
	if idx >= 0 && idx < len(a.state.Providers) {
		old := a.state.Providers[idx]
		providerID = old.ID
		oldURL = old.URL
		createdAt = old.CreatedAt
		if createdAt == 0 {
			createdAt = time.Now().Unix()
		}
		epg = a.formPreservedEPG
		headers = cloneStringMap(a.formPreservedHeaders)
	}

	var raw string
	var err error
	if selectedFile != "" {
		raw, err = persistProviderPlaylistFile(providerID, selectedFile)
		if err != nil {
			messageBox(a.providerDialogOwner(), "RedPlay IPTV", "Could not import playlist file: "+err.Error(), MB_OK|MB_ICONERROR)
			return
		}
		if name == "" {
			name = strings.TrimSuffix(filepath.Base(selectedFile), filepath.Ext(selectedFile))
		}
	} else {
		raw, err = normalizeProviderURL(remote)
		if err != nil {
			messageBox(a.providerDialogOwner(), "RedPlay IPTV", "Invalid playlist URL: "+err.Error(), MB_OK|MB_ICONERROR)
			return
		}
	}

	// Hidden legacy EPG/header values are preserved only while editing the same
	// source. If the user intentionally changes the source, stale request headers
	// or an explicit EPG URL must not be applied to the new playlist.
	if oldURL != "" {
		oldNorm, oldErr := normalizeProviderURL(oldURL)
		newNorm, newErr := normalizeProviderURL(raw)
		if oldErr != nil || newErr != nil || oldNorm != newNorm {
			epg = ""
			headers = map[string]string{}
		}
	}

	if existing, ok := findProviderByURL(a.state.Providers, raw); ok && existing != idx {
		messageBox(a.providerDialogOwner(), "RedPlay IPTV", "This playlist is already added as \""+a.state.Providers[existing].Name+"\".", MB_OK|MB_ICONINFORMATION)
		return
	}
	if name == "" {
		name = nextProviderName(a.state.Providers)
	}

	if idx >= 0 && idx < len(a.state.Providers) {
		p := a.state.Providers[idx]
		p.Name = name
		p.URL = raw
		p.EPGURL = epg
		p.Headers = headers
		p.CreatedAt = createdAt
		a.state.Providers[idx] = p
		a.state.LastProvider = p.ID
		if oldURL != "" && oldURL != raw {
			removeManagedPlaylistFile(oldURL)
		}
	} else {
		p := Provider{ID: providerID, Name: name, URL: raw, EPGURL: epg, Headers: headers, CreatedAt: createdAt}
		a.state.Providers = append(a.state.Providers, p)
		idx = len(a.state.Providers) - 1
		a.state.LastProvider = p.ID
	}
	a.saveStateAsync(120 * time.Millisecond)
	a.populateProviders()
	send(a.providerCombo, CB_SETCURSEL, uintptr(idx), 0)
	a.showProviderForm(false)
	a.loadProvider(idx)
}

func (a *App) openEditProviderForm() {
	idx := int(send(a.providerCombo, CB_GETCURSEL, 0, 0))
	if idx < 0 || idx >= len(a.state.Providers) {
		return
	}
	a.editingProvider = idx
	a.showProviderForm(true)
}

func (a *App) deleteProvider() {
	idx := int(send(a.providerCombo, CB_GETCURSEL, 0, 0))
	if idx < 0 || idx >= len(a.state.Providers) {
		return
	}
	p := a.state.Providers[idx]
	if messageBox(a.hwnd, "RedPlay IPTV", "Delete provider \""+p.Name+"\"?", MB_YESNO|MB_ICONQUESTION) != IDYES {
		return
	}
	// Invalidate every async result that can still reference this provider.
	if a.providerCancel != nil {
		a.providerCancel()
	}
	if a.epgCancel != nil {
		a.epgCancel()
	}
	if a.playCancel != nil {
		a.playCancel()
	}
	atomic.AddInt64(&a.loadGen, 1)
	atomic.AddInt64(&a.epgGen, 1)
	atomic.AddInt64(&a.playGen, 1)
	atomic.AddInt64(&a.filterGen, 1)
	if token := a.player.CurrentToken(); token != "" {
		go a.player.AbortIfToken(token)
	}
	a.state.Providers = append(a.state.Providers[:idx], a.state.Providers[idx+1:]...)
	removeManagedPlaylistFile(p.URL)
	if a.state.LastProvider == p.ID {
		a.state.LastProvider = ""
	}
	a.saveStateAsync(120 * time.Millisecond)
	a.playlist = Playlist{}
	a.epg = EPGData{}
	a.currentProvider = -1
	a.currentChannel = -1
	a.libraryPlaying = nil
	a.resetLibrarySeek()
	a.layout()
	a.populateProviders()
	send(a.channelList, LB_RESETCONTENT, 0, 0)
	setText(a.channelLabel, "Select a channel")
	a.updateNowNext()
	a.updateInfoPanel()
}

func (a *App) populateProviders() {
	send(a.providerCombo, CB_RESETCONTENT, 0, 0)
	for _, p := range a.state.Providers {
		send(a.providerCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p(p.Name))))
	}
	if len(a.state.Providers) == 0 {
		a.updateInfoPanel()
		return
	}
	idx := 0
	for i, p := range a.state.Providers {
		if p.ID == a.state.LastProvider {
			idx = i
			break
		}
	}
	send(a.providerCombo, CB_SETCURSEL, uintptr(idx), 0)
	a.currentProvider = idx
	a.updateInfoPanel()
}

func (a *App) loadProvider(idx int) {
	if idx < 0 || idx >= len(a.state.Providers) {
		return
	}
	if a.providerCancel != nil {
		a.providerCancel()
	}
	if a.epgCancel != nil {
		a.epgCancel()
	}
	if a.playCancel != nil {
		a.playCancel()
	}
	// A provider switch invalidates old EPG, playback setup, and list-filter work.
	atomic.AddInt64(&a.epgGen, 1)
	atomic.AddInt64(&a.playGen, 1)
	atomic.AddInt64(&a.filterGen, 1)
	if token := a.player.CurrentToken(); token != "" {
		go a.player.AbortIfToken(token)
	}
	a.currentChannel = -1
	a.libraryPlaying = nil
	a.resetLibrarySeek()
	a.layout()
	a.filtered = nil
	a.filterLabels = nil
	send(a.channelList, LB_RESETCONTENT, 0, 0)
	procEnableWindow.Call(a.channelList, 0)
	setText(a.channelLabel, "Select a channel")
	a.updateNowNext()
	gen := atomic.AddInt64(&a.loadGen, 1)
	ctx, cancel := context.WithCancel(a.ctx)
	a.providerCancel = cancel
	p := a.state.Providers[idx]
	a.currentProvider = idx
	a.state.LastProvider = p.ID
	a.saveStateAsync(120 * time.Millisecond)
	a.setStatusAsync("Loading provider: " + p.Name + "...")
	go func() {
		text, err := FetchText(ctx, p.URL, p.Headers, 128<<20)
		pl := Playlist{}
		if err == nil {
			pl, err = ParseM3UContext(ctx, text, p.URL)
			if len(pl.Channels) == 0 {
				if err == nil {
					err = fmt.Errorf("playlist contains no playable channels")
				}
			}
		}
		// Never publish an obsolete result into the shared pending slot. Without
		// this guard an older, slower provider load can overwrite a newer result
		// before the UI thread consumes its posted message.
		if gen != atomic.LoadInt64(&a.loadGen) || ctx.Err() != nil {
			return
		}
		a.mu.Lock()
		a.pendingLoad = asyncLoadResult{gen: gen, provider: p, playlist: pl, err: err}
		a.mu.Unlock()
		post(a.hwnd, msgProviderDone, 0, 0)
	}()
}

func (a *App) finishProviderLoad() {
	a.mu.Lock()
	r := a.pendingLoad
	a.mu.Unlock()
	if r.gen != atomic.LoadInt64(&a.loadGen) {
		return
	}
	if r.err != nil {
		a.setStatusAsync("Provider error: " + r.err.Error())
		return
	}
	a.playlist = r.playlist
	a.currentChannel = -1
	a.epg = EPGData{}
	a.epgURL = ""
	a.populateGroups()
	a.rebuildChannelList()
	a.updateInfoPanel()
	a.setStatusAsync(fmt.Sprintf("%s — %d channels", r.provider.Name, len(r.playlist.Channels)))
	epg := strings.TrimSpace(r.provider.EPGURL)
	if epg == "" {
		epg = r.playlist.EPGURL
	}
	if epg != "" {
		a.loadEPG(epg, r.provider.Headers)
	}
}

func (a *App) populateGroups() {
	groups := map[string]bool{}
	for _, c := range a.playlist.Channels {
		g := strings.TrimSpace(c.Group)
		if g == "" {
			g = "Other"
		}
		groups[g] = true
	}
	arr := make([]string, 0, len(groups))
	for g := range groups {
		arr = append(arr, g)
	}
	sort.Strings(arr)
	send(a.groupCombo, CB_RESETCONTENT, 0, 0)
	send(a.groupCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p("All categories"))))
	for _, g := range arr {
		send(a.groupCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p(g))))
	}
	send(a.groupCombo, CB_SETCURSEL, 0, 0)
}

func comboSelectedText(hwnd uintptr) string {
	idx := int(send(hwnd, CB_GETCURSEL, 0, 0))
	if idx < 0 {
		return ""
	}
	const CB_GETLBTEXT = 0x0148
	const CB_GETLBTEXTLEN = 0x0149
	n := int(send(hwnd, CB_GETLBTEXTLEN, uintptr(idx), 0))
	if n <= 0 {
		return ""
	}
	buf := make([]uint16, n+1)
	send(hwnd, CB_GETLBTEXT, uintptr(idx), uintptr(unsafe.Pointer(&buf[0])))
	return syscall.UTF16ToString(buf)
}
func (a *App) favoriteSet() map[string]bool {
	m := map[string]bool{}
	for _, k := range a.state.Favorites {
		m[k] = true
	}
	return m
}
func (a *App) rebuildChannelList() {
	group := comboSelectedText(a.groupCombo)
	query := getText(a.searchEdit)
	favOnly := send(a.favOnlyCheck, BM_GETCHECK, 0, 0) == BST_CHECKED
	fav := a.favoriteSet()
	channels := a.playlist.Channels
	gen := atomic.AddInt64(&a.filterGen, 1)

	// Do not keep stale row mappings clickable while a new result is prepared.
	a.filtered = nil
	a.filterLabels = nil
	a.filterBatchPos = 0
	a.filterDisplayGen = 0
	send(a.channelList, LB_RESETCONTENT, 0, 0)
	procEnableWindow.Call(a.channelList, 0)

	// Debounce typing and keep O(n) normalization/filtering off the Win32
	// message thread. Large provider lists must never monopolize the UI pump.
	go func() {
		t := time.NewTimer(90 * time.Millisecond)
		defer t.Stop()
		select {
		case <-a.ctx.Done():
			return
		case <-t.C:
		}
		if gen != atomic.LoadInt64(&a.filterGen) {
			return
		}
		items := buildChannelListItemsCancelable(channels, group, query, favOnly, fav, func() bool { return gen != atomic.LoadInt64(&a.filterGen) || a.ctx.Err() != nil })
		if gen != atomic.LoadInt64(&a.filterGen) || a.ctx.Err() != nil {
			return
		}
		a.mu.Lock()
		a.pendingFilter = asyncFilterResult{gen: gen, items: items}
		a.mu.Unlock()
		post(a.hwnd, msgFilterDone, 0, 0)
	}()
}

func (a *App) finishChannelFilter() {
	a.mu.Lock()
	r := a.pendingFilter
	a.mu.Unlock()
	if r.gen != atomic.LoadInt64(&a.filterGen) {
		return
	}
	a.filtered = make([]int, len(r.items))
	a.filterLabels = make([]string, len(r.items))
	for i, item := range r.items {
		a.filtered[i] = item.Index
		a.filterLabels[i] = item.Label
	}
	a.filterBatchPos = 0
	a.filterDisplayGen = r.gen
	send(a.channelList, LB_RESETCONTENT, 0, 0)
	if len(a.filterLabels) == 0 {
		procEnableWindow.Call(a.channelList, 1)
		return
	}
	// Preallocate list-box storage to reduce repeated reallocations for large lists.
	send(a.channelList, LB_INITSTORAGE, uintptr(len(a.filterLabels)), uintptr(len(a.filterLabels)*48))
	post(a.hwnd, msgFilterBatch, 0, 0)
}

func (a *App) continueChannelFilterBatch() {
	gen := a.filterDisplayGen
	if gen == 0 || gen != atomic.LoadInt64(&a.filterGen) {
		return
	}
	const batch = 200
	end := a.filterBatchPos + batch
	if end > len(a.filterLabels) {
		end = len(a.filterLabels)
	}
	for i := a.filterBatchPos; i < end; i++ {
		send(a.channelList, LB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p(a.filterLabels[i]))))
	}
	a.filterBatchPos = end
	if a.filterBatchPos < len(a.filterLabels) {
		post(a.hwnd, msgFilterBatch, 0, 0)
		return
	}
	procEnableWindow.Call(a.channelList, 1)
	procInvalidateRect.Call(a.channelList, 0, 1)
}

func (a *App) selectChannelFromList(play bool) {
	row := int(send(a.channelList, LB_GETCURSEL, 0, 0))
	if row < 0 || row >= len(a.filtered) {
		return
	}
	a.currentChannel = a.filtered[row]
	c := a.playlist.Channels[a.currentChannel]
	setText(a.channelLabel, c.Name)
	a.updateFavoriteButton()
	a.updateNowNext()
	if play {
		a.playChannel(a.currentChannel)
	}
}
func (a *App) playSelectedChannel() {
	if a.currentChannel >= 0 {
		a.playChannel(a.currentChannel)
		return
	}
	a.selectChannelFromList(true)
}

func (a *App) setTrackControlsLoading() {
	a.audioTracks = nil
	a.subTracks = nil
	send(a.audioCombo, CB_RESETCONTENT, 0, 0)
	send(a.subCombo, CB_RESETCONTENT, 0, 0)
	send(a.audioCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p("Loading audio..."))))
	send(a.subCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p("Loading subtitles..."))))
	send(a.audioCombo, CB_SETCURSEL, 0, 0)
	send(a.subCombo, CB_SETCURSEL, 0, 0)
	procEnableWindow.Call(a.audioCombo, 0)
	procEnableWindow.Call(a.subCombo, 0)
}

func (a *App) playChannel(idx int) {
	if idx < 0 || idx >= len(a.playlist.Channels) {
		return
	}
	a.libraryPlaying = nil
	a.resetLibrarySeek()
	a.layout()
	c := a.playlist.Channels[idx]
	a.currentChannel = idx
	setText(a.channelLabel, c.Name)
	a.updateNowNext()
	a.updateFavoriteButton()
	a.setTrackControlsLoading()
	if a.playCancel != nil {
		a.playCancel()
	}
	gen := atomic.AddInt64(&a.playGen, 1)
	atomic.AddInt64(&a.audioActionGen, 1)
	atomic.AddInt64(&a.subActionGen, 1)
	atomic.AddInt64(&a.volumeActionGen, 1)
	ctx, cancel := context.WithCancel(a.ctx)
	a.playCancel = cancel
	p := Provider{}
	if a.currentProvider >= 0 && a.currentProvider < len(a.state.Providers) {
		p = a.state.Providers[a.currentProvider]
	}
	headers := mergeHeaders(p.Headers, c.Headers)
	settings := a.state.Settings
	a.setStatusAsync("Opening " + c.Name + "...")
	go func() {
		exe := a.getEngineExe()
		var err error
		if exe == "" {
			exe, err = EnsureMPV(ctx, func(pc int, msg string) { a.setStatusAsync(msg) })
			if err == nil {
				a.setEngineExe(exe)
			}
		}
		if err == nil && gen == atomic.LoadInt64(&a.playGen) {
			err = a.player.Start(ctx, exe, a.videoHost, c, headers, settings.Volume, settings.SubtitleSize)
		}
		if err != nil {
			if gen == atomic.LoadInt64(&a.playGen) {
				a.setPlayerErrorAsync("Playback error: " + err.Error())
			}
			return
		}
		if gen != atomic.LoadInt64(&a.playGen) || ctx.Err() != nil {
			return
		}
		a.setStatusAsync("Playing via native mpv - " + c.Name)
		time.Sleep(1200 * time.Millisecond)
		tracks, terr := a.queryTracksWithRetry(gen)
		if terr == nil {
			a.player.ApplyLanguagePolicy(tracks, settings.AutoSubtitles)
			if settings.AutoSubtitles && !hasBulgarianSubtitle(tracks) {
				subs := DiscoverHLSSubtitles(ctx, c.URL, headers)
				for _, s := range subs {
					if isBulgarianLang(s.Lang) || isBulgarianLang(s.Name) {
						if a.player.AddSubtitle(s.URL, firstNonEmpty(s.Name, "Bulgarian"), firstNonEmpty(s.Lang, "bg")) == nil {
							time.Sleep(550 * time.Millisecond)
							tracks, _ = a.queryTracksWithRetry(gen)
							a.player.ApplyLanguagePolicy(tracks, true)
						}
						break
					}
				}
			}
			if updated, uerr := a.queryTracksWithRetry(gen); uerr == nil && len(updated) > 0 {
				tracks = updated
				terr = nil
			}
		}
		if gen != atomic.LoadInt64(&a.playGen) || ctx.Err() != nil {
			return
		}
		a.mu.Lock()
		a.pendingTracks = asyncTracksResult{gen: gen, tracks: tracks, err: terr}
		a.mu.Unlock()
		post(a.hwnd, msgTracksDone, 0, 0)
	}()
}
func firstNonEmpty(v, d string) string {
	if strings.TrimSpace(v) != "" {
		return v
	}
	return d
}
func hasBulgarianSubtitle(t []MPVTrack) bool {
	for _, x := range t {
		if x.Type == "sub" && (isBulgarianLang(x.Lang) || isBulgarianLang(x.Title)) {
			return true
		}
	}
	return false
}
func (a *App) queryTracksWithRetry(gen int64) ([]MPVTrack, error) {
	var t []MPVTrack
	var e error
	for i := 0; i < 8; i++ {
		if gen != atomic.LoadInt64(&a.playGen) {
			return nil, context.Canceled
		}
		t, e = a.player.Tracks()
		if gen != atomic.LoadInt64(&a.playGen) {
			return nil, context.Canceled
		}
		if e == nil && len(t) > 0 {
			return t, nil
		}
		time.Sleep(450 * time.Millisecond)
	}
	return t, e
}

func (a *App) finishTracks() {
	a.mu.Lock()
	r := a.pendingTracks
	a.mu.Unlock()
	if r.gen != atomic.LoadInt64(&a.playGen) {
		return
	}
	if r.err != nil {
		a.audioTracks = nil
		a.subTracks = nil
		send(a.audioCombo, CB_RESETCONTENT, 0, 0)
		send(a.subCombo, CB_RESETCONTENT, 0, 0)
		send(a.audioCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p("Stream audio"))))
		send(a.subCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p("Subtitles: Off"))))
		send(a.audioCombo, CB_SETCURSEL, 0, 0)
		send(a.subCombo, CB_SETCURSEL, 0, 0)
		procEnableWindow.Call(a.audioCombo, 1)
		procEnableWindow.Call(a.subCombo, 1)
		return
	}
	a.audioTracks = nil
	a.subTracks = nil
	send(a.audioCombo, CB_RESETCONTENT, 0, 0)
	send(a.subCombo, CB_RESETCONTENT, 0, 0)
	audioSel := -1
	subSel := 0
	for _, t := range r.tracks {
		if t.Type == "audio" {
			a.audioTracks = append(a.audioTracks, t)
			label := trackLabel(t, "Audio")
			send(a.audioCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p(label))))
			if t.Selected {
				audioSel = len(a.audioTracks) - 1
			}
		}
	}
	if len(a.audioTracks) == 0 {
		send(a.audioCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p("Stream audio"))))
		audioSel = 0
	}
	if audioSel < 0 {
		audioSel = 0
	}
	send(a.audioCombo, CB_SETCURSEL, uintptr(audioSel), 0)
	send(a.subCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p("Subtitles: Off"))))
	for _, t := range r.tracks {
		if t.Type == "sub" {
			a.subTracks = append(a.subTracks, t)
			send(a.subCombo, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(utf16p(trackLabel(t, "Subtitle")))))
			if t.Selected {
				subSel = len(a.subTracks)
			}
		}
	}
	send(a.subCombo, CB_SETCURSEL, uintptr(subSel), 0)
	procEnableWindow.Call(a.audioCombo, 1)
	procEnableWindow.Call(a.subCombo, 1)
}
func trackLabel(t MPVTrack, fallback string) string {
	parts := []string{}
	if t.Title != "" {
		parts = append(parts, t.Title)
	}
	if t.Lang != "" && !strings.EqualFold(t.Lang, t.Title) {
		parts = append(parts, strings.ToUpper(t.Lang))
	}
	if len(parts) == 0 {
		parts = append(parts, fmt.Sprintf("%s %d", fallback, t.ID))
	}
	if t.Codec != "" {
		parts = append(parts, "["+t.Codec+"]")
	}
	return strings.Join(parts, " ")
}
func ignorablePlayerActionError(err error) bool {
	if err == nil {
		return true
	}
	s := strings.ToLower(err.Error())
	return strings.Contains(s, "not running") || strings.Contains(s, "player changed") || strings.Contains(s, "context canceled") || strings.Contains(s, "operation canceled")
}

func (a *App) runPlayerAction(label string, fn func() error) {
	if a.playerActionSem == nil {
		a.playerActionSem = make(chan struct{}, 1)
	}
	select {
	case a.playerActionSem <- struct{}{}:
		go func() {
			defer func() { <-a.playerActionSem }()
			if err := fn(); !ignorablePlayerActionError(err) {
				a.setStatusAsync(label + ": " + err.Error())
			}
		}()
	default:
		// A previous UI command is still in flight. Dropping rapid repeat clicks is
		// preferable to queuing seconds of stale commands and freezing the UI.
	}
}

func (a *App) runLatestPlayerAction(label string, genPtr *int64, fn func() error) {
	gen := atomic.AddInt64(genPtr, 1)
	go func() {
		deadline := time.Now().Add(2500 * time.Millisecond)
		for {
			if gen != atomic.LoadInt64(genPtr) || a.ctx.Err() != nil {
				return
			}
			select {
			case a.playerActionSem <- struct{}{}:
				defer func() { <-a.playerActionSem }()
				if gen != atomic.LoadInt64(genPtr) {
					return
				}
				if err := fn(); !ignorablePlayerActionError(err) {
					a.setStatusAsync(label + ": " + err.Error())
				}
				return
			default:
				if time.Now().After(deadline) {
					a.setStatusAsync(label + ": player is busy")
					return
				}
				time.Sleep(25 * time.Millisecond)
			}
		}
	}()
}

func (a *App) changeAudioTrack() {
	idx := int(send(a.audioCombo, CB_GETCURSEL, 0, 0))
	if idx >= 0 && idx < len(a.audioTracks) {
		id := a.audioTracks[idx].ID
		a.runLatestPlayerAction("Audio track", &a.audioActionGen, func() error { return a.player.SelectAudio(id) })
	}
}
func (a *App) changeSubtitleTrack() {
	idx := int(send(a.subCombo, CB_GETCURSEL, 0, 0))
	if idx <= 0 {
		a.runLatestPlayerAction("Subtitles", &a.subActionGen, a.player.DisableSubtitles)
		return
	}
	i := idx - 1
	if i < len(a.subTracks) {
		id := a.subTracks[i].ID
		a.runLatestPlayerAction("Subtitle track", &a.subActionGen, func() error { return a.player.SelectSubtitle(id) })
	}
}
func (a *App) changeSubtitleSize(delta int) {
	old := a.state.Settings.SubtitleSize
	v := normalizeSubtitleSize(old + delta)
	if v == old {
		return
	}
	a.state.Settings.SubtitleSize = v
	setText(a.subSizeValue, fmt.Sprintf("%d", v))
	procKillTimer.Call(a.hwnd, 2)
	procSetTimer.Call(a.hwnd, 2, 450, 0)
	a.runLatestPlayerAction("Subtitle size", &a.subSizeActionGen, func() error { return a.player.SetSubtitleSize(v) })
}

func (a *App) changeVolume(delta int) {
	v := a.state.Settings.Volume + delta
	if v < 0 {
		v = 0
	}
	if v > 100 {
		v = 100
	}
	a.state.Settings.Volume = v
	setText(a.volumeLabel, fmt.Sprintf("%d%%", v))
	a.updateInfoPanel()
	// Coalesce disk writes while the user is clicking the volume buttons.
	procKillTimer.Call(a.hwnd, 2)
	procSetTimer.Call(a.hwnd, 2, 450, 0)
	a.runLatestPlayerAction("Volume", &a.volumeActionGen, func() error { return a.player.SetVolume(v) })
}

func (a *App) saveStateAsync(delay time.Duration) {
	snapshot := cloneAppState(a.state)
	gen := atomic.AddInt64(&a.saveGen, 1)
	go func() {
		if delay > 0 {
			t := time.NewTimer(delay)
			defer t.Stop()
			select {
			case <-a.ctx.Done():
				return
			case <-t.C:
			}
		}
		if gen != atomic.LoadInt64(&a.saveGen) {
			return
		}
		if err := SaveState(snapshot); err != nil {
			a.setStatusAsync("Could not save settings: " + err.Error())
		}
	}()
}

func (a *App) toggleFavorite() {
	if a.currentChannel < 0 || a.currentChannel >= len(a.playlist.Channels) {
		return
	}
	k := channelKey(a.playlist.Channels[a.currentChannel])
	found := -1
	for i, x := range a.state.Favorites {
		if x == k {
			found = i
			break
		}
	}
	if found >= 0 {
		a.state.Favorites = append(a.state.Favorites[:found], a.state.Favorites[found+1:]...)
	} else {
		a.state.Favorites = append(a.state.Favorites, k)
	}
	a.saveStateAsync(120 * time.Millisecond)
	a.updateFavoriteButton()
	a.updateInfoPanel()
	a.rebuildChannelList()
}
func (a *App) updateFavoriteButton() {
	if a.currentChannel < 0 || a.currentChannel >= len(a.playlist.Channels) {
		setText(a.favoriteBtn, "Favorite")
		return
	}
	if a.favoriteSet()[channelKey(a.playlist.Channels[a.currentChannel])] {
		setText(a.favoriteBtn, "★ Saved")
	} else {
		setText(a.favoriteBtn, "☆ Favorite")
	}
}

func (a *App) loadEPG(raw string, headers map[string]string) {
	if a.epgCancel != nil {
		a.epgCancel()
	}
	gen := atomic.AddInt64(&a.epgGen, 1)
	ctx, cancel := context.WithCancel(a.ctx)
	a.epgCancel = cancel
	a.epgURL = raw
	go func() {
		body, err := OpenURL(ctx, raw, headers)
		d := EPGData{}
		if err == nil {
			defer body.Close()
			now := time.Now()
			d, err = ParseXMLTVContext(ctx, body, now.Add(-24*time.Hour), now.Add(15*24*time.Hour))
		}
		if gen != atomic.LoadInt64(&a.epgGen) || ctx.Err() != nil {
			return
		}
		a.mu.Lock()
		a.pendingEPG = asyncEPGResult{gen: gen, data: d, err: err, url: raw}
		a.mu.Unlock()
		post(a.hwnd, msgEPGDone, 0, 0)
	}()
}
func (a *App) finishEPGLoad() {
	a.mu.Lock()
	r := a.pendingEPG
	a.mu.Unlock()
	if r.gen != atomic.LoadInt64(&a.epgGen) {
		return
	}
	if r.err != nil {
		a.setStatusAsync("Channels loaded; EPG error: " + r.err.Error())
		return
	}
	a.epg = r.data
	a.updateNowNext()
	a.setStatusAsync(fmt.Sprintf("Ready — EPG loaded (%d channels)", len(r.data.Programmes)))
}
func (a *App) updateNowNext() {
	if a.currentChannel < 0 || a.currentChannel >= len(a.playlist.Channels) {
		if a.libraryPlaying != nil {
			m := *a.libraryPlaying
			header := m.DisplayTitle + "  •  Library"
			setText(a.channelLabel, header)
			meta := strings.TrimSpace(strings.Join([]string{m.Year, formatLibraryDuration(m.Duration)}, "  •  "))
			meta = strings.Trim(meta, " •")
			nowText := "On-demand movie\r\n" + m.DisplayTitle
			if meta != "" {
				nowText += "\r\n" + meta
			}
			setText(a.nowLabel, nowText)
			setText(a.nextLabel, "Western Channel Library\r\nPause and seek anywhere in the movie.")
			setText(a.guideNowLabel, "Library playback\r\n"+m.DisplayTitle+"\r\nDirect on-demand playback")
			a.updateInfoPanel()
			return
		}
		setText(a.channelLabel, "Select a channel")
		setText(a.nowLabel, "Choose a channel to view the current programme.")
		setText(a.nextLabel, "The upcoming programme will appear here.")
		setText(a.guideNowLabel, "Now on selected channel\r\nChoose a channel to see TV guide data.")
		a.updateInfoPanel()
		return
	}
	c := a.playlist.Channels[a.currentChannel]
	header := c.Name
	if strings.TrimSpace(c.Group) != "" {
		header += "  •  " + c.Group
	}
	setText(a.channelLabel, header)
	cur, nxt := nowNextFor(c, a.epg, time.Now())
	if cur != nil {
		nowText := fmt.Sprintf("%s\r\n%s – %s", cur.Title, cur.Start.Format("15:04"), cur.Stop.Format("15:04"))
		if strings.TrimSpace(cur.Desc) != "" {
			d := cur.Desc
			if len([]rune(d)) > 110 {
				d = string([]rune(d)[:110]) + "…"
			}
			nowText += "\r\n\r\n" + d
		}
		setText(a.nowLabel, nowText)
		guideText := fmt.Sprintf("Now on %s\r\n\r\n%s\r\n%s – %s", c.Name, cur.Title, cur.Start.Format("15:04"), cur.Stop.Format("15:04"))
		if strings.TrimSpace(cur.SubTitle) != "" {
			guideText += "\r\n" + cur.SubTitle
		}
		if strings.TrimSpace(cur.Desc) != "" {
			d := cur.Desc
			if len([]rune(d)) > 220 {
				d = string([]rune(d)[:220]) + "…"
			}
			guideText += "\r\n\r\n" + d
		}
		setText(a.guideNowLabel, guideText)
	} else {
		setText(a.nowLabel, "Now Playing\r\nNo EPG programme available.")
		setText(a.guideNowLabel, "Now on selected channel\r\nNo EPG programme available for this channel.")
	}
	if nxt != nil {
		nextText := fmt.Sprintf("%s\r\n%s – %s", nxt.Title, nxt.Start.Format("15:04"), nxt.Stop.Format("15:04"))
		if strings.TrimSpace(nxt.Desc) != "" {
			d := nxt.Desc
			if len([]rune(d)) > 110 {
				d = string([]rune(d)[:110]) + "…"
			}
			nextText += "\r\n\r\n" + d
		}
		setText(a.nextLabel, nextText)
	} else {
		setText(a.nextLabel, "Up Next\r\nNo upcoming programme available.")
	}
	a.updateInfoPanel()
}

func (a *App) updateInfoPanel() {
	providerName := "No provider"
	providerChannels := 0
	if a.currentProvider >= 0 && a.currentProvider < len(a.state.Providers) {
		providerName = a.state.Providers[a.currentProvider].Name
	}
	providerChannels = len(a.playlist.Channels)
	setText(a.providerMetaLabel, fmt.Sprintf("Current: %s\r\nLoaded channels: %d", providerName, providerChannels))

	status := strings.TrimSpace(a.status)
	if status == "" {
		status = "Native player ready"
	}
	setText(a.statusLabel, status)

	channelName := "—"
	groupName := "—"
	if a.currentChannel >= 0 && a.currentChannel < len(a.playlist.Channels) {
		c := a.playlist.Channels[a.currentChannel]
		channelName = c.Name
		if strings.TrimSpace(c.Group) != "" {
			groupName = c.Group
		}
	} else if a.libraryPlaying != nil {
		channelName = a.libraryPlaying.DisplayTitle
		groupName = "Library"
	}
	autoSubs := "Off"
	if a.state.Settings.AutoSubtitles {
		autoSubs = "On"
	}
	favCount := len(a.state.Favorites)
	setText(a.streamInfoLabel, fmt.Sprintf("Provider: %s\r\nChannel: %s\r\nCategory: %s\r\nVolume: %d%%\r\nFavorites: %d\r\nAuto subtitles: %s", providerName, channelName, groupName, a.state.Settings.Volume, favCount, autoSubs))
}

func (a *App) checkForUpdates() {
	if a.updateBtn == 0 {
		return
	}
	setText(a.updateBtn, "Checking...")
	procEnableWindow.Call(a.updateBtn, 0)
	go func() {
		ctx, cancel := context.WithTimeout(a.ctx, 35*time.Second)
		defer cancel()
		info, err := checkForUpdate(ctx)
		a.mu.Lock()
		a.pendingUpdate = asyncUpdateResult{info: info, err: err}
		a.mu.Unlock()
		post(a.hwnd, msgUpdateCheck, 0, 0)
	}()
}

func (a *App) finishUpdateCheck() {
	a.mu.Lock()
	r := a.pendingUpdate
	a.mu.Unlock()
	procEnableWindow.Call(a.updateBtn, 1)
	setText(a.updateBtn, "Check for updates")
	if r.err != nil {
		setText(a.versionLabel, "Version "+appVersion)
		messageBox(a.hwnd, "RedPlay update", "Could not check for updates.\r\n\r\n"+r.err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	if !isNewerVersion(appVersion, r.info.Version) {
		setText(a.versionLabel, "Version "+appVersion+"  •  Up to date")
		return
	}
	notes := strings.TrimSpace(r.info.Notes)
	if len([]rune(notes)) > 650 {
		notes = string([]rune(notes)[:650]) + "…"
	}
	msg := fmt.Sprintf("RedPlay IPTV %s is available.\r\n\r\nInstalled: %s", r.info.Version, appVersion)
	if notes != "" {
		msg += "\r\n\r\n" + notes
	}
	msg += "\r\n\r\nDownload and install now?"
	if messageBox(a.hwnd, "RedPlay update available", msg, MB_YESNO|MB_ICONQUESTION) != IDYES {
		setText(a.versionLabel, "Update: "+r.info.Version)
		return
	}
	setText(a.updateBtn, "Downloading...")
	procEnableWindow.Call(a.updateBtn, 0)
	go func(info updateInfo) {
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
		defer cancel()
		path, err := downloadUpdate(ctx, info)
		if err == nil {
			err = launchUpdateInstaller(path)
		}
		a.mu.Lock()
		if err != nil {
			a.pendingUpdateErr = err.Error()
		} else {
			a.pendingUpdateErr = ""
		}
		a.mu.Unlock()
		post(a.hwnd, msgUpdateDone, 0, 0)
	}(r.info)
}

func (a *App) finishUpdateInstall() {
	a.mu.Lock()
	errText := a.pendingUpdateErr
	a.mu.Unlock()
	if errText != "" {
		procEnableWindow.Call(a.updateBtn, 1)
		setText(a.updateBtn, "Check for updates")
		messageBox(a.hwnd, "RedPlay update", "Update failed.\r\n\r\n"+errText, MB_OK|MB_ICONERROR)
		return
	}
	setText(a.updateBtn, "Installing...")
	setText(a.versionLabel, "Restarting for update...")
	// The installer also closes RedPlay before replacing the executable.
	// Closing here makes the transition immediate and leaves user state intact.
	post(a.hwnd, WM_CLOSE, 0, 0)
}

func (a *App) openEPGWindow() {
	if a.currentChannel < 0 || a.currentChannel >= len(a.playlist.Channels) {
		return
	}
	c := a.playlist.Channels[a.currentChannel]
	id := matchEPGChannel(c, a.epg)
	arr := a.epg.Programmes[id]
	var b strings.Builder
	b.WriteString(c.Name + "\r\n\r\n")
	if len(arr) == 0 {
		b.WriteString("No EPG programmes available.\r\n")
	}
	for _, p := range arr {
		if p.Stop.Before(time.Now().Add(-2 * time.Hour)) {
			continue
		}
		b.WriteString(p.Start.Format("Mon 02 Jan 15:04") + "  " + p.Title + "\r\n")
		if p.SubTitle != "" {
			b.WriteString("    " + p.SubTitle + "\r\n")
		}
		if p.Desc != "" {
			d := p.Desc
			if len([]rune(d)) > 220 {
				d = string([]rune(d)[:220]) + "…"
			}
			b.WriteString("    " + d + "\r\n")
		}
		b.WriteString("\r\n")
	}
	hinst, _, _ := procGetModuleHandleW.Call(0)
	wnd, _, _ := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(utf16p("RedPlayEPGWindow"))), uintptr(unsafe.Pointer(utf16p("TV Guide — "+c.Name))), WS_OVERLAPPEDWINDOW|WS_VISIBLE, uintptr(CW_USEDEFAULT), uintptr(CW_USEDEFAULT), 760, 650, 0, 0, hinst, 0)
	if wnd == 0 {
		return
	}
	edit := createControl(WS_EX_CLIENTEDGE, "EDIT", b.String(), uintptr(WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_HSCROLL)|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY, 8, 8, 728, 600, wnd, 0)
	epgWindowEdits.Lock()
	epgWindowEdits.m[wnd] = edit
	epgWindowEdits.Unlock()
	procShowWindow.Call(wnd, SW_SHOW)
	procUpdateWindow.Call(wnd)
}

func (a *App) startUIWatchdog() {
	atomic.StoreInt64(&a.lastUIHeartbeat, time.Now().UnixNano())
	go func() {
		t := time.NewTicker(2 * time.Second)
		defer t.Stop()
		var lastReport time.Time
		for {
			select {
			case <-a.ctx.Done():
				return
			case <-t.C:
				post(a.hwnd, msgHeartbeat, 0, 0)
				last := time.Unix(0, atomic.LoadInt64(&a.lastUIHeartbeat))
				if time.Since(last) < 7*time.Second || time.Since(lastReport) < 20*time.Second {
					continue
				}
				lastReport = time.Now()
				buf := make([]byte, 1<<20)
				n := runtime.Stack(buf, true)
				path := filepath.Join(nativeDataDir(), "redplay-hang.log")
				f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
				if err == nil {
					fmt.Fprintf(f, "\r\n=== RedPlay UI unresponsive at %s ===\r\n", time.Now().Format(time.RFC3339))
					_, _ = f.Write(buf[:n])
					_ = f.Close()
				}
			}
		}
	}()
}

func (a *App) ensureEngineBackground() {
	go func() {
		exe, err := EnsureMPV(a.ctx, func(pc int, msg string) { a.setStatusAsync(msg) })
		if err != nil {
			a.setStatusAsync("Media engine: " + err.Error())
			return
		}
		a.setEngineExe(exe)
		a.setStatusAsync("Native media engine ready")
	}()
}
func (a *App) shutdown() {
	if a.libraryHwnd != 0 {
		procDestroyWindow.Call(a.libraryHwnd)
		a.libraryHwnd = 0
	}
	if a.cancel != nil {
		a.cancel()
	}
	if a.providerCancel != nil {
		a.providerCancel()
	}
	if a.epgCancel != nil {
		a.epgCancel()
	}
	if a.playCancel != nil {
		a.playCancel()
	}
	atomic.AddInt64(&a.playGen, 1)
	if a.player != nil {
		go a.player.Abort()
	}
	_ = TrySaveState(cloneAppState(a.state))
	procKillTimer.Call(a.hwnd, 1)
	procKillTimer.Call(a.hwnd, 2)
	procKillTimer.Call(a.hwnd, 3)
}

func loadAppIcon(hwnd uintptr) {
	exe, _ := os.Executable()
	p := filepath.Join(filepath.Dir(exe), "RedPlayIcon.ico")
	if _, err := os.Stat(p); err != nil {
		return
	}
	ico, _, _ := procLoadImageW.Call(0, uintptr(unsafe.Pointer(utf16p(p))), IMAGE_ICON, 0, 0, LR_LOADFROMFILE|LR_DEFAULTSIZE)
	if ico != 0 {
		send(hwnd, WM_SETICON, ICON_BIG, ico)
		send(hwnd, WM_SETICON, ICON_SMALL, ico)
	}
}

func registerWindowClasses(hinst uintptr, bg uintptr) error {
	mainName := utf16p("RedPlayNativeWindow")
	cursor, _, _ := procLoadCursorW.Call(0, IDC_ARROW)
	wc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(mainWndProc), HInstance: hinst, HCursor: cursor, HbrBackground: bg, LpszClassName: mainName}
	if r, _, _ := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); r == 0 {
		return fmt.Errorf("could not register main window class")
	}
	epgName := utf16p("RedPlayEPGWindow")
	wc2 := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(epgWndProc), HInstance: hinst, HCursor: cursor, HbrBackground: bg, LpszClassName: epgName}
	procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc2)))
	providerName := utf16p("RedPlayProviderDialog")
	wc3 := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(providerDialogWndProc), HInstance: hinst, HCursor: cursor, HbrBackground: bg, LpszClassName: providerName}
	if r, _, _ := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc3))); r == 0 {
		return fmt.Errorf("could not register provider dialog class")
	}
	libraryName := utf16p("RedPlayLibraryWindow")
	wc4 := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), Style: CS_DBLCLKS, LpfnWndProc: syscall.NewCallback(libraryWndProc), HInstance: hinst, HCursor: cursor, HbrBackground: bg, LpszClassName: libraryName}
	if r, _, _ := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc4))); r == 0 {
		return fmt.Errorf("could not register library window class")
	}
	seekName := utf16p("RedPlayLibrarySeek")
	wc5 := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(librarySeekWndProc), HInstance: hinst, HCursor: cursor, HbrBackground: bg, LpszClassName: seekName}
	if r, _, _ := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc5))); r == 0 {
		return fmt.Errorf("could not register library seek class")
	}
	return nil
}

func runNativeUI() error {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	st, err := LoadState()
	if err != nil {
		st = defaultState()
	}
	ctx, cancel := context.WithCancel(context.Background())
	a := &App{ctx: ctx, cancel: cancel, state: st, player: NewMPVPlayer(), currentProvider: -1, currentChannel: -1, editingProvider: -1, playerActionSem: make(chan struct{}, 1)}
	gApp = a
	a.bgBrush, _, _ = procCreateSolidBrush.Call(rgb(7, 11, 17))
	a.panelBrush, _, _ = procCreateSolidBrush.Call(rgb(10, 15, 23))
	a.fieldBrush, _, _ = procCreateSolidBrush.Call(rgb(14, 20, 29))
	a.accentBrush, _, _ = procCreateSolidBrush.Call(rgb(255, 59, 72))
	a.cardBrush, _, _ = procCreateSolidBrush.Call(rgb(13, 20, 29))
	a.providerCardBrush, _, _ = procCreateSolidBrush.Call(rgb(14, 21, 30))
	a.topBrush, _, _ = procCreateSolidBrush.Call(rgb(10, 16, 24))
	a.fontBrand = createFont(24, FW_SEMIBOLD, "Segoe UI")
	a.fontSection = createFont(16, FW_SEMIBOLD, "Segoe UI")
	a.fontBody = createFont(14, FW_NORMAL, "Segoe UI")
	a.fontSmall = createFont(12, FW_NORMAL, "Segoe UI")
	a.fontButton = createFont(14, FW_SEMIBOLD, "Segoe UI")
	a.fontProviderTitle = createFont(28, FW_SEMIBOLD, "Segoe UI")
	a.fontProviderSubtitle = createFont(17, FW_NORMAL, "Segoe UI")
	a.fontProviderLabel = createFont(17, FW_SEMIBOLD, "Segoe UI")
	a.fontProviderDrop = createFont(18, FW_SEMIBOLD, "Segoe UI")
	hinst, _, _ := procGetModuleHandleW.Call(0)
	if err := registerWindowClasses(hinst, a.bgBrush); err != nil {
		return err
	}
	hwnd, _, _ := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(utf16p("RedPlayNativeWindow"))), uintptr(unsafe.Pointer(utf16p("RedPlay IPTV"))), WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN, uintptr(CW_USEDEFAULT), uintptr(CW_USEDEFAULT), 1480, 900, 0, 0, hinst, 0)
	if hwnd == 0 {
		return fmt.Errorf("could not create RedPlay window")
	}
	a.hwnd = hwnd
	enableDarkMode(hwnd)
	loadAppIcon(hwnd)
	procShowWindow.Call(hwnd, SW_SHOW)
	procUpdateWindow.Call(hwnd)
	a.populateProviders()
	setText(a.volumeLabel, fmt.Sprintf("%d%%", a.state.Settings.Volume))
	setText(a.subSizeValue, fmt.Sprintf("%d", a.state.Settings.SubtitleSize))
	a.layout()
	a.startUIWatchdog()
	a.ensureEngineBackground()
	if len(a.state.Providers) > 0 && a.state.Settings.AutoLastProvider {
		idx := int(send(a.providerCombo, CB_GETCURSEL, 0, 0))
		if idx >= 0 {
			a.loadProvider(idx)
		}
	}
	var m MSG
	for {
		r, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		// The provider editor is a real modal owned window. Route keyboard
		// navigation to it before interpreting application-wide shortcuts.
		if a.providerDialogHwnd != 0 {
			if m.Message == WM_KEYDOWN && m.WParam == VK_ESCAPE {
				a.showProviderForm(false)
				continue
			}
			if handled, _, _ := procIsDialogMessageW.Call(a.providerDialogHwnd, uintptr(unsafe.Pointer(&m))); handled != 0 {
				continue
			}
		}
		// Handle fullscreen keys before child controls consume them.
		if m.Message == WM_KEYDOWN {
			if m.WParam == VK_F11 {
				a.toggleFullscreen()
				continue
			}
			if m.WParam == VK_ESCAPE && a.fullscreen {
				a.toggleFullscreen()
				continue
			}
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
	return nil
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}
