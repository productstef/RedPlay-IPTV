package main

import (
	"bytes"
	"context"
	"errors"
	"strings"
	"testing"
	"time"
)

func TestXMLTVNowNext(t *testing.T) {
	x := `<tv><channel id="c1"><display-name>Test TV</display-name></channel><programme channel="c1" start="20260908090000 +0300" stop="20260908100000 +0300"><title>Morning</title></programme><programme channel="c1" start="20260908100000 +0300" stop="20260908110000 +0300"><title>Next</title></programme></tv>`
	d, e := ParseXMLTV(strings.NewReader(x), time.Time{}, time.Time{})
	if e != nil {
		t.Fatal(e)
	}
	n := time.Date(2026, 9, 8, 9, 30, 0, 0, time.FixedZone("EEST", 3*3600))
	c := Channel{TVGID: "c1", Name: "Test TV"}
	cur, nxt := nowNextFor(c, d, n)
	if cur == nil || cur.Title != "Morning" || nxt == nil || nxt.Title != "Next" {
		t.Fatalf("cur=%+v nxt=%+v", cur, nxt)
	}
}

func TestXMLTVContextCancellation(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, err := ParseXMLTVContext(ctx, strings.NewReader(`<tv><channel id="x"><display-name>X</display-name></channel></tv>`), time.Time{}, time.Time{})
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("expected context cancellation, got %v", err)
	}
}
func TestXMLTVNoTimezone(t *testing.T) {
	if _, ok := parseXMLTVTime("20260908090000"); !ok {
		t.Fatal("timezone-less XMLTV timestamp rejected")
	}
}

func TestXMLTVWindows1251(t *testing.T) {
	prefix := []byte(`<?xml version="1.0" encoding="windows-1251"?><tv><channel id="bg"><display-name>`)
	name := []byte{0xC1, 0xCD, 0xD2} // БНТ
	suffix := []byte(`</display-name></channel></tv>`)
	raw := append(prefix, name...)
	raw = append(raw, suffix...)
	d, err := ParseXMLTV(bytes.NewReader(raw), time.Time{}, time.Time{})
	if err != nil {
		t.Fatal(err)
	}
	if got := d.DisplayNames["bg"]; len(got) != 1 || got[0] != "БНТ" {
		t.Fatalf("got %#v", got)
	}
}
