package main

import (
	"archive/zip"
	"os"
	"path/filepath"
	"testing"
)

func TestExtractZipSafeAndHash(t *testing.T) {
	d := t.TempDir()
	zpath := filepath.Join(d, "e.zip")
	zf, err := os.Create(zpath)
	if err != nil {
		t.Fatal(err)
	}
	zw := zip.NewWriter(zf)
	w, _ := zw.Create("mpv/mpv.exe")
	_, _ = w.Write([]byte("MZsynthetic"))
	_ = zw.Close()
	_ = zf.Close()
	out := filepath.Join(d, "out")
	if err := extractZipSafe(zpath, out); err != nil {
		t.Fatal(err)
	}
	if got := findFileRecursive(out, "mpv.exe"); got == "" {
		t.Fatal("mpv.exe not found")
	}
	if h, err := fileSHA256(zpath); err != nil || len(h) != 64 {
		t.Fatalf("bad hash: %q %v", h, err)
	}
}

func TestExtractZipRejectsTraversal(t *testing.T) {
	d := t.TempDir()
	zpath := filepath.Join(d, "bad.zip")
	zf, _ := os.Create(zpath)
	zw := zip.NewWriter(zf)
	w, _ := zw.Create("../evil.exe")
	_, _ = w.Write([]byte("x"))
	_ = zw.Close()
	_ = zf.Close()
	if err := extractZipSafe(zpath, filepath.Join(d, "out")); err == nil {
		t.Fatal("expected traversal rejection")
	}
}

func TestExtractMPVArchiveNested(t *testing.T) {
	d := t.TempDir()
	innerPath := filepath.Join(d, "inner.zip")
	innerFile, err := os.Create(innerPath)
	if err != nil {
		t.Fatal(err)
	}
	inner := zip.NewWriter(innerFile)
	w, err := inner.Create("portable/mpv.exe")
	if err != nil {
		t.Fatal(err)
	}
	_, _ = w.Write([]byte("MZsynthetic-native-player"))
	if err := inner.Close(); err != nil {
		t.Fatal(err)
	}
	if err := innerFile.Close(); err != nil {
		t.Fatal(err)
	}
	innerBytes, err := os.ReadFile(innerPath)
	if err != nil {
		t.Fatal(err)
	}

	outerPath := filepath.Join(d, "outer.zip")
	outerFile, err := os.Create(outerPath)
	if err != nil {
		t.Fatal(err)
	}
	outer := zip.NewWriter(outerFile)
	ow, err := outer.Create("mpv-release-portable.zip")
	if err != nil {
		t.Fatal(err)
	}
	_, _ = ow.Write(innerBytes)
	if err := outer.Close(); err != nil {
		t.Fatal(err)
	}
	if err := outerFile.Close(); err != nil {
		t.Fatal(err)
	}

	exe, err := extractMPVArchive(outerPath, filepath.Join(d, "out"))
	if err != nil {
		t.Fatal(err)
	}
	if filepath.Base(exe) != "mpv.exe" {
		t.Fatalf("unexpected executable: %s", exe)
	}
}
