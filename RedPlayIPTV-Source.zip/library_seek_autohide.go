package main

import "time"

const librarySeekHideDelay = 2 * time.Second

func librarySeekShouldHide(now, lastActivity time.Time, dragging bool) bool {
	if dragging || lastActivity.IsZero() {
		return false
	}
	return !now.Before(lastActivity.Add(librarySeekHideDelay))
}
