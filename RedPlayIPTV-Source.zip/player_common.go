package main

import "strings"

// mpvHeaderArgs maps provider/channel HTTP requirements to mpv's native network options.
func mpvHeaderArgs(headers map[string]string) []string {
	headers = safeHeaders(headers)
	var out []string
	if ua := headers["User-Agent"]; ua != "" {
		out = append(out, "--user-agent="+ua)
	}
	if ref := headers["Referer"]; ref != "" {
		out = append(out, "--referrer="+ref)
	}
	var fields []string
	for _, k := range []string{"Origin", "Cookie", "Authorization", "Accept-Language"} {
		if v := headers[k]; v != "" {
			fields = append(fields, k+": "+v)
		}
	}
	if len(fields) > 0 {
		out = append(out, "--http-header-fields="+strings.Join(fields, ","))
	}
	return out
}

type MPVTrack struct {
	ID       int
	Type     string
	Lang     string
	Title    string
	Codec    string
	Selected bool
	Default  bool
	Forced   bool
}

// preferredAudioTrackID implements RedPlay's policy: keep a selected/default
// Bulgarian or English track; otherwise prefer English when it exists.
func preferredAudioTrackID(tracks []MPVTrack) (int, bool) {
	var selected, def, english *MPVTrack
	for i := range tracks {
		t := &tracks[i]
		if t.Type != "audio" {
			continue
		}
		if t.Selected {
			selected = t
		}
		if def == nil && t.Default {
			def = t
		}
		if english == nil && (isEnglishLang(t.Lang) || isEnglishLang(t.Title)) {
			english = t
		}
	}
	chosen := selected
	if chosen == nil {
		chosen = def
	}
	if chosen == nil || english == nil {
		return 0, false
	}
	if isBulgarianLang(chosen.Lang) || isBulgarianLang(chosen.Title) || isEnglishLang(chosen.Lang) || isEnglishLang(chosen.Title) {
		return 0, false
	}
	return english.ID, true
}

func preferredBulgarianSubtitleID(tracks []MPVTrack) (int, bool) {
	for _, t := range tracks {
		if t.Type == "sub" && (isBulgarianLang(t.Lang) || isBulgarianLang(t.Title)) {
			return t.ID, true
		}
	}
	return 0, false
}

// preferredSubtitleTrackID implements RedPlay's auto-subtitle policy:
// keep an already selected subtitle track, otherwise prefer Bulgarian,
// then English, then a default-marked track, and finally the first
// available subtitle track so subtitles are enabled by default.
func preferredSubtitleTrackID(tracks []MPVTrack) (int, bool) {
	var first, selected, bulgarian, english, def *MPVTrack
	for i := range tracks {
		t := &tracks[i]
		if t.Type != "sub" {
			continue
		}
		if first == nil {
			first = t
		}
		if t.Selected {
			selected = t
		}
		if bulgarian == nil && (isBulgarianLang(t.Lang) || isBulgarianLang(t.Title)) {
			bulgarian = t
		}
		if english == nil && (isEnglishLang(t.Lang) || isEnglishLang(t.Title)) {
			english = t
		}
		if def == nil && t.Default {
			def = t
		}
	}
	if selected != nil {
		return 0, false
	}
	if bulgarian != nil {
		return bulgarian.ID, true
	}
	if english != nil {
		return english.ID, true
	}
	if def != nil {
		return def.ID, true
	}
	if first != nil {
		return first.ID, true
	}
	return 0, false
}
