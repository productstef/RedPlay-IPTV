package main

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestStatePersistsAndRecoversBackup(t *testing.T) {
	old := os.Getenv("LOCALAPPDATA")
	t.Cleanup(func() { _ = os.Setenv("LOCALAPPDATA", old) })
	d := t.TempDir()
	_ = os.Setenv("LOCALAPPDATA", d)
	s := defaultState()
	s.Providers = []Provider{{ID: "p1", Name: "Provider", URL: "http://example.test/list.m3u"}}
	s.Favorites = []string{"id:c1"}
	s.Settings.Volume = 0
	s.Settings.SubtitleSize = 46
	if err := SaveState(s); err != nil {
		t.Fatal(err)
	}
	got, err := LoadState()
	if err != nil {
		t.Fatal(err)
	}
	if len(got.Providers) != 1 || got.Settings.Volume != 0 || got.Settings.SubtitleSize != 46 {
		t.Fatalf("roundtrip failed: %+v", got)
	}
	// Save again so a backup exists, then corrupt primary.
	if err := SaveState(got); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(d, "RedPlay IPTV", "state.json"), []byte("{broken"), 0644); err != nil {
		t.Fatal(err)
	}
	recovered, err := LoadState()
	if err != nil {
		t.Fatal(err)
	}
	if len(recovered.Providers) != 1 || recovered.Providers[0].ID != "p1" {
		t.Fatalf("backup recovery failed: %+v", recovered)
	}
}

func TestLegacyBrowserStateMigration(t *testing.T) {
	old := os.Getenv("LOCALAPPDATA")
	t.Cleanup(func() { _ = os.Setenv("LOCALAPPDATA", old) })
	d := t.TempDir()
	_ = os.Setenv("LOCALAPPDATA", d)
	dir := filepath.Join(d, "RedPlay IPTV")
	_ = os.MkdirAll(dir, 0755)
	legacy := `{"redplay.providers.v1":[{"id":"old","name":"Old provider","url":"http://example.test/list.m3u"}],"redplay.favorites.v1":["id:one"],"redplay.lastProvider.v1":"old","redplay.settings.v1":{"volume":55,"preferredAudio":"bg-en","preferredSubtitle":"bg","autoSubtitles":true,"autoLastProvider":true}}`
	if err := os.WriteFile(filepath.Join(dir, "state.json"), []byte(legacy), 0644); err != nil {
		t.Fatal(err)
	}
	s, err := LoadState()
	if err != nil {
		t.Fatal(err)
	}
	if len(s.Providers) != 3 || s.Providers[0].ID != "old" || s.LastProvider != "old" || s.Settings.Volume != 55 || s.Settings.SubtitleSize != defaultSubtitleSize || len(s.Favorites) != 1 || s.DefaultsVersion != currentDefaultsVersion {
		t.Fatalf("migration failed: %+v", s)
	}
	if _, ok := findProviderByURL(s.Providers, "http://92.5.59.81/western/playlist.m3u"); !ok {
		t.Fatal("Western default provider was not migrated")
	}
	if _, ok := findProviderByURL(s.Providers, "http://92.5.59.81/starwars.m3u"); !ok {
		t.Fatal("Star Wars default provider was not migrated")
	}
}

func TestCloneAppStateDeepCopiesMutableFields(t *testing.T) {
	s := defaultState()
	s.Providers = []Provider{{ID: "p", Name: "P", URL: "http://x", Headers: map[string]string{"User-Agent": "A"}}}
	s.Favorites = []string{"one"}
	c := cloneAppState(s)
	s.Providers[0].Headers["User-Agent"] = "B"
	s.Favorites[0] = "two"
	if c.Providers[0].Headers["User-Agent"] != "A" {
		t.Fatalf("header was not deep copied: %#v", c.Providers[0].Headers)
	}
	if c.Favorites[0] != "one" {
		t.Fatalf("favorites were not deep copied: %#v", c.Favorites)
	}
}

func TestTrySaveStateDoesNotWaitForBusyWriter(t *testing.T) {
	stateMu.Lock()
	done := make(chan struct{})
	go func() {
		_ = TrySaveState(defaultState())
		close(done)
	}()
	select {
	case <-done:
		stateMu.Unlock()
	case <-time.After(200 * time.Millisecond):
		stateMu.Unlock()
		t.Fatal("TrySaveState blocked behind stateMu")
	}
}

func TestStateRecoversWhenPrimaryIsMissing(t *testing.T) {
	old := os.Getenv("LOCALAPPDATA")
	t.Cleanup(func() { _ = os.Setenv("LOCALAPPDATA", old) })
	d := t.TempDir()
	_ = os.Setenv("LOCALAPPDATA", d)
	s := defaultState()
	s.Providers = []Provider{{ID: "p1", Name: "Provider", URL: "http://example.test/list.m3u"}}
	if err := SaveState(s); err != nil {
		t.Fatal(err)
	}
	if err := SaveState(s); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(d, "RedPlay IPTV", "state.json")
	if err := os.Remove(path); err != nil {
		t.Fatal(err)
	}
	got, err := LoadState()
	if err != nil {
		t.Fatal(err)
	}
	if len(got.Providers) != 1 || got.Providers[0].ID != "p1" {
		t.Fatalf("missing-primary recovery failed: %+v", got)
	}
}

func TestSubtitleSizeDefaultsAndClamps(t *testing.T) {
	if got := defaultSettings().SubtitleSize; got != 40 {
		t.Fatalf("default subtitle size = %d, want 40", got)
	}
	if got := normalizeSubtitleSize(0); got != 40 {
		t.Fatalf("zero subtitle size = %d, want 40", got)
	}
	if got := normalizeSubtitleSize(10); got != minSubtitleSize {
		t.Fatalf("low subtitle size = %d, want %d", got, minSubtitleSize)
	}
	if got := normalizeSubtitleSize(100); got != maxSubtitleSize {
		t.Fatalf("high subtitle size = %d, want %d", got, maxSubtitleSize)
	}
}

func TestBuiltInProviderMigrationRunsOnlyOnce(t *testing.T) {
	old := os.Getenv("LOCALAPPDATA")
	t.Cleanup(func() { _ = os.Setenv("LOCALAPPDATA", old) })
	d := t.TempDir()
	_ = os.Setenv("LOCALAPPDATA", d)

	// Simulate an old native state that predates built-in provider seeding.
	dir := filepath.Join(d, "RedPlay IPTV")
	_ = os.MkdirAll(dir, 0755)
	oldNative := `{"redplay.native.state.v1":{"providers":[{"id":"custom","name":"Custom","url":"https://example.test/list.m3u"}],"favorites":[],"lastProvider":"custom","settings":{"volume":80,"preferredAudio":"bg-en","preferredSubtitle":"bg","subtitleSize":40,"autoSubtitles":true,"autoLastProvider":true}}}`
	if err := os.WriteFile(filepath.Join(dir, "state.json"), []byte(oldNative), 0644); err != nil {
		t.Fatal(err)
	}
	s, err := LoadState()
	if err != nil {
		t.Fatal(err)
	}
	if len(s.Providers) != 3 {
		t.Fatalf("providers after migration = %d", len(s.Providers))
	}
	if err := SaveState(s); err != nil {
		t.Fatal(err)
	}
	// Delete Western after migration and persist. It must stay deleted.
	idx, ok := findProviderByURL(s.Providers, "http://92.5.59.81/western/playlist.m3u")
	if !ok {
		t.Fatal("Western provider missing after migration")
	}
	s.Providers = append(s.Providers[:idx], s.Providers[idx+1:]...)
	if err := SaveState(s); err != nil {
		t.Fatal(err)
	}
	reloaded, err := LoadState()
	if err != nil {
		t.Fatal(err)
	}
	if _, ok := findProviderByURL(reloaded.Providers, "http://92.5.59.81/western/playlist.m3u"); ok {
		t.Fatal("deleted built-in provider was re-added")
	}
}
