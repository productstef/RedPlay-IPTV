//go:build windows

package main

import (
	"context"
	"fmt"
	"os"
	"strings"
	"sync/atomic"
	"time"
	"unsafe"
)

const (
	idLibraryPlay = 1110
)

type libraryMetrics struct {
	grid, detail RECT
	play         RECT
	cols         int
	cardW        int
	cardH        int
	gap          int
	startX       int
	startY       int
	visibleRows  int
}

func calcLibraryMetrics(w, h int) libraryMetrics {
	pad := 28
	detailW := 350
	if w < 1080 {
		detailW = 310
	}
	gridRight := w - detailW - 42
	if gridRight < 560 {
		gridRight = maxInt(420, w*2/3)
		detailW = maxInt(250, w-gridRight-42)
	}
	m := libraryMetrics{
		grid:   RECT{Left: int32(pad), Top: 164, Right: int32(gridRight), Bottom: int32(h - 28)},
		detail: RECT{Left: int32(gridRight + 18), Top: 164, Right: int32(w - pad), Bottom: int32(h - 28)},
		gap:    14,
	}
	gridW := int(m.grid.Right - m.grid.Left)
	m.cols = 4
	if gridW < 720 {
		m.cols = 3
	}
	if gridW < 520 {
		m.cols = 2
	}
	m.cardW = (gridW - (m.cols-1)*m.gap) / m.cols
	m.cardH = minInt(260, maxInt(210, int(float64(m.cardW)*1.38)))
	m.startX = int(m.grid.Left)
	m.startY = int(m.grid.Top)
	m.visibleRows = maxInt(1, int(m.grid.Bottom-m.grid.Top)/(m.cardH+m.gap))
	playW := int(m.detail.Right-m.detail.Left) - 36
	m.play = RECT{Left: m.detail.Left + 18, Top: m.detail.Bottom - 66, Right: m.detail.Left + 18 + int32(playW), Bottom: m.detail.Bottom - 18}
	return m
}

func (a *App) libraryCardRect(m libraryMetrics, movieIndex int) (RECT, bool) {
	start := a.libraryScrollRows * m.cols
	visible := movieIndex - start
	if visible < 0 {
		return RECT{}, false
	}
	row := visible / m.cols
	col := visible % m.cols
	if row >= m.visibleRows+1 {
		return RECT{}, false
	}
	x := m.startX + col*(m.cardW+m.gap)
	y := m.startY + row*(m.cardH+m.gap)
	r := RECT{Left: int32(x), Top: int32(y), Right: int32(x + m.cardW), Bottom: int32(y + m.cardH)}
	if r.Top >= m.grid.Bottom || r.Bottom <= m.grid.Top {
		return RECT{}, false
	}
	return r, true
}

func (a *App) maxLibraryScrollRows(m libraryMetrics) int {
	if len(a.libraryData.Movies) == 0 {
		return 0
	}
	rows := (len(a.libraryData.Movies) + m.cols - 1) / m.cols
	return maxInt(0, rows-m.visibleRows)
}

func (a *App) libraryMovieAtPoint(hwnd, lParam uintptr) (int, bool) {
	var rc RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	m := calcLibraryMetrics(int(rc.Right-rc.Left), int(rc.Bottom-rc.Top))
	x, y := int(int16(loWord(lParam))), int(int16(hiWord(lParam)))
	for i := range a.libraryData.Movies {
		cr, ok := a.libraryCardRect(m, i)
		if ok && pointInRect(x, y, cr) {
			return i, true
		}
	}
	return -1, false
}

func libraryTileColor(title string) (uintptr, uintptr) {
	// Stable, intentionally muted Western palette. These are UI tiles, not fake
	// movie posters; they keep the library useful without requiring artwork APIs.
	var h uint32 = 2166136261
	for _, r := range strings.ToLower(title) {
		h ^= uint32(r)
		h *= 16777619
	}
	pal := [][2][3]byte{
		{{72, 43, 33}, {111, 55, 38}},
		{{39, 50, 60}, {74, 79, 77}},
		{{70, 34, 31}, {125, 52, 34}},
		{{33, 46, 58}, {62, 74, 84}},
		{{63, 49, 30}, {112, 77, 38}},
		{{47, 35, 39}, {91, 50, 43}},
	}
	p := pal[int(h)%len(pal)]
	return rgb(p[0][0], p[0][1], p[0][2]), rgb(p[1][0], p[1][1], p[1][2])
}

func paintLibraryPoster(hdc uintptr, rc RECT, movie LibraryMovie, selected bool, titleFont, bodyFont, smallFont uintptr) {
	border := rgb(36, 46, 58)
	if selected {
		border = rgb(26, 145, 255)
	}
	drawRoundRect(hdc, rc, rgb(12, 18, 26), border, 16)
	inner := RECT{Left: rc.Left + 5, Top: rc.Top + 5, Right: rc.Right - 5, Bottom: rc.Bottom - 64}
	top, bottom := libraryTileColor(movie.Title)
	drawRoundRect(hdc, inner, top, bottom, 13)
	// Two simple bands give the card a cinematic-poster feel without pretending
	// to be official artwork.
	mid := inner.Top + (inner.Bottom-inner.Top)*2/3
	fillSolid(hdc, RECT{Left: inner.Left + 2, Top: mid, Right: inner.Right - 2, Bottom: inner.Bottom - 2}, bottom)
	fillSolid(hdc, RECT{Left: inner.Left + 16, Top: inner.Top + 18, Right: inner.Right - 16, Bottom: inner.Top + 21}, rgb(202, 145, 91))

	if smallFont != 0 {
		procSelectObject.Call(hdc, smallFont)
	}
	drawTextRect(hdc, RECT{Left: inner.Left + 12, Top: inner.Top + 24, Right: inner.Right - 12, Bottom: inner.Top + 46}, "REDPLAY  •  WESTERN", rgb(226, 188, 142), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)

	if titleFont != 0 {
		procSelectObject.Call(hdc, titleFont)
	}
	posterTitle := strings.ToUpper(movie.DisplayTitle)
	drawTextRect(hdc, RECT{Left: inner.Left + 14, Top: inner.Top + 55, Right: inner.Right - 14, Bottom: inner.Bottom - 22}, posterTitle, rgb(247, 239, 225), DT_CENTER|DT_VCENTER|DT_WORDBREAK|DT_NOPREFIX)
	if movie.Year != "" {
		if smallFont != 0 {
			procSelectObject.Call(hdc, smallFont)
		}
		drawTextRect(hdc, RECT{Left: inner.Left + 12, Top: inner.Bottom - 29, Right: inner.Right - 12, Bottom: inner.Bottom - 8}, movie.Year, rgb(226, 188, 142), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
	}

	if bodyFont != 0 {
		procSelectObject.Call(hdc, bodyFont)
	}
	drawTextRect(hdc, RECT{Left: rc.Left + 9, Top: rc.Bottom - 58, Right: rc.Right - 9, Bottom: rc.Bottom - 34}, movie.DisplayTitle, rgb(238, 243, 248), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)
	if smallFont != 0 {
		procSelectObject.Call(hdc, smallFont)
	}
	meta := strings.TrimSpace(strings.Join([]string{movie.Year, formatLibraryDuration(movie.Duration)}, "  •  "))
	meta = strings.Trim(meta, " •")
	drawTextRect(hdc, RECT{Left: rc.Left + 9, Top: rc.Bottom - 34, Right: rc.Right - 9, Bottom: rc.Bottom - 10}, meta, rgb(143, 158, 174), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)
}

func libraryWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	a := gApp
	if a == nil {
		r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
		return r
	}
	switch msg {
	case WM_CREATE:
		a.libraryHwnd = hwnd
		a.libraryPlayBtn = createControl(0, "BUTTON", "▶  Play movie", uintptr(WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW), 0, 0, 200, 46, hwnd, idLibraryPlay)
		setFont(a.libraryPlayBtn, a.fontProviderLabel)
		a.layoutLibraryWindow(hwnd)
		return 0
	case WM_SIZE:
		a.layoutLibraryWindow(hwnd)
		return 0
	case WM_PAINT:
		a.paintLibraryWindow(hwnd)
		return 0
	case WM_ERASEBKGND:
		return 1
	case WM_DRAWITEM:
		return a.drawCustomButton(lParam)
	case WM_COMMAND:
		if int(loWord(wParam)) == idLibraryPlay && int(hiWord(wParam)) == BN_CLICKED {
			a.playSelectedLibraryMovie()
			return 0
		}
	case WM_LBUTTONDOWN:
		if i, ok := a.libraryMovieAtPoint(hwnd, lParam); ok {
			a.librarySelected = i
			procInvalidateRect.Call(hwnd, 0, 0)
			return 0
		}
	case WM_LBUTTONDBLCLK:
		if i, ok := a.libraryMovieAtPoint(hwnd, lParam); ok {
			a.librarySelected = i
			procInvalidateRect.Call(hwnd, 0, 0)
			a.playSelectedLibraryMovie()
			return 0
		}
	case WM_MOUSEWHEEL:
		var rc RECT
		procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
		m := calcLibraryMetrics(int(rc.Right-rc.Left), int(rc.Bottom-rc.Top))
		delta := int(int16(hiWord(wParam)))
		if delta < 0 {
			a.libraryScrollRows++
		} else if delta > 0 {
			a.libraryScrollRows--
		}
		if a.libraryScrollRows < 0 {
			a.libraryScrollRows = 0
		}
		if mx := a.maxLibraryScrollRows(m); a.libraryScrollRows > mx {
			a.libraryScrollRows = mx
		}
		procInvalidateRect.Call(hwnd, 0, 0)
		return 0
	case WM_CTLCOLORBTN:
		procSetTextColor.Call(wParam, rgb(238, 243, 248))
		procSetBkMode.Call(wParam, TRANSPARENT)
		return a.panelBrush
	case WM_CLOSE:
		procDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		if a.libraryHwnd == hwnd {
			a.libraryHwnd = 0
			a.libraryPlayBtn = 0
		}
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func (a *App) layoutLibraryWindow(hwnd uintptr) {
	if hwnd == 0 {
		return
	}
	var rc RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	m := calcLibraryMetrics(int(rc.Right-rc.Left), int(rc.Bottom-rc.Top))
	move(a.libraryPlayBtn, int(m.play.Left), int(m.play.Top), int(m.play.Right-m.play.Left), int(m.play.Bottom-m.play.Top))
	if mx := a.maxLibraryScrollRows(m); a.libraryScrollRows > mx {
		a.libraryScrollRows = mx
	}
	procInvalidateRect.Call(hwnd, 0, 0)
}

func (a *App) paintLibraryWindow(hwnd uintptr) {
	var ps PAINTSTRUCT
	hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	defer procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))

	var rc RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	w, h := int(rc.Right-rc.Left), int(rc.Bottom-rc.Top)
	m := calcLibraryMetrics(w, h)
	fillSolid(hdc, rc, rgb(7, 11, 17))

	// Header is deliberately sparse: this screen only contains controls that do
	// real work. The native title-bar close control remains available.
	drawRoundRect(hdc, RECT{Left: 18, Top: 18, Right: int32(w - 18), Bottom: 142}, rgb(10, 16, 24), rgb(28, 38, 50), 20)
	fillSolid(hdc, RECT{Left: 30, Top: 36, Right: 35, Bottom: 118}, rgb(255, 59, 72))
	if a.fontProviderTitle != 0 {
		procSelectObject.Call(hdc, a.fontProviderTitle)
	}
	drawTextRect(hdc, RECT{Left: 52, Top: 34, Right: int32(w - 40), Bottom: 75}, a.libraryData.Title, rgb(245, 248, 251), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)
	if a.fontBody != 0 {
		procSelectObject.Call(hdc, a.fontBody)
	}
	drawTextRect(hdc, RECT{Left: 54, Top: 78, Right: int32(w - 40), Bottom: 103}, "Pick any movie from the Western channel rotation and play it on demand.", rgb(175, 190, 207), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)
	if a.fontSmall != 0 {
		procSelectObject.Call(hdc, a.fontSmall)
	}
	drawTextRect(hdc, RECT{Left: 54, Top: 105, Right: int32(w - 40), Bottom: 128}, fmt.Sprintf("%d titles  •  direct playback  •  pause and seek enabled", len(a.libraryData.Movies)), rgb(118, 138, 158), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)

	// Movie grid.
	for i, movie := range a.libraryData.Movies {
		cr, ok := a.libraryCardRect(m, i)
		if !ok {
			continue
		}
		paintLibraryPoster(hdc, cr, movie, i == a.librarySelected, a.fontSection, a.fontBody, a.fontSmall)
	}

	// Detail panel.
	drawRoundRect(hdc, m.detail, rgb(11, 17, 25), rgb(30, 41, 54), 18)
	if len(a.libraryData.Movies) > 0 && a.librarySelected >= 0 && a.librarySelected < len(a.libraryData.Movies) {
		movie := a.libraryData.Movies[a.librarySelected]
		hero := RECT{Left: m.detail.Left + 14, Top: m.detail.Top + 14, Right: m.detail.Right - 14, Bottom: m.detail.Top + 190}
		top, bottom := libraryTileColor(movie.Title)
		drawRoundRect(hdc, hero, top, bottom, 14)
		fillSolid(hdc, RECT{Left: hero.Left + 2, Top: hero.Bottom - 62, Right: hero.Right - 2, Bottom: hero.Bottom - 2}, bottom)
		if a.fontSection != 0 {
			procSelectObject.Call(hdc, a.fontSection)
		}
		drawTextRect(hdc, RECT{Left: hero.Left + 20, Top: hero.Top + 26, Right: hero.Right - 20, Bottom: hero.Bottom - 25}, strings.ToUpper(movie.DisplayTitle), rgb(248, 240, 225), DT_CENTER|DT_VCENTER|DT_WORDBREAK|DT_NOPREFIX)

		if a.fontProviderTitle != 0 {
			procSelectObject.Call(hdc, a.fontProviderTitle)
		}
		drawTextRect(hdc, RECT{Left: m.detail.Left + 18, Top: hero.Bottom + 18, Right: m.detail.Right - 18, Bottom: hero.Bottom + 60}, movie.DisplayTitle, rgb(246, 248, 251), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)
		if a.fontBody != 0 {
			procSelectObject.Call(hdc, a.fontBody)
		}
		metaParts := make([]string, 0, 2)
		if movie.Year != "" {
			metaParts = append(metaParts, movie.Year)
		}
		if d := formatLibraryDuration(movie.Duration); d != "" {
			metaParts = append(metaParts, d)
		}
		drawTextRect(hdc, RECT{Left: m.detail.Left + 18, Top: hero.Bottom + 61, Right: m.detail.Right - 18, Bottom: hero.Bottom + 88}, strings.Join(metaParts, "   •   "), rgb(154, 170, 187), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
		descBottom := m.play.Top - 58
		drawTextRect(hdc, RECT{Left: m.detail.Left + 18, Top: hero.Bottom + 100, Right: m.detail.Right - 18, Bottom: descBottom}, movie.Description, rgb(205, 216, 228), DT_LEFT|DT_WORDBREAK|DT_NOPREFIX)
		if a.fontSmall != 0 {
			procSelectObject.Call(hdc, a.fontSmall)
		}
		drawTextRect(hdc, RECT{Left: m.detail.Left + 18, Top: m.play.Top - 44, Right: m.detail.Right - 18, Bottom: m.play.Top - 16}, "Original movie file • seekable • source audio/subtitles", rgb(111, 147, 173), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)
	}

	if a.libraryScrollRows > 0 {
		if a.fontSmall != 0 {
			procSelectObject.Call(hdc, a.fontSmall)
		}
		drawTextRect(hdc, RECT{Left: m.grid.Left, Top: m.grid.Bottom - 23, Right: m.grid.Right, Bottom: m.grid.Bottom}, "Scroll to browse more titles", rgb(107, 125, 145), DT_RIGHT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
	}
}

func (a *App) openLibraryWindow() {
	if a.currentProvider < 0 || a.currentProvider >= len(a.state.Providers) {
		messageBox(a.hwnd, "RedPlay Library", "Load the Western provider first.", MB_OK|MB_ICONINFORMATION)
		return
	}
	provider := a.state.Providers[a.currentProvider]
	lib, err := BuildWesternLibrary(provider, a.playlist, a.epg)
	if err != nil {
		messageBox(a.hwnd, "RedPlay Library", err.Error()+"\r\n\r\nThe library uses the Western XMLTV guide that is already part of your current setup.", MB_OK|MB_ICONINFORMATION)
		return
	}
	a.libraryData = lib
	a.librarySelected = 0
	a.libraryScrollRows = 0
	if a.libraryHwnd != 0 {
		procShowWindow.Call(a.libraryHwnd, SW_SHOW)
		procSetFocus.Call(a.libraryHwnd)
		procInvalidateRect.Call(a.libraryHwnd, 0, 0)
		return
	}

	hinst, _, _ := procGetModuleHandleW.Call(0)
	hwnd, _, _ := procCreateWindowExW.Call(
		0,
		uintptr(unsafe.Pointer(utf16p("RedPlayLibraryWindow"))),
		uintptr(unsafe.Pointer(utf16p("RedPlay IPTV — Western Library"))),
		WS_OVERLAPPEDWINDOW|WS_VISIBLE|WS_CLIPCHILDREN,
		uintptr(CW_USEDEFAULT), uintptr(CW_USEDEFAULT), 1260, 820,
		a.hwnd, 0, hinst, 0,
	)
	if hwnd == 0 {
		messageBox(a.hwnd, "RedPlay Library", "Could not open the library window.", MB_OK|MB_ICONERROR)
		return
	}
	a.libraryHwnd = hwnd
	enableDarkMode(hwnd)
	loadAppIcon(hwnd)
	procShowWindow.Call(hwnd, SW_SHOW)
	procUpdateWindow.Call(hwnd)
}

func (a *App) playSelectedLibraryMovie() {
	if a.librarySelected < 0 || a.librarySelected >= len(a.libraryData.Movies) {
		return
	}
	movie := a.libraryData.Movies[a.librarySelected]
	// Close the catalogue so the existing video host is immediately visible.
	if a.libraryHwnd != 0 {
		procDestroyWindow.Call(a.libraryHwnd)
	}
	a.playLibraryMovie(movie)
}

func (a *App) playLibraryMovie(movie LibraryMovie) {
	if strings.TrimSpace(movie.URL) == "" {
		return
	}
	movieCopy := movie
	a.libraryPlaying = &movieCopy
	a.resetLibrarySeek()
	a.layout()
	a.currentChannel = -1
	a.updateFavoriteButton()
	a.updateNowNext()
	a.setTrackControlsLoading()
	if a.playCancel != nil {
		a.playCancel()
	}
	gen := atomic.AddInt64(&a.playGen, 1)
	atomic.AddInt64(&a.audioActionGen, 1)
	atomic.AddInt64(&a.subActionGen, 1)
	atomic.AddInt64(&a.volumeActionGen, 1)
	ctx, cancel := context.WithCancel(a.ctx)
	a.playCancel = cancel

	provider := Provider{}
	if a.currentProvider >= 0 && a.currentProvider < len(a.state.Providers) {
		provider = a.state.Providers[a.currentProvider]
	}
	headers := cloneStringMap(provider.Headers)
	settings := a.state.Settings
	a.setStatusAsync("Finding movie file: " + movie.DisplayTitle + "...")

	go func() {
		resolvedURL, err := resolveLibraryMovieURL(ctx, movie, headers)
		if err != nil {
			if gen == atomic.LoadInt64(&a.playGen) {
				a.setPlayerErrorAsync("Library playback error: " + err.Error())
			}
			return
		}
		if gen != atomic.LoadInt64(&a.playGen) || ctx.Err() != nil {
			return
		}
		movie.URL = resolvedURL
		ch := Channel{
			ID:      "library:" + movie.Title,
			Name:    movie.DisplayTitle,
			TVGName: movie.Title,
			Group:   "Library",
			URL:     resolvedURL,
			Headers: headers,
		}
		a.setStatusAsync("Opening library movie: " + movie.DisplayTitle + "...")

		exe := a.getEngineExe()
		if exe == "" {
			exe, err = EnsureMPV(ctx, func(pc int, msg string) { a.setStatusAsync(msg) })
			if err == nil {
				a.setEngineExe(exe)
			}
		}
		if err == nil && gen == atomic.LoadInt64(&a.playGen) {
			err = a.player.Start(ctx, exe, a.videoHost, ch, headers, settings.Volume, settings.SubtitleSize)
		}
		if err == nil && gen == atomic.LoadInt64(&a.playGen) && ctx.Err() == nil {
			go a.librarySeekPollLoop(ctx, gen)
		}
		if err != nil {
			if gen == atomic.LoadInt64(&a.playGen) {
				a.setPlayerErrorAsync("Library playback error: " + err.Error())
			}
			return
		}
		if gen != atomic.LoadInt64(&a.playGen) || ctx.Err() != nil {
			return
		}

		// The Western archive already keeps matching .srt files next to the
		// movies. Some Bulgarian sidecars are legacy Windows-1251 (the live
		// Western FFmpeg path explicitly used CP1251), while others may be UTF-8.
		// Normalize the sidecar to a temporary UTF-8 .srt before sub-add so mpv
		// renders Cyrillic consistently without forcing one codepage globally.
		if strings.TrimSpace(movie.SubtitleURL) != "" {
			if rawSub, ferr := FetchText(ctx, movie.SubtitleURL, headers, 8<<20); ferr == nil {
				normalized := normalizeSubtitleText([]byte(rawSub))
				if tmp, terr := os.CreateTemp("", "redplay-sub-*.srt"); terr == nil {
					tmpPath := tmp.Name()
					_, werr := tmp.WriteString(normalized)
					cerr := tmp.Close()
					if werr == nil && cerr == nil {
						if a.player.AddSubtitle(tmpPath, "Bulgarian", "bg") == nil {
							go func(path string) {
								<-ctx.Done()
								_ = os.Remove(path)
							}(tmpPath)
						} else {
							_ = os.Remove(tmpPath)
						}
					} else {
						_ = os.Remove(tmpPath)
					}
				}
			} else {
				// Preserve the old non-fatal fallback if the app cannot prefetch the
				// sidecar (for example due to a transient server response).
				_ = a.player.AddSubtitle(movie.SubtitleURL, "Bulgarian", "bg")
			}
		}
		a.setStatusAsync("Playing on demand - " + movie.DisplayTitle)
		time.Sleep(900 * time.Millisecond)
		tracks, terr := a.queryTracksWithRetry(gen)
		if terr == nil {
			a.player.ApplyLanguagePolicy(tracks, settings.AutoSubtitles)
			if updated, uerr := a.queryTracksWithRetry(gen); uerr == nil && len(updated) > 0 {
				tracks = updated
				terr = nil
			}
		}
		if gen != atomic.LoadInt64(&a.playGen) || ctx.Err() != nil {
			return
		}
		a.mu.Lock()
		a.pendingTracks = asyncTracksResult{gen: gen, tracks: tracks, err: terr}
		a.mu.Unlock()
		post(a.hwnd, msgTracksDone, 0, 0)
	}()
}
