//go:build windows

package main

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"time"
)

const (
	mpvEngineVersion = "0.41.0"
	mpvArchiveURL    = "https://github.com/mpv-player/mpv/releases/download/v0.41.0/mpv-v0.41.0-x86_64-w64-mingw32.zip"
	mpvArchiveSHA256 = "a49811c0752c108b8260636f9c6f6fcb97406641c98b30f1e7b500dfb20177de"
)

var engineMu sync.Mutex

type EngineProgress func(percent int, message string)

func nativeDataDir() string {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		if d, err := os.UserConfigDir(); err == nil {
			base = d
		} else {
			base = os.TempDir()
		}
	}
	d := filepath.Join(base, "RedPlay IPTV")
	_ = os.MkdirAll(d, 0755)
	return d
}

func mpvEngineDir() string {
	return filepath.Join(nativeDataDir(), "EngineNative", "mpv-"+mpvEngineVersion)
}

func hiddenCommandContext(ctx context.Context, exe string, args ...string) *exec.Cmd {
	c := exec.CommandContext(ctx, exe, args...)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	return c
}

func validateMPV(ctx context.Context, exe string) error {
	if st, err := os.Stat(exe); err != nil || st.IsDir() || st.Size() < 500000 {
		if err != nil {
			return err
		}
		return fmt.Errorf("invalid mpv executable")
	}
	vctx, cancel := context.WithTimeout(ctx, 12*time.Second)
	defer cancel()
	cmd := hiddenCommandContext(vctx, exe, "--version")
	cmd.Dir = filepath.Dir(exe)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("mpv self-check failed: %w", err)
	}
	if !strings.Contains(strings.ToLower(string(out)), "mpv") {
		return fmt.Errorf("mpv self-check returned unexpected output")
	}
	return nil
}

func installedMPV(ctx context.Context) string {
	root := mpvEngineDir()
	exe := findFileRecursive(root, "mpv.exe")
	if exe == "" {
		return ""
	}
	if validateMPV(ctx, exe) == nil {
		return exe
	}
	return ""
}

func EnsureMPV(ctx context.Context, progress EngineProgress) (string, error) {
	engineMu.Lock()
	defer engineMu.Unlock()
	if exe := installedMPV(ctx); exe != "" {
		if progress != nil {
			progress(100, "Native media engine ready")
		}
		return exe, nil
	}
	select {
	case <-ctx.Done():
		return "", ctx.Err()
	default:
	}
	root := mpvEngineDir()
	_ = removeAllRetry(root, 5, 120*time.Millisecond)
	stage := root + ".staging"
	_ = removeAllRetry(stage, 5, 120*time.Millisecond)
	if err := os.MkdirAll(stage, 0755); err != nil {
		return "", err
	}
	archive := filepath.Join(nativeDataDir(), "mpv-"+mpvEngineVersion+".zip.part")
	_ = os.Remove(archive)
	if progress != nil {
		progress(0, "Downloading native media engine...")
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, mpvArchiveURL, nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("User-Agent", "RedPlay-IPTV/0.5.2")
	client := &http.Client{Timeout: 20 * time.Minute}
	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("media engine download failed: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", fmt.Errorf("media engine server returned %s", resp.Status)
	}
	f, err := os.Create(archive)
	if err != nil {
		return "", err
	}
	total := resp.ContentLength
	var done int64
	buf := make([]byte, 256*1024)
	lastPct := -1
	for {
		n, rerr := resp.Body.Read(buf)
		if n > 0 {
			if _, err := f.Write(buf[:n]); err != nil {
				f.Close()
				return "", err
			}
			done += int64(n)
			pct := 0
			message := fmt.Sprintf("Downloading native media engine... %.1f MB", float64(done)/(1024*1024))
			if total > 0 {
				pct = int(done * 85 / total)
				message = fmt.Sprintf("Downloading native media engine... %d%%", int(done*100/total))
			}
			if pct != lastPct && progress != nil {
				progress(pct, message)
				lastPct = pct
			}
		}
		if rerr == io.EOF {
			break
		}
		if rerr != nil {
			f.Close()
			return "", rerr
		}
		select {
		case <-ctx.Done():
			f.Close()
			_ = os.Remove(archive)
			return "", ctx.Err()
		default:
		}
	}
	if err := f.Sync(); err != nil {
		f.Close()
		return "", err
	}
	if err := f.Close(); err != nil {
		return "", err
	}
	if progress != nil {
		progress(88, "Verifying media engine...")
	}
	got, err := fileSHA256(archive)
	if err != nil {
		return "", err
	}
	if !strings.EqualFold(got, mpvArchiveSHA256) {
		_ = os.Remove(archive)
		return "", fmt.Errorf("media engine checksum mismatch")
	}
	if progress != nil {
		progress(92, "Installing native media engine...")
	}
	exe, err := extractMPVArchive(archive, stage)
	if err != nil {
		return "", err
	}
	_ = os.Remove(archive)
	if err := validateMPV(ctx, exe); err != nil {
		return "", err
	}
	if err := os.MkdirAll(filepath.Dir(root), 0755); err != nil {
		return "", err
	}
	_ = removeAllRetry(root, 5, 120*time.Millisecond)
	if err := os.Rename(stage, root); err != nil {
		return "", err
	}
	exe = findFileRecursive(root, "mpv.exe")
	if err := validateMPV(ctx, exe); err != nil {
		return "", err
	}
	if progress != nil {
		progress(100, "Native media engine ready")
	}
	return exe, nil
}

func removeAllRetry(path string, tries int, delay time.Duration) error {
	var err error
	for i := 0; i < tries; i++ {
		err = os.RemoveAll(path)
		if err == nil {
			return nil
		}
		time.Sleep(delay)
	}
	return err
}
