//go:build windows

package main

import (
	"embed"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"
)

// Embed whatever release payload is present. Keeping the pattern directory-wide
// lets the source tree remain testable before RedPlayIPTV.exe is generated; the
// installer still fails clearly at runtime if the executable payload is absent.
//
//go:embed payload/*
var payload embed.FS

const appName = "RedPlay IPTV"
const version = "0.6.7"

func main() {
	if len(os.Args) > 1 && strings.EqualFold(os.Args[1], "/uninstall") {
		uninstall()
		return
	}
	install()
}
func localAppData() string {
	if v := os.Getenv("LOCALAPPDATA"); v != "" {
		return v
	}
	h, _ := os.UserHomeDir()
	return filepath.Join(h, "AppData", "Local")
}
func installDir() string      { return filepath.Join(localAppData(), "Programs", appName) }
func psQuote(s string) string { return strings.ReplaceAll(s, "'", "''") }
func hidden(name string, args ...string) *exec.Cmd {
	c := exec.Command(name, args...)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	return c
}

func closeRedPlay() {
	_ = hidden("taskkill.exe", "/IM", "RedPlayIPTV.exe", "/F").Run()
	script := `$ErrorActionPreference='SilentlyContinue'; Get-CimInstance Win32_Process -Filter "Name='mpv.exe'" | Where-Object { $_.ExecutablePath -like '*RedPlay IPTV*EngineNative*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }`
	_ = hidden("powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script).Run()
}
func writeRetry(path string, data []byte, mode os.FileMode) error {
	var err error
	for i := 0; i < 10; i++ {
		err = os.WriteFile(path, data, mode)
		if err == nil {
			return nil
		}
		time.Sleep(180 * time.Millisecond)
	}
	return err
}
func install() {
	closeRedPlay()
	time.Sleep(250 * time.Millisecond)
	dir := installDir()
	if err := os.MkdirAll(dir, 0755); err != nil {
		fail(err.Error())
		return
	}
	app, err := payload.ReadFile("payload/RedPlayIPTV.exe")
	if err != nil {
		fail("Installer payload missing: " + err.Error())
		return
	}
	icon, err := payload.ReadFile("payload/RedPlayIcon.ico")
	if err != nil {
		fail("Icon payload missing: " + err.Error())
		return
	}
	appExe := filepath.Join(dir, "RedPlayIPTV.exe")
	iconPath := filepath.Join(dir, "RedPlayIcon.ico")
	if err := writeRetry(appExe, app, 0755); err != nil {
		fail("Could not install RedPlay IPTV: " + err.Error())
		return
	}
	if err := writeRetry(iconPath, icon, 0644); err != nil {
		fail("Could not install RedPlay icon: " + err.Error())
		return
	}
	self, _ := os.Executable()
	if b, e := os.ReadFile(self); e == nil {
		_ = writeRetry(filepath.Join(dir, "Uninstall.exe"), b, 0755)
	}
	createShortcuts(appExe, iconPath)
	registerUninstall(dir, iconPath)
	_ = hidden(appExe).Start()
}
func createShortcuts(appExe, iconPath string) {
	script := fmt.Sprintf(`$ErrorActionPreference='SilentlyContinue'; $ws=New-Object -ComObject WScript.Shell; $desktop=[Environment]::GetFolderPath('Desktop'); $start=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'; $target='%s'; $working='%s'; $icon='%s'; foreach($p in @((Join-Path $desktop 'RedPlay IPTV.lnk'),(Join-Path $start 'RedPlay IPTV.lnk'))){$s=$ws.CreateShortcut($p);$s.TargetPath=$target;$s.WorkingDirectory=$working;$s.IconLocation=$icon;$s.Description='RedPlay IPTV - Native IPTV Player';$s.Save()}`, psQuote(appExe), psQuote(installDir()), psQuote(iconPath))
	_ = hidden("powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script).Run()
}
func registerUninstall(dir, iconPath string) {
	key := `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\RedPlayIPTV`
	un := filepath.Join(dir, "Uninstall.exe")
	vals := [][3]string{{"DisplayName", "REG_SZ", appName}, {"DisplayVersion", "REG_SZ", version}, {"Publisher", "REG_SZ", "RedPlay"}, {"InstallLocation", "REG_SZ", dir}, {"DisplayIcon", "REG_SZ", iconPath}, {"UninstallString", "REG_SZ", `"` + un + `" /uninstall`}, {"NoModify", "REG_DWORD", "1"}, {"NoRepair", "REG_DWORD", "1"}}
	for _, v := range vals {
		_ = hidden("reg.exe", "ADD", key, "/v", v[0], "/t", v[1], "/d", v[2], "/f").Run()
	}
}
func uninstall() {
	closeRedPlay()
	dir := installDir()
	script := `$ErrorActionPreference='SilentlyContinue'; $desktop=[Environment]::GetFolderPath('Desktop'); $start=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'; Remove-Item (Join-Path $desktop 'RedPlay IPTV.lnk') -Force; Remove-Item (Join-Path $start 'RedPlay IPTV.lnk') -Force; Remove-Item (Join-Path $env:LOCALAPPDATA 'RedPlay IPTV\EngineNative') -Recurse -Force`
	_ = hidden("powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script).Run()
	_ = hidden("reg.exe", "DELETE", `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\RedPlayIPTV`, "/f").Run()
	cmd := fmt.Sprintf(`timeout /t 1 /nobreak >nul & rmdir /s /q "%s"`, dir)
	_ = hidden("cmd.exe", "/C", cmd).Start()
}
func fail(msg string) {
	script := fmt.Sprintf(`Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('%s','RedPlay IPTV Setup') | Out-Null`, psQuote(msg))
	_ = hidden("powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script).Run()
}
