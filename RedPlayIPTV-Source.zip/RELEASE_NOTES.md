## RedPlay IPTV 0.6.3

- Rebuilt the **Add IPTV provider** visual design to closely match the supplied dark mockup while keeping the existing owned-modal window architecture intact.
- Added the custom red TV mark, mockup-style header and close control, large rounded Name and M3U/M3U8 URL fields, GitHub-inspired dashed M3U drop zone, and matching Cancel / Save provider action row.
- Removed the optional EPG, User-Agent, and Referer fields from the visible provider form. Existing hidden EPG/header values remain preserved when editing the same source, so a UI-only edit does not silently destroy provider configuration.
- Added functional `.m3u` / `.m3u8` file browsing and drag-and-drop. Imported playlists are copied into RedPlay's private LocalAppData playlist folder so they remain available after the original file is moved or removed.
- Local M3U providers use the same playlist parser, EPG auto-detection, channel filtering, audio/subtitle behavior, and native mpv playback path as URL providers.
- The main RedPlay window is still disabled while the provider editor is open; mpv/videoHost ownership, playback overlays, and z-order behavior are unchanged.

## RedPlay IPTV 0.6.2

- Rebuilt the **Add IPTV provider** editor as a dedicated modal Windows dialog instead of an overlay made from child controls inside the main player window.
- The provider dialog is an owned top-level window, so mpv/video child-window z-order can no longer cover or split the form.
- The main RedPlay window is disabled while the provider dialog is open and restored when it closes.
- Added proper dialog keyboard routing for Tab navigation and Escape-to-close.
- Provider validation messages are owned by the provider dialog so they remain above the editor.
- No changes to playback, playlists, EPG, audio/subtitle selection, built-in Western/Star Wars providers, privacy controls, or updater behavior.
