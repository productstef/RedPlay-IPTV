## RedPlay IPTV 0.6.1

- Western and Star Wars are included as default providers on fresh installs.
- Existing users receive the built-in providers once on upgrade if they do not already have those playlist URLs; deleting a built-in provider afterwards stays deleted.
- Fixed the Add IPTV provider modal so embedded mpv video cannot cover the form.
- Background controls keep their prior enabled/disabled state while the Add Provider form is open.
- Add Provider validates playlist and EPG URLs and blocks duplicate playlist URLs.
- Custom unnamed providers start at Provider 1 even though built-in providers already exist.
- Existing playback, EPG, audio, subtitle sizing, privacy and in-app updater behavior remain unchanged.
