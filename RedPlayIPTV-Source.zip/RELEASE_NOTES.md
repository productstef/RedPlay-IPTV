# RedPlay IPTV 0.6.8

- Added VLC-style auto-hide behavior to the Library movie seek timeline.
- The seek bar is visible when Library playback begins, then hides after 2 seconds of mouse inactivity.
- Any mouse movement inside the RedPlay window reveals the timeline again and restarts the 2-second countdown.
- The bar remains visible while the scrubber is being dragged.
- Mouse movement is detected by polling the system cursor because mpv owns an embedded child window and can consume video-surface mouse messages.
- Live TV behavior is unchanged.

# RedPlay IPTV 0.6.7

- Fixed garbled Bulgarian Cyrillic in Library sidecar `.srt` subtitles.
- The Western live service already treated these legacy files as Windows-1251; direct Library playback previously handed the same bytes straight to mpv without that conversion.
- RedPlay now fetches a matching Library sidecar, detects/normalizes UTF-8, UTF-8 BOM, UTF-16 BOM, or legacy Windows-1251 text, writes a temporary UTF-8 `.srt`, and gives that normalized file to mpv.
- The temporary subtitle is removed when the Library playback context ends.
- Existing embedded subtitles, audio selection, live Western playback, mixed-extension movie resolution, double-click playback, and the 0.6.6 seek timeline are unchanged.

# RedPlay IPTV 0.6.6

- Added a VLC-style seek timeline for on-demand Library movies.
- The timeline shows current position and total movie duration.
- Click or drag the timeline to jump directly to any point in a Library movie.
- The seek timeline is Library-only; live TV behavior is unchanged.
- Keeps the 0.6.5 mixed-extension resolver and double-click-to-play behavior.

## RedPlay IPTV 0.6.5

- Fixed Western Library playback for mixed media archives. RedPlay no longer assumes every on-demand title is stored as `.mkv`.
- Before launching a library movie, RedPlay now checks the matching `.mkv`, `.mp4`, `.avi`, `.m4v`, and `.mov` URL on the existing Oracle/Nginx server and launches the first real file it finds.
- The check uses lightweight HEAD requests with a one-byte HTTP Range fallback, so it does not download the movie before playback.
- Existing sidecar `.srt` handling, embedded audio/subtitle tracks, live Western rotation, UI layout, and native mpv playback remain unchanged.
- Missing archive files now surface a clear Library playback error instead of silently handing mpv a guessed path.
- Library movie cards now support double-click to play immediately; single-click still selects a title and the Play movie button remains available.

## RedPlay IPTV 0.6.3

- Rebuilt the **Add IPTV provider** visual design to closely match the supplied dark mockup while keeping the existing owned-modal window architecture intact.
- Added the custom red TV mark, mockup-style header and close control, large rounded Name and M3U/M3U8 URL fields, GitHub-inspired dashed M3U drop zone, and matching Cancel / Save provider action row.
- Removed the optional EPG, User-Agent, and Referer fields from the visible provider form. Existing hidden EPG/header values remain preserved when editing the same source, so a UI-only edit does not silently destroy provider configuration.
- Added functional `.m3u` / `.m3u8` file browsing and drag-and-drop. Imported playlists are copied into RedPlay's private LocalAppData playlist folder so they remain available after the original file is moved or removed.
- Local M3U providers use the same playlist parser, EPG auto-detection, channel filtering, audio/subtitle behavior, and native mpv playback path as URL providers.
- The main RedPlay window is still disabled while the provider editor is open; mpv/videoHost ownership, playback overlays, and z-order behavior are unchanged.

## RedPlay IPTV 0.6.2

- Rebuilt the **Add IPTV provider** editor as a dedicated modal Windows dialog instead of an overlay made from child controls inside the main player window.
- The provider dialog is an owned top-level window, so mpv/video child-window z-order can no longer cover or split the form.
- The main RedPlay window is disabled while the provider dialog is open and restored when it closes.
- Added proper dialog keyboard routing for Tab navigation and Escape-to-close.
- Provider validation messages are owned by the provider dialog so they remain above the editor.
- No changes to playback, playlists, EPG, audio/subtitle selection, built-in Western/Star Wars providers, privacy controls, or updater behavior.
