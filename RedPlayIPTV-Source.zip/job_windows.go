//go:build windows

package main

import (
	"fmt"
	"unsafe"
)

var (
	procCreateJobObjectW         = kernel32.NewProc("CreateJobObjectW")
	procSetInformationJobObject  = kernel32.NewProc("SetInformationJobObject")
	procAssignProcessToJobObject = kernel32.NewProc("AssignProcessToJobObject")
	procOpenProcess              = kernel32.NewProc("OpenProcess")
	procCloseHandle              = kernel32.NewProc("CloseHandle")
)

const (
	jobObjectExtendedLimitInformation = 9
	jobObjectLimitKillOnJobClose      = 0x00002000
	processTerminate                  = 0x0001
	processSetQuota                   = 0x0100
)

type jobBasicLimitInformation struct {
	PerProcessUserTimeLimit int64
	PerJobUserTimeLimit     int64
	LimitFlags              uint32
	_                       uint32
	MinimumWorkingSetSize   uintptr
	MaximumWorkingSetSize   uintptr
	ActiveProcessLimit      uint32
	_2                      uint32
	Affinity                uintptr
	PriorityClass           uint32
	SchedulingClass         uint32
}
type ioCounters struct{ ReadOperationCount, WriteOperationCount, OtherOperationCount, ReadTransferCount, WriteTransferCount, OtherTransferCount uint64 }
type jobExtendedLimitInformation struct {
	BasicLimitInformation jobBasicLimitInformation
	IoInfo                ioCounters
	ProcessMemoryLimit    uintptr
	JobMemoryLimit        uintptr
	PeakProcessMemoryUsed uintptr
	PeakJobMemoryUsed     uintptr
}

func makeKillJob(pid int) (uintptr, error) {
	job, _, e := procCreateJobObjectW.Call(0, 0)
	if job == 0 {
		return 0, e
	}
	info := jobExtendedLimitInformation{}
	info.BasicLimitInformation.LimitFlags = jobObjectLimitKillOnJobClose
	ok, _, e := procSetInformationJobObject.Call(job, jobObjectExtendedLimitInformation, uintptr(unsafe.Pointer(&info)), unsafe.Sizeof(info))
	if ok == 0 {
		procCloseHandle.Call(job)
		return 0, fmt.Errorf("SetInformationJobObject: %v", e)
	}
	ph, _, e := procOpenProcess.Call(processTerminate|processSetQuota, 0, uintptr(uint32(pid)))
	if ph == 0 {
		procCloseHandle.Call(job)
		return 0, e
	}
	ok, _, e = procAssignProcessToJobObject.Call(job, ph)
	procCloseHandle.Call(ph)
	if ok == 0 {
		procCloseHandle.Call(job)
		return 0, e
	}
	return job, nil
}
func closeWinHandle(h uintptr) {
	if h != 0 {
		procCloseHandle.Call(h)
	}
}
