package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestProviderToEPGIntegration(t *testing.T) {
	var base string
	mux := http.NewServeMux()
	mux.HandleFunc("/playlist.m3u", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "audio/x-mpegurl")
		_, _ = w.Write([]byte(`#EXTM3U x-tvg-url="` + base + `/epg.xml"
#EXTINF:-1 tvg-id="live101" group-title="Live",Live 101
` + base + `/live/u/p/101.ts
#EXTINF:-1 tvg-id="hls102" group-title="Live",HLS 102
` + base + `/hls/102/index.m3u8
`))
	})
	mux.HandleFunc("/epg.xml", func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`<tv><channel id="live101"><display-name>Live 101</display-name></channel><programme channel="live101" start="20260908090000 +0300" stop="20260908110000 +0300"><title>Live programme</title></programme></tv>`))
	})
	srv := httptest.NewServer(mux)
	defer srv.Close()
	base = srv.URL
	text, err := FetchText(context.Background(), srv.URL+"/playlist.m3u", nil, 1<<20)
	if err != nil {
		t.Fatal(err)
	}
	pl := ParseM3U(text, srv.URL+"/playlist.m3u")
	if len(pl.Channels) != 2 {
		t.Fatalf("channels=%d", len(pl.Channels))
	}
	if !strings.HasSuffix(pl.Channels[0].URL, "/live/u/p/101.ts") {
		t.Fatalf("direct stream changed: %s", pl.Channels[0].URL)
	}
	body, err := OpenURL(context.Background(), pl.EPGURL, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer body.Close()
	epg, err := ParseXMLTV(body, time.Time{}, time.Time{})
	if err != nil {
		t.Fatal(err)
	}
	cur, _ := nowNextFor(pl.Channels[0], epg, time.Date(2026, 9, 8, 10, 0, 0, 0, time.FixedZone("EEST", 3*3600)))
	if cur == nil || cur.Title != "Live programme" {
		t.Fatalf("bad now: %+v", cur)
	}
}
