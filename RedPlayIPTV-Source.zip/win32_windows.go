//go:build windows

package main

import (
	"syscall"
	"unsafe"
)

var (
	user32                    = syscall.NewLazyDLL("user32.dll")
	gdi32                     = syscall.NewLazyDLL("gdi32.dll")
	kernel32                  = syscall.NewLazyDLL("kernel32.dll")
	dwmapi                    = syscall.NewLazyDLL("dwmapi.dll")
	uxtheme                   = syscall.NewLazyDLL("uxtheme.dll")
	procRegisterClassExW      = user32.NewProc("RegisterClassExW")
	procCreateWindowExW       = user32.NewProc("CreateWindowExW")
	procDefWindowProcW        = user32.NewProc("DefWindowProcW")
	procShowWindow            = user32.NewProc("ShowWindow")
	procUpdateWindow          = user32.NewProc("UpdateWindow")
	procGetMessageW           = user32.NewProc("GetMessageW")
	procTranslateMessage      = user32.NewProc("TranslateMessage")
	procIsDialogMessageW      = user32.NewProc("IsDialogMessageW")
	procDispatchMessageW      = user32.NewProc("DispatchMessageW")
	procPostQuitMessage       = user32.NewProc("PostQuitMessage")
	procPostMessageW          = user32.NewProc("PostMessageW")
	procSendMessageW          = user32.NewProc("SendMessageW")
	procMoveWindow            = user32.NewProc("MoveWindow")
	procGetClientRect         = user32.NewProc("GetClientRect")
	procSetWindowTextW        = user32.NewProc("SetWindowTextW")
	procGetWindowTextW        = user32.NewProc("GetWindowTextW")
	procGetWindowTextLengthW  = user32.NewProc("GetWindowTextLengthW")
	procDestroyWindow         = user32.NewProc("DestroyWindow")
	procMessageBoxW           = user32.NewProc("MessageBoxW")
	procSetTimer              = user32.NewProc("SetTimer")
	procKillTimer             = user32.NewProc("KillTimer")
	procLoadImageW            = user32.NewProc("LoadImageW")
	procLoadCursorW           = user32.NewProc("LoadCursorW")
	procSetFocus              = user32.NewProc("SetFocus")
	procEnableWindow          = user32.NewProc("EnableWindow")
	procInvalidateRect        = user32.NewProc("InvalidateRect")
	procGetWindowRect         = user32.NewProc("GetWindowRect")
	procGetWindowLongPtrW     = user32.NewProc("GetWindowLongPtrW")
	procSetWindowLongPtrW     = user32.NewProc("SetWindowLongPtrW")
	procSetWindowPos          = user32.NewProc("SetWindowPos")
	procIsWindowVisible       = user32.NewProc("IsWindowVisible")
	procIsWindowEnabled       = user32.NewProc("IsWindowEnabled")
	procMonitorFromWindow     = user32.NewProc("MonitorFromWindow")
	procGetMonitorInfoW       = user32.NewProc("GetMonitorInfoW")
	procBeginPaint            = user32.NewProc("BeginPaint")
	procEndPaint              = user32.NewProc("EndPaint")
	procFillRect              = user32.NewProc("FillRect")
	procDrawTextW             = user32.NewProc("DrawTextW")
	procCreateSolidBrush      = gdi32.NewProc("CreateSolidBrush")
	procCreatePen             = gdi32.NewProc("CreatePen")
	procCreateFontW           = gdi32.NewProc("CreateFontW")
	procSelectObject          = gdi32.NewProc("SelectObject")
	procDeleteObject          = gdi32.NewProc("DeleteObject")
	procRoundRect             = gdi32.NewProc("RoundRect")
	procSetTextColor          = gdi32.NewProc("SetTextColor")
	procSetBkColor            = gdi32.NewProc("SetBkColor")
	procSetBkMode             = gdi32.NewProc("SetBkMode")
	procGetStockObject        = gdi32.NewProc("GetStockObject")
	procGetModuleHandleW      = kernel32.NewProc("GetModuleHandleW")
	procCreateMutexW          = kernel32.NewProc("CreateMutexW")
	procGetLastError          = kernel32.NewProc("GetLastError")
	procCancelIoEx            = kernel32.NewProc("CancelIoEx")
	procRtlMoveMemory         = kernel32.NewProc("RtlMoveMemory")
	procDwmSetWindowAttribute = dwmapi.NewProc("DwmSetWindowAttribute")
	procSetWindowTheme        = uxtheme.NewProc("SetWindowTheme")
)

const (
	WS_OVERLAPPEDWINDOW           = 0x00CF0000
	WS_POPUP                      = 0x80000000
	WS_CHILD                      = 0x40000000
	WS_VISIBLE                    = 0x10000000
	WS_TABSTOP                    = 0x00010000
	WS_BORDER                     = 0x00800000
	WS_VSCROLL                    = 0x00200000
	WS_HSCROLL                    = 0x00100000
	WS_CLIPCHILDREN               = 0x02000000
	WS_CLIPSIBLINGS               = 0x04000000
	WS_EX_CLIENTEDGE              = 0x00000200
	WS_EX_DLGMODALFRAME           = 0x00000001
	WS_EX_CONTROLPARENT           = 0x00010000
	WS_CAPTION                    = 0x00C00000
	WS_THICKFRAME                 = 0x00040000
	WS_MINIMIZEBOX                = 0x00020000
	WS_MAXIMIZEBOX                = 0x00010000
	WS_SYSMENU                    = 0x00080000
	GWL_STYLE                     = -16
	SWP_NOSIZE                    = 0x0001
	SWP_NOMOVE                    = 0x0002
	SWP_NOACTIVATE                = 0x0010
	SWP_FRAMECHANGED              = 0x0020
	SWP_NOOWNERZORDER             = 0x0200
	MONITOR_DEFAULTTONEAREST      = 2
	CW_USEDEFAULT                 = 0x80000000
	SW_SHOW                       = 5
	SW_HIDE                       = 0
	WM_CREATE                     = 0x0001
	WM_PAINT                      = 0x000F
	WM_ERASEBKGND                 = 0x0014
	WM_MEASUREITEM                = 0x002C
	WM_DRAWITEM                   = 0x002B
	WM_DESTROY                    = 0x0002
	WM_SIZE                       = 0x0005
	WM_CLOSE                      = 0x0010
	WM_SETFONT                    = 0x0030
	WM_SETICON                    = 0x0080
	WM_COMMAND                    = 0x0111
	WM_TIMER                      = 0x0113
	WM_CTLCOLORMSGBOX             = 0x0132
	WM_CTLCOLOREDIT               = 0x0133
	WM_CTLCOLORLISTBOX            = 0x0134
	WM_CTLCOLORBTN                = 0x0135
	WM_CTLCOLORDLG                = 0x0136
	WM_CTLCOLORSCROLLBAR          = 0x0137
	WM_CTLCOLORSTATIC             = 0x0138
	WM_APP                        = 0x8000
	WM_KEYDOWN                    = 0x0100
	VK_F11                        = 0x7A
	VK_ESCAPE                     = 0x1B
	MB_OK                         = 0x00000000
	MB_ICONERROR                  = 0x00000010
	MB_ICONINFORMATION            = 0x00000040
	MB_YESNO                      = 0x00000004
	MB_ICONQUESTION               = 0x00000020
	IDYES                         = 6
	IMAGE_ICON                    = 1
	LR_LOADFROMFILE               = 0x0010
	LR_DEFAULTSIZE                = 0x0040
	ICON_SMALL                    = 0
	ICON_BIG                      = 1
	DEFAULT_GUI_FONT              = 17
	TRANSPARENT                   = 1
	COLOR_WINDOW                  = 5
	ES_AUTOHSCROLL                = 0x0080
	EM_SETCUEBANNER               = 0x1501
	EM_SETMARGINS                 = 0x00D3
	EC_LEFTMARGIN                 = 0x0001
	EC_RIGHTMARGIN                = 0x0002
	ES_MULTILINE                  = 0x0004
	ES_AUTOVSCROLL                = 0x0040
	ES_READONLY                   = 0x0800
	BS_PUSHBUTTON                 = 0x00000000
	BS_OWNERDRAW                  = 0x0000000B
	BS_FLAT                       = 0x00008000
	BS_AUTOCHECKBOX               = 0x00000003
	BST_CHECKED                   = 1
	BST_UNCHECKED                 = 0
	BM_GETCHECK                   = 0x00F0
	BM_SETCHECK                   = 0x00F1
	CBS_DROPDOWNLIST              = 0x0003
	CBN_SELCHANGE                 = 1
	LBS_NOTIFY                    = 0x0001
	LBS_OWNERDRAWFIXED            = 0x0010
	LBS_HASSTRINGS                = 0x0040
	LBS_NOINTEGRALHEIGHT          = 0x0100
	LB_ERR                        = -1
	LB_ADDSTRING                  = 0x0180
	LB_RESETCONTENT               = 0x0184
	LB_SETCURSEL                  = 0x0186
	LB_GETCURSEL                  = 0x0188
	LB_INITSTORAGE                = 0x01A8
	LB_GETTEXT                    = 0x0189
	LB_GETTEXTLEN                 = 0x018A
	LB_SETITEMHEIGHT              = 0x01A0
	LB_DBLCLK                     = 2
	LB_SELCHANGE                  = 1
	CB_ADDSTRING                  = 0x0143
	CB_RESETCONTENT               = 0x014B
	CB_GETCURSEL                  = 0x0147
	CB_SETCURSEL                  = 0x014E
	BN_CLICKED                    = 0
	EN_CHANGE                     = 0x0300
	SS_LEFT                       = 0x0000
	SS_CENTER                     = 0x0001
	SS_BLACKRECT                  = 0x0004
	ERROR_ALREADY_EXISTS          = 183
	IDC_ARROW                     = 32512
	PS_SOLID                      = 0
	FW_NORMAL                     = 400
	FW_SEMIBOLD                   = 600
	DT_LEFT                       = 0x0000
	DT_CENTER                     = 0x0001
	DT_VCENTER                    = 0x0004
	DT_SINGLELINE                 = 0x0020
	DT_END_ELLIPSIS               = 0x00008000
	DT_NOPREFIX                   = 0x00000800
	ODS_SELECTED                  = 0x0001
	DWMWA_USE_IMMERSIVE_DARK_MODE = 20
)

type WNDCLASSEX struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}
type POINT struct{ X, Y int32 }
type RECT struct{ Left, Top, Right, Bottom int32 }
type MONITORINFO struct {
	CbSize    uint32
	RcMonitor RECT
	RcWork    RECT
	DwFlags   uint32
}
type MSG struct {
	Hwnd     uintptr
	Message  uint32
	WParam   uintptr
	LParam   uintptr
	Time     uint32
	Pt       POINT
	LPrivate uint32
}

type PAINTSTRUCT struct {
	Hdc         uintptr
	FErase      int32
	RcPaint     RECT
	FRestore    int32
	FIncUpdate  int32
	RgbReserved [32]byte
}

type DRAWITEMSTRUCT struct {
	CtlType    uint32
	CtlID      uint32
	ItemID     uint32
	ItemAction uint32
	ItemState  uint32
	HwndItem   uintptr
	HDC        uintptr
	RcItem     RECT
	ItemData   uintptr
}

func utf16p(s string) *uint16        { p, _ := syscall.UTF16PtrFromString(s); return p }
func rgb(r, g, b byte) uintptr       { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }
func loWord(v uintptr) uint16        { return uint16(v & 0xffff) }
func hiWord(v uintptr) uint16        { return uint16((v >> 16) & 0xffff) }
func makeLong(lo, hi uint16) uintptr { return uintptr(lo) | uintptr(hi)<<16 }
func setText(hwnd uintptr, s string) {
	procSetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(utf16p(s))))
}
func getText(hwnd uintptr) string {
	n, _, _ := procGetWindowTextLengthW.Call(hwnd)
	if n == 0 {
		return ""
	}
	buf := make([]uint16, n+1)
	procGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), n+1)
	return syscall.UTF16ToString(buf)
}
func move(hwnd uintptr, x, y, w, h int) {
	if hwnd != 0 {
		procMoveWindow.Call(hwnd, uintptr(x), uintptr(y), uintptr(w), uintptr(h), 1)
	}
}
func show(hwnd uintptr, on bool) {
	if hwnd == 0 {
		return
	}
	c := uintptr(SW_HIDE)
	if on {
		c = SW_SHOW
	}
	procShowWindow.Call(hwnd, c)
}
func send(hwnd uintptr, msg uint32, w, l uintptr) uintptr {
	r, _, _ := procSendMessageW.Call(hwnd, uintptr(msg), w, l)
	return r
}
func post(hwnd uintptr, msg uint32, w, l uintptr) { procPostMessageW.Call(hwnd, uintptr(msg), w, l) }
func messageBox(owner uintptr, title, text string, flags uintptr) int {
	r, _, _ := procMessageBoxW.Call(owner, uintptr(unsafe.Pointer(utf16p(text))), uintptr(unsafe.Pointer(utf16p(title))), flags)
	return int(r)
}

func createControl(exStyle uintptr, class, text string, style uintptr, x, y, w, h int, parent uintptr, id int) uintptr {
	hnd, _, _ := procCreateWindowExW.Call(exStyle, uintptr(unsafe.Pointer(utf16p(class))), uintptr(unsafe.Pointer(utf16p(text))), style, uintptr(x), uintptr(y), uintptr(w), uintptr(h), parent, uintptr(id), 0, 0)
	if hnd != 0 {
		font, _, _ := procGetStockObject.Call(DEFAULT_GUI_FONT)
		send(hnd, WM_SETFONT, font, 1)
	}
	return hnd
}

func createFont(height, weight int, face string) uintptr {
	h, _, _ := procCreateFontW.Call(
		uintptr(^uintptr(height-1)), 0, 0, 0, uintptr(weight), 0, 0, 0, 0, 0, 0, 0, 0,
		uintptr(unsafe.Pointer(utf16p(face))),
	)
	return h
}

func setFont(hwnd, font uintptr) {
	if hwnd != 0 && font != 0 {
		send(hwnd, WM_SETFONT, font, 1)
	}
}

func fillSolid(hdc uintptr, rc RECT, color uintptr) {
	brush, _, _ := procCreateSolidBrush.Call(color)
	procFillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), brush)
	procDeleteObject.Call(brush)
}

func drawRoundRect(hdc uintptr, rc RECT, fillColor, borderColor uintptr, radius int) {
	brush, _, _ := procCreateSolidBrush.Call(fillColor)
	pen, _, _ := procCreatePen.Call(PS_SOLID, 1, borderColor)
	oldBrush, _, _ := procSelectObject.Call(hdc, brush)
	oldPen, _, _ := procSelectObject.Call(hdc, pen)
	procRoundRect.Call(hdc, uintptr(rc.Left), uintptr(rc.Top), uintptr(rc.Right), uintptr(rc.Bottom), uintptr(radius), uintptr(radius))
	procSelectObject.Call(hdc, oldBrush)
	procSelectObject.Call(hdc, oldPen)
	procDeleteObject.Call(brush)
	procDeleteObject.Call(pen)
}

func drawTextRect(hdc uintptr, rc RECT, text string, color uintptr, format uint32) {
	procSetTextColor.Call(hdc, color)
	procSetBkMode.Call(hdc, TRANSPARENT)
	buf := syscall.StringToUTF16(text)
	procDrawTextW.Call(hdc, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)-1), uintptr(unsafe.Pointer(&rc)), uintptr(format))
}

func getWindowStyle(hwnd uintptr) uintptr {
	idx := int32(GWL_STYLE)
	r, _, _ := procGetWindowLongPtrW.Call(hwnd, uintptr(idx))
	return r
}

func setWindowStyle(hwnd, style uintptr) {
	idx := int32(GWL_STYLE)
	procSetWindowLongPtrW.Call(hwnd, uintptr(idx), style)
}

func nearestMonitorRect(hwnd uintptr) (RECT, bool) {
	mon, _, _ := procMonitorFromWindow.Call(hwnd, MONITOR_DEFAULTTONEAREST)
	if mon == 0 {
		return RECT{}, false
	}
	mi := MONITORINFO{CbSize: uint32(unsafe.Sizeof(MONITORINFO{}))}
	ok, _, _ := procGetMonitorInfoW.Call(mon, uintptr(unsafe.Pointer(&mi)))
	if ok == 0 {
		return RECT{}, false
	}
	return mi.RcMonitor, true
}

func setWindowPos(hwnd uintptr, x, y, w, h int, flags uintptr) {
	procSetWindowPos.Call(hwnd, 0, uintptr(x), uintptr(y), uintptr(w), uintptr(h), flags)
}

func raiseWindow(hwnd uintptr) {
	if hwnd == 0 {
		return
	}
	procSetWindowPos.Call(hwnd, 0, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOOWNERZORDER)
}

func isWindowVisible(hwnd uintptr) bool {
	if hwnd == 0 {
		return false
	}
	r, _, _ := procIsWindowVisible.Call(hwnd)
	return r != 0
}

func isWindowEnabled(hwnd uintptr) bool {
	if hwnd == 0 {
		return false
	}
	r, _, _ := procIsWindowEnabled.Call(hwnd)
	return r != 0
}

func enableDarkMode(hwnd uintptr) {
	if hwnd == 0 {
		return
	}
	v := int32(1)
	procDwmSetWindowAttribute.Call(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, uintptr(unsafe.Pointer(&v)), unsafe.Sizeof(v))
	procSetWindowTheme.Call(hwnd, uintptr(unsafe.Pointer(utf16p("DarkMode_Explorer"))), 0)
}

func setDarkTheme(hwnd uintptr) {
	if hwnd != 0 {
		procSetWindowTheme.Call(hwnd, uintptr(unsafe.Pointer(utf16p("DarkMode_Explorer"))), 0)
	}
}

func listBoxText(hwnd uintptr, index int) string {
	if hwnd == 0 || index < 0 {
		return ""
	}
	n := int(send(hwnd, LB_GETTEXTLEN, uintptr(index), 0))
	if n <= 0 {
		return ""
	}
	buf := make([]uint16, n+1)
	send(hwnd, LB_GETTEXT, uintptr(index), uintptr(unsafe.Pointer(&buf[0])))
	return syscall.UTF16ToString(buf)
}
