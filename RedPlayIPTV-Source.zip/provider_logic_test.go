package main

import "testing"

func TestNormalizeProviderURL(t *testing.T) {
	got, err := normalizeProviderURL(" HTTPS://Example.COM/list.m3u#frag ")
	if err != nil {
		t.Fatal(err)
	}
	if got != "https://example.com/list.m3u" {
		t.Fatalf("got %q", got)
	}
	for _, bad := range []string{"", "ftp://example.com/list.m3u", "not-a-url", "http:///missing-host"} {
		if _, err := normalizeProviderURL(bad); err == nil {
			t.Fatalf("expected error for %q", bad)
		}
	}
}

func TestFindProviderByURLPreventsDuplicateAdd(t *testing.T) {
	providers := []Provider{{ID: "p1", Name: "One", URL: "https://Example.com/list.m3u"}}
	idx, ok := findProviderByURL(providers, "https://example.com/list.m3u#ignored")
	if !ok || idx != 0 {
		t.Fatalf("idx=%d ok=%v", idx, ok)
	}
	if _, ok := findProviderByURL(providers, "https://example.com/other.m3u"); ok {
		t.Fatal("different playlist treated as duplicate")
	}
}

func TestDefaultStateIncludesBuiltInChannels(t *testing.T) {
	s := defaultState()
	if len(s.Providers) != 2 {
		t.Fatalf("default providers = %d, want 2", len(s.Providers))
	}
	if s.Providers[0].ID != "builtin-western" || s.Providers[0].Name != "Western" {
		t.Fatalf("unexpected first provider: %+v", s.Providers[0])
	}
	if s.Providers[1].ID != "builtin-starwars" || s.Providers[1].Name != "Star Wars" {
		t.Fatalf("unexpected second provider: %+v", s.Providers[1])
	}
	if s.LastProvider != "builtin-western" {
		t.Fatalf("LastProvider = %q", s.LastProvider)
	}
}

func TestNextProviderNameIgnoresBuiltInCount(t *testing.T) {
	providers := builtInProviders()
	if got := nextProviderName(providers); got != "Provider 1" {
		t.Fatalf("got %q", got)
	}
	providers = append(providers, Provider{Name: "Provider 1"})
	if got := nextProviderName(providers); got != "Provider 2" {
		t.Fatalf("got %q", got)
	}
}
