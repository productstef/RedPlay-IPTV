package main

import (
	"context"
	"encoding/xml"
	"fmt"
	"io"
	"sort"
	"strings"
	"time"
	"unicode/utf8"
)

type contextReader struct {
	ctx context.Context
	r   io.Reader
}

func (r contextReader) Read(p []byte) (int, error) {
	if err := r.ctx.Err(); err != nil {
		return 0, err
	}
	n, err := r.r.Read(p)
	if n == 0 {
		if ctxErr := r.ctx.Err(); ctxErr != nil {
			return 0, ctxErr
		}
	}
	return n, err
}

// singleByteUTF8Reader converts legacy single-byte XMLTV encodings to UTF-8
// incrementally. The previous implementation io.ReadAll'ed the entire EPG in
// CharsetReader, which could create a very large transient allocation.
type singleByteUTF8Reader struct {
	src     io.Reader
	mode    string
	pending []byte
	readErr error
}

func windows1251Rune(by byte) rune {
	if by < 0x80 {
		return rune(by)
	}
	if by >= 0xC0 {
		return rune('А') + rune(by-0xC0)
	}
	table := []rune{
		'Ђ', 'Ѓ', '‚', 'ѓ', '„', '…', '†', '‡', '€', '‰', 'Љ', '‹', 'Њ', 'Ќ', 'Ћ', 'Џ',
		'ђ', '‘', '’', '“', '”', '•', '–', '—', '�', '™', 'љ', '›', 'њ', 'ќ', 'ћ', 'џ',
		'\u00a0', 'Ў', 'ў', 'Ј', '¤', 'Ґ', '¦', '§', 'Ё', '©', 'Є', '«', '¬', '\u00ad', '®', 'Ї',
		'°', '±', 'І', 'і', 'ґ', 'µ', '¶', '·', 'ё', '№', 'є', '»', 'ј', 'Ѕ', 'ѕ', 'ї',
	}
	idx := int(by) - 0x80
	if idx >= 0 && idx < len(table) {
		return table[idx]
	}
	return '�'
}

func (r *singleByteUTF8Reader) Read(p []byte) (int, error) {
	for len(r.pending) == 0 && r.readErr == nil {
		buf := make([]byte, 4096)
		n, err := r.src.Read(buf)
		if n > 0 {
			out := make([]byte, 0, n*2)
			for _, by := range buf[:n] {
				var rr rune
				if r.mode == "latin1" {
					rr = rune(by)
				} else {
					rr = windows1251Rune(by)
				}
				out = utf8.AppendRune(out, rr)
			}
			r.pending = out
		}
		if err != nil {
			r.readErr = err
		}
		if n == 0 && err == nil {
			continue
		}
	}
	if len(r.pending) > 0 {
		n := copy(p, r.pending)
		r.pending = r.pending[n:]
		return n, nil
	}
	return 0, r.readErr
}

func parseXMLTVTime(raw string) (time.Time, bool) {
	raw = strings.TrimSpace(raw)
	if len(raw) < 12 {
		return time.Time{}, false
	}
	base := raw
	zone := ""
	if i := strings.IndexAny(raw, " +-Zz"); i >= 0 {
		base = strings.TrimSpace(raw[:i])
		zone = strings.TrimSpace(raw[i:])
	}
	layouts := []string{"20060102150405", "200601021504"}
	for _, layout := range layouts {
		if len(base) != len(layout) {
			continue
		}
		if zone == "" {
			if t, e := time.ParseInLocation(layout, base, time.Local); e == nil {
				return t, true
			}
		}
		if zone == "Z" || zone == "z" {
			if t, e := time.ParseInLocation(layout, base, time.UTC); e == nil {
				return t, true
			}
		}
		zone = strings.ReplaceAll(zone, ":", "")
		if len(zone) >= 5 && (zone[0] == '+' || zone[0] == '-') {
			if t, e := time.Parse(layout+" -0700", base+" "+zone[:5]); e == nil {
				return t, true
			}
		}
	}
	return time.Time{}, false
}

func ParseXMLTV(r io.Reader, minTime, maxTime time.Time) (EPGData, error) {
	return ParseXMLTVContext(context.Background(), r, minTime, maxTime)
}

func ParseXMLTVContext(ctx context.Context, r io.Reader, minTime, maxTime time.Time) (EPGData, error) {
	d := EPGData{DisplayNames: map[string][]string{}, Programmes: map[string][]Programme{}, NameToIDs: map[string][]string{}}
	dec := xml.NewDecoder(contextReader{ctx: ctx, r: r})
	dec.CharsetReader = func(charset string, input io.Reader) (io.Reader, error) {
		switch strings.ToLower(strings.TrimSpace(charset)) {
		case "utf-8", "utf8":
			return input, nil
		case "windows-1251", "cp1251", "windows1251":
			return &singleByteUTF8Reader{src: input, mode: "windows1251"}, nil
		case "iso-8859-1", "latin1", "latin-1":
			return &singleByteUTF8Reader{src: input, mode: "latin1"}, nil
		default:
			return nil, fmt.Errorf("unsupported XMLTV charset %q", charset)
		}
	}
	for {
		if err := ctx.Err(); err != nil {
			return d, err
		}
		tok, err := dec.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			return d, err
		}
		se, ok := tok.(xml.StartElement)
		if !ok {
			continue
		}
		switch se.Name.Local {
		case "channel":
			var x struct {
				ID    string   `xml:"id,attr"`
				Names []string `xml:"display-name"`
			}
			if err := dec.DecodeElement(&x, &se); err != nil {
				return d, err
			}
			x.ID = strings.TrimSpace(x.ID)
			if x.ID == "" {
				continue
			}
			for i := range x.Names {
				x.Names[i] = strings.TrimSpace(x.Names[i])
				if x.Names[i] != "" {
					n := normalizeName(x.Names[i])
					if n != "" {
						d.NameToIDs[n] = appendUnique(d.NameToIDs[n], x.ID)
					}
				}
			}
			d.DisplayNames[x.ID] = x.Names
		case "programme":
			var x struct {
				Channel, Start, Stop string `xml:"-"`
				Title                string `xml:"title"`
				SubTitle             string `xml:"sub-title"`
				Desc                 string `xml:"desc"`
				Category             string `xml:"category"`
			}
			for _, a := range se.Attr {
				switch a.Name.Local {
				case "channel":
					x.Channel = a.Value
				case "start":
					x.Start = a.Value
				case "stop":
					x.Stop = a.Value
				}
			}
			if err := dec.DecodeElement(&x, &se); err != nil {
				return d, err
			}
			st, ok := parseXMLTVTime(x.Start)
			if !ok {
				continue
			}
			sp, ok := parseXMLTVTime(x.Stop)
			if !ok {
				sp = st.Add(2 * time.Hour)
			}
			if !minTime.IsZero() && sp.Before(minTime) {
				continue
			}
			if !maxTime.IsZero() && st.After(maxTime) {
				continue
			}
			p := Programme{ChannelID: strings.TrimSpace(x.Channel), Start: st, Stop: sp, Title: strings.TrimSpace(x.Title), SubTitle: strings.TrimSpace(x.SubTitle), Desc: strings.TrimSpace(x.Desc), Category: strings.TrimSpace(x.Category)}
			if p.Title == "" {
				p.Title = "Untitled programme"
			}
			d.Programmes[p.ChannelID] = append(d.Programmes[p.ChannelID], p)
		}
	}
	for id := range d.Programmes {
		if err := ctx.Err(); err != nil {
			return d, err
		}
		sort.Slice(d.Programmes[id], func(i, j int) bool { return d.Programmes[id][i].Start.Before(d.Programmes[id][j].Start) })
	}
	return d, nil
}

func appendUnique(a []string, v string) []string {
	for _, x := range a {
		if x == v {
			return a
		}
	}
	return append(a, v)
}

func matchEPGChannel(c Channel, d EPGData) string {
	if c.TVGID != "" {
		if _, ok := d.Programmes[c.TVGID]; ok {
			return c.TVGID
		}
		if _, ok := d.DisplayNames[c.TVGID]; ok {
			return c.TVGID
		}
	}
	cands := []string{c.TVGName, c.Name}
	for _, name := range cands {
		n := normalizeName(name)
		if ids := d.NameToIDs[n]; len(ids) == 1 {
			return ids[0]
		}
	}
	return ""
}

func nowNextFor(c Channel, d EPGData, now time.Time) (*Programme, *Programme) {
	id := matchEPGChannel(c, d)
	if id == "" {
		return nil, nil
	}
	arr := d.Programmes[id]
	var cur, nxt *Programme
	for i := range arr {
		p := &arr[i]
		if (now.Equal(p.Start) || now.After(p.Start)) && now.Before(p.Stop) {
			cp := *p
			cur = &cp
			if i+1 < len(arr) {
				np := arr[i+1]
				nxt = &np
			}
			break
		}
		if p.Start.After(now) {
			np := *p
			nxt = &np
			break
		}
	}
	return cur, nxt
}
