//go:build windows

package main

import (
	"fmt"
	"os"
	"unsafe"
)

func main() {
	// Per-user single instance prevents multiple players fighting over state/audio.
	name := utf16p("Local\\RedPlayIPTVNative-0.5")
	h, _, _ := procCreateMutexW.Call(0, 0, uintptr(unsafe.Pointer(name)))
	if h != 0 {
		defer closeWinHandle(h)
	}
	last, _, _ := procGetLastError.Call()
	if h != 0 && last == ERROR_ALREADY_EXISTS {
		messageBox(0, "RedPlay IPTV", "RedPlay IPTV is already running.", MB_OK|MB_ICONINFORMATION)
		return
	}
	if err := runNativeUI(); err != nil {
		messageBox(0, "RedPlay IPTV", fmt.Sprintf("Could not start RedPlay IPTV:\r\n%s", err), MB_OK|MB_ICONERROR)
		os.Exit(1)
	}
}
