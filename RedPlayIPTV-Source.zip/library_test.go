package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestBuildWesternLibraryFromEPG(t *testing.T) {
	start := time.Date(2026, 9, 17, 10, 0, 0, 0, time.UTC)
	ch := Channel{ID: "western", Name: "Western Channel", TVGID: "western-channel", Group: "Movies"}
	pl := Playlist{Channels: []Channel{ch}}
	epg := EPGData{
		DisplayNames: map[string][]string{"western-channel": []string{"Western Channel"}},
		Programmes: map[string][]Programme{
			"western-channel": []Programme{
				{ChannelID: "western-channel", Start: start, Stop: start.Add(99 * time.Minute), Title: "A Fistful of Dollars (1964)"},
				{ChannelID: "western-channel", Start: start.Add(99 * time.Minute), Stop: start.Add(210 * time.Minute), Title: "High Noon (1952)"},
				{ChannelID: "western-channel", Start: start.Add(210 * time.Minute), Stop: start.Add(309 * time.Minute), Title: "A Fistful of Dollars (1964)"},
			},
		},
		NameToIDs: map[string][]string{},
	}
	provider := Provider{Name: "Western", URL: "http://92.5.59.81/western/playlist.m3u"}
	lib, err := BuildWesternLibrary(provider, pl, epg)
	if err != nil {
		t.Fatal(err)
	}
	if len(lib.Movies) != 2 {
		t.Fatalf("got %d movies, want 2", len(lib.Movies))
	}
	if lib.Movies[0].DisplayTitle != "A Fistful of Dollars" || lib.Movies[0].Year != "1964" {
		t.Fatalf("unexpected first movie: %#v", lib.Movies[0])
	}
	if !strings.Contains(lib.Movies[0].URL, "/videos/western/A%20Fistful%20of%20Dollars%20%281964%29.mkv") {
		t.Fatalf("unexpected video URL: %s", lib.Movies[0].URL)
	}
	if len(lib.Movies[0].CandidateURLs) != len(westernMovieExtensions) {
		t.Fatalf("got %d media candidates, want %d", len(lib.Movies[0].CandidateURLs), len(westernMovieExtensions))
	}
	if !strings.HasSuffix(lib.Movies[0].SubtitleURL, ".srt") {
		t.Fatalf("unexpected subtitle URL: %s", lib.Movies[0].SubtitleURL)
	}
	if got := formatLibraryDuration(lib.Movies[0].Duration); got != "99 min" {
		t.Fatalf("duration = %q", got)
	}
}

func TestBuildWesternLibraryRequiresHTTPProvider(t *testing.T) {
	ch := Channel{Name: "Western Channel", TVGID: "western-channel"}
	pl := Playlist{Channels: []Channel{ch}}
	epg := EPGData{
		Programmes: map[string][]Programme{
			"western-channel": []Programme{{Title: "High Noon (1952)"}},
		},
		DisplayNames: map[string][]string{},
		NameToIDs:    map[string][]string{},
	}
	_, err := BuildWesternLibrary(Provider{URL: "file:///tmp/western.m3u"}, pl, epg)
	if err == nil {
		t.Fatal("expected error for local provider")
	}
}

func TestResolveLibraryMovieURLFallsBackToMP4(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/videos/western/High Noon (1952).mkv":
			http.NotFound(w, r)
		case "/videos/western/High Noon (1952).mp4":
			w.Header().Set("Accept-Ranges", "bytes")
			w.WriteHeader(http.StatusOK)
		default:
			http.NotFound(w, r)
		}
	}))
	defer ts.Close()

	candidates, err := directWesternMovieCandidates(ts.URL+"/western/playlist.m3u", "High Noon (1952)")
	if err != nil {
		t.Fatal(err)
	}
	movie := LibraryMovie{DisplayTitle: "High Noon", URL: candidates[0], CandidateURLs: candidates}
	got, err := resolveLibraryMovieURL(context.Background(), movie, nil)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.HasSuffix(got, "/videos/western/High%20Noon%20%281952%29.mp4") {
		t.Fatalf("resolved URL = %q", got)
	}
}

func TestResolveLibraryMovieURLReportsMissingFile(t *testing.T) {
	ts := httptest.NewServer(http.NotFoundHandler())
	defer ts.Close()
	candidates, err := directWesternMovieCandidates(ts.URL+"/western/playlist.m3u", "Missing Movie (1960)")
	if err != nil {
		t.Fatal(err)
	}
	_, err = resolveLibraryMovieURL(context.Background(), LibraryMovie{DisplayTitle: "Missing Movie", CandidateURLs: candidates}, nil)
	if err == nil || !strings.Contains(err.Error(), "not found") {
		t.Fatalf("expected missing-file error, got %v", err)
	}
}
