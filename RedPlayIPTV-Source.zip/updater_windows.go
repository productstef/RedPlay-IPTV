//go:build windows

package main

import (
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

const (
	appVersion        = "0.6.8"
	updateRepo        = "productstef/RedPlay-IPTV"
	updateAPIURL      = "https://api.github.com/repos/" + updateRepo + "/releases/latest"
	updateUserAgent   = "RedPlay-IPTV/" + appVersion
	updateHTTPTimeout = 30 * time.Second
)

type updateAsset struct {
	Name               string `json:"name"`
	BrowserDownloadURL string `json:"browser_download_url"`
}

type githubRelease struct {
	TagName string        `json:"tag_name"`
	Name    string        `json:"name"`
	Body    string        `json:"body"`
	Assets  []updateAsset `json:"assets"`
}

type updateInfo struct {
	Version       string
	Notes         string
	InstallerName string
	InstallerURL  string
	ChecksumURL   string
}

func normalizeVersion(v string) string {
	v = strings.TrimSpace(v)
	v = strings.TrimPrefix(strings.ToLower(v), "v")
	return v
}

func versionParts(v string) []int {
	v = normalizeVersion(v)
	base := strings.SplitN(v, "-", 2)[0]
	chunks := strings.Split(base, ".")
	out := make([]int, 0, len(chunks))
	for _, c := range chunks {
		n, err := strconv.Atoi(c)
		if err != nil {
			return nil
		}
		out = append(out, n)
	}
	return out
}

func isNewerVersion(current, latest string) bool {
	a := versionParts(current)
	b := versionParts(latest)
	if len(a) == 0 || len(b) == 0 {
		return false
	}
	n := len(a)
	if len(b) > n {
		n = len(b)
	}
	for i := 0; i < n; i++ {
		av, bv := 0, 0
		if i < len(a) {
			av = a[i]
		}
		if i < len(b) {
			bv = b[i]
		}
		if bv != av {
			return bv > av
		}
	}
	return false
}

func updateRequest(ctx context.Context, rawURL string) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, rawURL, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", updateUserAgent)
	req.Header.Set("Accept", "application/vnd.github+json")
	client := &http.Client{Timeout: updateHTTPTimeout}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		defer resp.Body.Close()
		return nil, fmt.Errorf("update server returned HTTP %d", resp.StatusCode)
	}
	return resp, nil
}

func checkForUpdate(ctx context.Context) (updateInfo, error) {
	resp, err := updateRequest(ctx, updateAPIURL)
	if err != nil {
		return updateInfo{}, err
	}
	defer resp.Body.Close()

	var rel githubRelease
	if err := json.NewDecoder(io.LimitReader(resp.Body, 2<<20)).Decode(&rel); err != nil {
		return updateInfo{}, fmt.Errorf("invalid update response: %w", err)
	}
	latest := normalizeVersion(rel.TagName)
	if latest == "" {
		return updateInfo{}, fmt.Errorf("latest release has no version tag")
	}

	info := updateInfo{Version: latest, Notes: strings.TrimSpace(rel.Body)}
	for _, asset := range rel.Assets {
		low := strings.ToLower(asset.Name)
		switch {
		case strings.HasPrefix(low, "redplayiptv-setup-") && strings.HasSuffix(low, ".exe"):
			info.InstallerName = asset.Name
			info.InstallerURL = asset.BrowserDownloadURL
		case low == "sha256sums.txt":
			info.ChecksumURL = asset.BrowserDownloadURL
		}
	}
	if isNewerVersion(appVersion, latest) && (info.InstallerURL == "" || info.ChecksumURL == "") {
		return updateInfo{}, fmt.Errorf("release v%s is missing updater assets", latest)
	}
	return info, nil
}

func readExpectedSHA256(ctx context.Context, rawURL, installerName string) (string, error) {
	resp, err := updateRequest(ctx, rawURL)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	s := bufio.NewScanner(io.LimitReader(resp.Body, 256<<10))
	for s.Scan() {
		line := strings.TrimSpace(s.Text())
		if line == "" {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) < 2 {
			continue
		}
		name := strings.TrimPrefix(fields[len(fields)-1], "*")
		if strings.EqualFold(filepath.Base(name), filepath.Base(installerName)) {
			hash := strings.ToLower(fields[0])
			if len(hash) == 64 {
				if _, err := hex.DecodeString(hash); err == nil {
					return hash, nil
				}
			}
		}
	}
	if err := s.Err(); err != nil {
		return "", err
	}
	return "", fmt.Errorf("installer checksum not found")
}

func downloadUpdate(ctx context.Context, info updateInfo) (string, error) {
	expected, err := readExpectedSHA256(ctx, info.ChecksumURL, info.InstallerName)
	if err != nil {
		return "", err
	}
	resp, err := updateRequest(ctx, info.InstallerURL)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	path := filepath.Join(os.TempDir(), fmt.Sprintf("RedPlayIPTV-Update-%s.exe", info.Version))
	f, err := os.Create(path)
	if err != nil {
		return "", err
	}
	h := sha256.New()
	_, copyErr := io.Copy(io.MultiWriter(f, h), resp.Body)
	closeErr := f.Close()
	if copyErr != nil {
		_ = os.Remove(path)
		return "", copyErr
	}
	if closeErr != nil {
		_ = os.Remove(path)
		return "", closeErr
	}
	actual := hex.EncodeToString(h.Sum(nil))
	if !strings.EqualFold(actual, expected) {
		_ = os.Remove(path)
		return "", fmt.Errorf("download checksum verification failed")
	}
	return path, nil
}

func launchUpdateInstaller(path string) error {
	cmd := exec.Command(path)
	return cmd.Start()
}
