package main

import (
	"archive/zip"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

func fileSHA256(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

func extractZipSafe(zipPath, dest string) error {
	r, err := zip.OpenReader(zipPath)
	if err != nil {
		return err
	}
	defer r.Close()
	root, err := filepath.Abs(dest)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(root, 0755); err != nil {
		return err
	}
	for _, f := range r.File {
		clean := filepath.Clean(f.Name)
		if clean == "." || filepath.IsAbs(clean) || clean == ".." || strings.HasPrefix(clean, ".."+string(os.PathSeparator)) {
			return fmt.Errorf("unsafe zip entry %q", f.Name)
		}
		target := filepath.Join(root, clean)
		targetAbs, err := filepath.Abs(target)
		if err != nil {
			return err
		}
		if targetAbs != root && !strings.HasPrefix(targetAbs, root+string(os.PathSeparator)) {
			return fmt.Errorf("zip entry escapes destination: %q", f.Name)
		}
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(targetAbs, 0755); err != nil {
				return err
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(targetAbs), 0755); err != nil {
			return err
		}
		src, err := f.Open()
		if err != nil {
			return err
		}
		mode := f.Mode()
		if mode == 0 {
			mode = 0644
		}
		dst, err := os.OpenFile(targetAbs, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, mode)
		if err != nil {
			src.Close()
			return err
		}
		_, copyErr := io.Copy(dst, src)
		closeErr := dst.Close()
		src.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
	}
	return nil
}

func findFileRecursive(root, name string) string {
	var found string
	_ = filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil || info == nil {
			return nil
		}
		if !info.IsDir() && strings.EqualFold(info.Name(), name) {
			found = path
			return filepath.SkipDir
		}
		return nil
	})
	return found
}

// extractMPVArchive handles both the flat official Windows archive and the
// MinGW CI packaging, which may contain the actual portable mpv bundle as a
// second zip. Every layer is extracted with the same zip-slip protection.
func extractMPVArchive(zipPath, dest string) (string, error) {
	if err := extractZipSafe(zipPath, dest); err != nil {
		return "", err
	}
	if exe := findFileRecursive(dest, "mpv.exe"); exe != "" {
		return exe, nil
	}
	var nested []string
	_ = filepath.Walk(dest, func(path string, info os.FileInfo, err error) error {
		if err == nil && info != nil && !info.IsDir() && strings.EqualFold(filepath.Ext(info.Name()), ".zip") {
			nested = append(nested, path)
		}
		return nil
	})
	for i, z := range nested {
		inner := filepath.Join(dest, fmt.Sprintf("runtime-%d", i+1))
		if err := extractZipSafe(z, inner); err != nil {
			continue
		}
		if exe := findFileRecursive(inner, "mpv.exe"); exe != "" {
			_ = os.Remove(z)
			return exe, nil
		}
	}
	return "", fmt.Errorf("mpv.exe missing from verified archive")
}
