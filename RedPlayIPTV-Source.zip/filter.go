package main

import "strings"

type channelListItem struct {
	Index int
	Label string
}

func buildChannelListItems(channels []Channel, group, query string, favoritesOnly bool, favorites map[string]bool) []channelListItem {
	return buildChannelListItemsCancelable(channels, group, query, favoritesOnly, favorites, nil)
}

// buildChannelListItemsCancelable keeps the expensive normalization loop off the
// UI thread and lets a newer search request stop an older scan quickly.
func buildChannelListItemsCancelable(channels []Channel, group, query string, favoritesOnly bool, favorites map[string]bool, shouldStop func() bool) []channelListItem {
	q := normalizeName(query)
	out := make([]channelListItem, 0, minIntForFilter(len(channels), 4096))
	for i, c := range channels {
		if i&255 == 0 && shouldStop != nil && shouldStop() {
			return nil
		}
		if group != "" && group != "All categories" && c.Group != group {
			continue
		}
		if q != "" && !strings.Contains(normalizeName(c.Name), q) && !strings.Contains(normalizeName(c.TVGName), q) {
			continue
		}
		fav := favorites[channelKey(c)]
		if favoritesOnly && !fav {
			continue
		}
		label := c.Name
		if fav {
			label = "\u2605 " + label
		}
		out = append(out, channelListItem{Index: i, Label: label})
	}
	return out
}

func minIntForFilter(a, b int) int {
	if a < b {
		return a
	}
	return b
}
