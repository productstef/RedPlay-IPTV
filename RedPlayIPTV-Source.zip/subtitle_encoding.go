package main

import "unicode/utf8"

// normalizeSubtitleText converts common subtitle text encodings to UTF-8.
// Western sidecar .srt files in this setup are often Windows-1251, while
// newer files may already be UTF-8. We normalize before handing text to mpv
// so Cyrillic renders consistently without forcing one codepage globally.
func normalizeSubtitleText(raw []byte) string {
	if len(raw) >= 3 && raw[0] == 0xef && raw[1] == 0xbb && raw[2] == 0xbf {
		raw = raw[3:]
	}
	if len(raw) >= 2 && ((raw[0] == 0xff && raw[1] == 0xfe) || (raw[0] == 0xfe && raw[1] == 0xff)) {
		le := raw[0] == 0xff
		runes := make([]rune, 0, (len(raw)-2)/2)
		for i := 2; i+1 < len(raw); i += 2 {
			var u uint16
			if le {
				u = uint16(raw[i]) | uint16(raw[i+1])<<8
			} else {
				u = uint16(raw[i])<<8 | uint16(raw[i+1])
			}
			if u == 0 {
				continue
			}
			runes = append(runes, rune(u))
		}
		return string(runes)
	}
	if utf8.Valid(raw) {
		return string(raw)
	}
	return decodeWindows1251(raw)
}
