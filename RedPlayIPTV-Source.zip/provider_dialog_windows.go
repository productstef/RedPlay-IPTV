//go:build windows

package main

import (
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

const (
	providerDialogWidth  = 1080
	providerDialogHeight = 830

	idAddChooseFile = 1058
	idAddClose      = 1059

	maxLocalPlaylistBytes = 128 << 20
)

type providerDialogMetrics struct {
	outer, appIcon, closeBtn            RECT
	nameField, urlField, uploadBox      RECT
	chooseBtn, cancelBtn, saveBtn       RECT
	separatorY                          int
	headerTitleX, headerTitleY          int
	headerSubtitleY                     int
	nameLabelY, urlLabelY, uploadLabelY int
	uploadIconTop, uploadTitleY         int
	uploadSubtitleY, supportedY         int
}

func calcProviderDialogMetrics(w, h int) providerDialogMetrics {
	// The reference mockup is approximately 1.30:1. Keep the controls anchored
	// to the same proportions while allowing the bottom action row to follow a
	// slightly shorter client area on smaller displays.
	pad := 32
	fieldRight := w - pad
	fieldLeft := pad
	m := providerDialogMetrics{}
	m.outer = RECT{Left: 1, Top: 1, Right: int32(w - 1), Bottom: int32(h - 1)}
	m.appIcon = RECT{Left: int32(pad), Top: 26, Right: int32(pad + 62), Bottom: 88}
	m.closeBtn = RECT{Left: int32(w - pad - 38), Top: 27, Right: int32(w - pad), Bottom: 65}
	m.headerTitleX = pad + 88
	m.headerTitleY = 27
	m.headerSubtitleY = 67

	m.nameLabelY = 132
	m.nameField = RECT{Left: int32(fieldLeft), Top: 167, Right: int32(fieldRight), Bottom: 222}
	m.urlLabelY = 257
	m.urlField = RECT{Left: int32(fieldLeft), Top: 292, Right: int32(fieldRight), Bottom: 347}
	m.uploadLabelY = 382
	m.uploadBox = RECT{Left: int32(fieldLeft), Top: 417, Right: int32(fieldRight), Bottom: int32(h - 143)}
	if m.uploadBox.Bottom < 650 {
		m.uploadBox.Bottom = 650
	}
	m.separatorY = int(m.uploadBox.Bottom) + 28
	buttonY := m.separatorY + 25
	buttonH := 52
	m.saveBtn = RECT{Left: int32(w - pad - 220), Top: int32(buttonY), Right: int32(w - pad), Bottom: int32(buttonY + buttonH)}
	m.cancelBtn = RECT{Left: m.saveBtn.Left - 18 - 132, Top: int32(buttonY), Right: m.saveBtn.Left - 18, Bottom: int32(buttonY + buttonH)}

	cx := (fieldLeft + fieldRight) / 2
	m.uploadIconTop = int(m.uploadBox.Top) + 28
	m.uploadTitleY = m.uploadIconTop + 64
	m.uploadSubtitleY = m.uploadTitleY + 38
	m.chooseBtn = RECT{Left: int32(cx - 116), Top: int32(m.uploadSubtitleY + 35), Right: int32(cx + 116), Bottom: int32(m.uploadSubtitleY + 91)}
	m.supportedY = int(m.chooseBtn.Bottom) + 22
	return m
}

// providerDialogWndProc keeps the existing owned-modal architecture intact.
// Only the dialog's chrome/controls are restyled to match the supplied mockup;
// mpv/videoHost ownership and the main-window overlay/z-order behavior are not
// changed.
func providerDialogWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	a := gApp
	if a == nil {
		r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
		return r
	}

	switch msg {
	case WM_CREATE:
		a.createProviderDialogControls(hwnd)
		procDragAcceptFiles.Call(hwnd, 1)
		a.applyProviderDialogRegion(hwnd)
		return 0
	case WM_SIZE:
		a.layoutProviderDialog(hwnd)
		a.applyProviderDialogRegion(hwnd)
		return 0
	case WM_PAINT:
		a.paintProviderDialog(hwnd)
		return 0
	case WM_COMMAND:
		id, notify := int(loWord(wParam)), int(hiWord(wParam))
		switch id {
		case idAddSave:
			if notify == BN_CLICKED {
				a.saveNewProvider()
				return 0
			}
		case idAddCancel, idAddClose:
			if notify == BN_CLICKED {
				a.showProviderForm(false)
				return 0
			}
		case idAddChooseFile:
			if notify == BN_CLICKED {
				a.browseProviderPlaylistFile()
				return 0
			}
		case idAddURL:
			if notify == EN_CHANGE && strings.TrimSpace(getText(a.formURLEdit)) != "" && a.formSelectedFile != "" {
				a.formSelectedFile = ""
				procInvalidateRect.Call(hwnd, 0, 0)
			}
		}
	case WM_LBUTTONDOWN:
		var rc RECT
		procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
		m := calcProviderDialogMetrics(int(rc.Right-rc.Left), int(rc.Bottom-rc.Top))
		x, y := int(int16(loWord(lParam))), int(int16(hiWord(lParam)))
		if pointInRect(x, y, m.uploadBox) {
			a.browseProviderPlaylistFile()
			return 0
		}
	case WM_DROPFILES:
		a.handleProviderDrop(wParam)
		return 0
	case WM_NCHITTEST:
		// Preserve natural borderless-window dragging from the mockup header only.
		pt := POINT{X: int32(int16(loWord(lParam))), Y: int32(int16(hiWord(lParam)))}
		procScreenToClient.Call(hwnd, uintptr(unsafe.Pointer(&pt)))
		var rc RECT
		procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
		m := calcProviderDialogMetrics(int(rc.Right-rc.Left), int(rc.Bottom-rc.Top))
		if pointInRect(int(pt.X), int(pt.Y), m.closeBtn) {
			return HTCLIENT
		}
		if pt.Y >= 0 && pt.Y < 112 {
			return HTCAPTION
		}
		return HTCLIENT
	case WM_DRAWITEM:
		return a.drawCustomButton(lParam)
	case WM_CTLCOLOREDIT, WM_CTLCOLORLISTBOX:
		procSetTextColor.Call(wParam, rgb(224, 234, 246))
		procSetBkColor.Call(wParam, rgb(14, 20, 29))
		return a.fieldBrush
	case WM_CTLCOLORSTATIC:
		procSetTextColor.Call(wParam, rgb(226, 233, 241))
		procSetBkMode.Call(wParam, TRANSPARENT)
		return a.panelBrush
	case WM_CTLCOLORBTN:
		procSetTextColor.Call(wParam, rgb(238, 243, 248))
		procSetBkMode.Call(wParam, TRANSPARENT)
		return a.panelBrush
	case WM_CLOSE:
		a.showProviderForm(false)
		return 0
	case WM_DESTROY:
		procDragAcceptFiles.Call(hwnd, 0)
		a.providerDialogDestroyed(hwnd)
		return 0
	case WM_ERASEBKGND:
		return 1
	}

	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func (a *App) createProviderDialogControls(hwnd uintptr) {
	base := uintptr(WS_CHILD | WS_VISIBLE | WS_TABSTOP)
	btn := uintptr(WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_OWNERDRAW)

	// Optional EPG/header fields deliberately remain absent from the visual form,
	// as requested. Existing values are preserved when an existing provider is
	// edited and its source is unchanged.
	a.formTitle, a.formSubtitle = 0, 0
	a.formNameLabel, a.formURLLabel = 0, 0
	a.formEPGLabel, a.formEPGEdit = 0, 0
	a.formUALabel, a.formUAEdit = 0, 0
	a.formRefererLabel, a.formRefererEdit = 0, 0

	a.formNameEdit = createControl(0, "EDIT", "", base|ES_AUTOHSCROLL, 0, 0, 500, 34, hwnd, idAddName)
	a.formURLEdit = createControl(0, "EDIT", "", base|ES_AUTOHSCROLL, 0, 0, 500, 34, hwnd, idAddURL)
	a.formChooseFile = createControl(0, "BUTTON", "⇧   Choose file", btn, 0, 0, 232, 56, hwnd, idAddChooseFile)
	a.formCancel = createControl(0, "BUTTON", "Cancel", btn, 0, 0, 132, 52, hwnd, idAddCancel)
	a.formSave = createControl(0, "BUTTON", "✓   Save provider", btn, 0, 0, 220, 52, hwnd, idAddSave)
	a.formClose = createControl(0, "BUTTON", "×", btn, 0, 0, 38, 38, hwnd, idAddClose)

	setFont(a.formNameEdit, a.fontProviderSubtitle)
	setFont(a.formURLEdit, a.fontProviderSubtitle)
	setFont(a.formChooseFile, a.fontProviderLabel)
	setFont(a.formSave, a.fontProviderLabel)
	setFont(a.formCancel, a.fontProviderLabel)
	setFont(a.formClose, a.fontProviderTitle)
	setDarkTheme(a.formNameEdit)
	setDarkTheme(a.formURLEdit)
	send(a.formNameEdit, EM_SETCUEBANNER, 0, uintptr(unsafe.Pointer(utf16p("e.g. My IPTV, Home TV, Provider Name..."))))
	send(a.formURLEdit, EM_SETCUEBANNER, 0, uintptr(unsafe.Pointer(utf16p("https://example.com/playlist.m3u"))))

	a.formSelectedFile = ""
	a.formPreservedEPG = ""
	a.formPreservedHeaders = nil
	if a.editingProvider >= 0 && a.editingProvider < len(a.state.Providers) {
		p := a.state.Providers[a.editingProvider]
		setText(a.formNameEdit, p.Name)
		if localPath, ok := providerFilePath(p.URL); ok {
			a.formSelectedFile = localPath
		} else {
			setText(a.formURLEdit, p.URL)
		}
		a.formPreservedEPG = p.EPGURL
		a.formPreservedHeaders = cloneStringMap(p.Headers)
	}

	a.layoutProviderDialog(hwnd)
}

func (a *App) layoutProviderDialog(hwnd uintptr) {
	if hwnd == 0 {
		return
	}
	var rc RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	w, h := int(rc.Right-rc.Left), int(rc.Bottom-rc.Top)
	if w <= 0 || h <= 0 {
		return
	}
	m := calcProviderDialogMetrics(w, h)

	// The edit controls are inset into the painted shells so the icon area and
	// rounded border stay pixel-clean instead of relying on WS_EX_CLIENTEDGE.
	move(a.formNameEdit, int(m.nameField.Left)+60, int(m.nameField.Top)+10, int(m.nameField.Right-m.nameField.Left)-76, 35)
	move(a.formURLEdit, int(m.urlField.Left)+60, int(m.urlField.Top)+10, int(m.urlField.Right-m.urlField.Left)-76, 35)
	move(a.formChooseFile, int(m.chooseBtn.Left), int(m.chooseBtn.Top), int(m.chooseBtn.Right-m.chooseBtn.Left), int(m.chooseBtn.Bottom-m.chooseBtn.Top))
	move(a.formCancel, int(m.cancelBtn.Left), int(m.cancelBtn.Top), int(m.cancelBtn.Right-m.cancelBtn.Left), int(m.cancelBtn.Bottom-m.cancelBtn.Top))
	move(a.formSave, int(m.saveBtn.Left), int(m.saveBtn.Top), int(m.saveBtn.Right-m.saveBtn.Left), int(m.saveBtn.Bottom-m.saveBtn.Top))
	move(a.formClose, int(m.closeBtn.Left), int(m.closeBtn.Top), int(m.closeBtn.Right-m.closeBtn.Left), int(m.closeBtn.Bottom-m.closeBtn.Top))
	procInvalidateRect.Call(hwnd, 0, 0)
}

func (a *App) paintProviderDialog(hwnd uintptr) {
	var ps PAINTSTRUCT
	hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	defer procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))

	var rc RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	w, h := int(rc.Right-rc.Left), int(rc.Bottom-rc.Top)
	m := calcProviderDialogMetrics(w, h)

	fillSolid(hdc, rc, rgb(7, 12, 19))
	drawRoundRect(hdc, m.outer, rgb(10, 17, 25), rgb(42, 56, 72), 18)

	// Red application mark from the reference.
	drawRoundRect(hdc, m.appIcon, rgb(255, 48, 72), rgb(255, 63, 84), 16)
	drawTVIcon(hdc, m.appIcon, rgb(255, 255, 255))

	title := "Add IPTV provider"
	if a.editingProvider >= 0 && a.editingProvider < len(a.state.Providers) {
		title = "Edit IPTV provider"
	}
	if a.fontProviderTitle != 0 {
		procSelectObject.Call(hdc, a.fontProviderTitle)
	}
	drawTextRect(hdc, RECT{Left: int32(m.headerTitleX), Top: int32(m.headerTitleY), Right: int32(w - 90), Bottom: int32(m.headerTitleY + 38)}, title, rgb(241, 245, 250), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
	if a.fontProviderSubtitle != 0 {
		procSelectObject.Call(hdc, a.fontProviderSubtitle)
	}
	drawTextRect(hdc, RECT{Left: int32(m.headerTitleX), Top: int32(m.headerSubtitleY), Right: int32(w - 90), Bottom: int32(m.headerSubtitleY + 28)}, "Add your IPTV playlist via URL or upload an M3U file", rgb(159, 181, 207), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)

	if a.fontProviderLabel != 0 {
		procSelectObject.Call(hdc, a.fontProviderLabel)
	}
	drawTextRect(hdc, RECT{Left: 32, Top: int32(m.nameLabelY), Right: int32(w - 32), Bottom: int32(m.nameLabelY + 28)}, "Name", rgb(241, 244, 248), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
	drawTextRect(hdc, RECT{Left: 32, Top: int32(m.urlLabelY), Right: int32(w - 32), Bottom: int32(m.urlLabelY + 28)}, "M3U / M3U8 playlist URL", rgb(241, 244, 248), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
	drawTextRect(hdc, RECT{Left: 32, Top: int32(m.uploadLabelY), Right: int32(w - 32), Bottom: int32(m.uploadLabelY + 28)}, "Or upload M3U file", rgb(241, 244, 248), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)

	// Input shells and left-side line icons.
	drawRoundRect(hdc, m.nameField, rgb(14, 20, 29), rgb(54, 70, 89), 13)
	drawRoundRect(hdc, m.urlField, rgb(14, 20, 29), rgb(54, 70, 89), 13)
	drawTagIcon(hdc, int(m.nameField.Left)+23, int((m.nameField.Top+m.nameField.Bottom)/2), rgb(159, 183, 211))
	drawLinkIcon(hdc, int(m.urlField.Left)+29, int((m.urlField.Top+m.urlField.Bottom)/2), rgb(159, 183, 211))

	// GitHub-inspired dashed drop zone.
	drawDashedRoundRect(hdc, m.uploadBox, rgb(168, 192, 221), 14)
	cx := int((m.uploadBox.Left + m.uploadBox.Right) / 2)
	drawFileIcon(hdc, cx, m.uploadIconTop, rgb(185, 207, 231))

	selected := strings.TrimSpace(a.formSelectedFile)
	if a.fontProviderDrop != 0 {
		procSelectObject.Call(hdc, a.fontProviderDrop)
	}
	mainText := "Drag and drop your M3U file here"
	if selected != "" {
		mainText = "M3U file selected"
	}
	drawTextRect(hdc, RECT{Left: m.uploadBox.Left + 20, Top: int32(m.uploadTitleY), Right: m.uploadBox.Right - 20, Bottom: int32(m.uploadTitleY + 32)}, mainText, rgb(241, 244, 248), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)
	if a.fontProviderSubtitle != 0 {
		procSelectObject.Call(hdc, a.fontProviderSubtitle)
	}
	subText := "or click to browse"
	if selected != "" {
		subText = filepath.Base(selected)
	}
	drawTextRect(hdc, RECT{Left: m.uploadBox.Left + 36, Top: int32(m.uploadSubtitleY), Right: m.uploadBox.Right - 36, Bottom: int32(m.uploadSubtitleY + 30)}, subText, rgb(159, 181, 207), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX)
	if a.fontSmall != 0 {
		procSelectObject.Call(hdc, a.fontSmall)
	}
	supported := "Supported format: .m3u"
	if selected != "" {
		supported = "Ready to add"
	}
	drawTextRect(hdc, RECT{Left: m.uploadBox.Left + 20, Top: int32(m.supportedY), Right: m.uploadBox.Right - 20, Bottom: int32(m.supportedY + 24)}, supported, rgb(143, 166, 194), DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)

	fillSolid(hdc, RECT{Left: 32, Top: int32(m.separatorY), Right: int32(w - 32), Bottom: int32(m.separatorY + 1)}, rgb(54, 68, 84))
}

func (a *App) applyProviderDialogRegion(hwnd uintptr) {
	if hwnd == 0 {
		return
	}
	var rc RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	w, h := int(rc.Right-rc.Left), int(rc.Bottom-rc.Top)
	if w <= 0 || h <= 0 {
		return
	}
	rgn, _, _ := procCreateRoundRectRgn.Call(0, 0, uintptr(w+1), uintptr(h+1), 22, 22)
	if rgn != 0 {
		// On success Windows owns the region handle.
		procSetWindowRgn.Call(hwnd, rgn, 1)
	}
}

func (a *App) browseProviderPlaylistFile() {
	path, ok := chooseM3UFile(a.providerDialogHwnd)
	if !ok {
		return
	}
	a.acceptProviderPlaylistFile(path)
}

func chooseM3UFile(owner uintptr) (string, bool) {
	buf := make([]uint16, 32768)
	filter := make([]uint16, 0, 96)
	for _, part := range []string{"M3U playlists (*.m3u;*.m3u8)", "*.m3u;*.m3u8", "All files (*.*)", "*.*"} {
		filter = append(filter, syscall.StringToUTF16(part)...)
	}
	filter = append(filter, 0)
	title := syscall.StringToUTF16("Choose M3U playlist")
	of := OPENFILENAME{
		LStructSize:  uint32(unsafe.Sizeof(OPENFILENAME{})),
		HwndOwner:    owner,
		LpstrFilter:  &filter[0],
		NFilterIndex: 1,
		LpstrFile:    &buf[0],
		NMaxFile:     uint32(len(buf)),
		LpstrTitle:   &title[0],
		Flags:        OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR,
	}
	ok, _, _ := procGetOpenFileNameW.Call(uintptr(unsafe.Pointer(&of)))
	if ok == 0 {
		return "", false
	}
	return syscall.UTF16ToString(buf), true
}

func (a *App) handleProviderDrop(hDrop uintptr) {
	defer procDragFinish.Call(hDrop)
	count, _, _ := procDragQueryFileW.Call(hDrop, ^uintptr(0), 0, 0)
	if count == 0 {
		return
	}
	n, _, _ := procDragQueryFileW.Call(hDrop, 0, 0, 0)
	if n == 0 {
		return
	}
	buf := make([]uint16, int(n)+1)
	procDragQueryFileW.Call(hDrop, 0, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	a.acceptProviderPlaylistFile(syscall.UTF16ToString(buf))
}

func (a *App) acceptProviderPlaylistFile(path string) {
	path = strings.TrimSpace(path)
	if path == "" {
		return
	}
	ext := strings.ToLower(filepath.Ext(path))
	if ext != ".m3u" && ext != ".m3u8" {
		messageBox(a.providerDialogOwner(), "RedPlay IPTV", "Choose an .m3u or .m3u8 playlist file.", MB_OK|MB_ICONERROR)
		return
	}
	st, err := os.Stat(path)
	if err != nil || st.IsDir() {
		if err == nil {
			err = fmt.Errorf("selected path is not a file")
		}
		messageBox(a.providerDialogOwner(), "RedPlay IPTV", "Could not open playlist: "+err.Error(), MB_OK|MB_ICONERROR)
		return
	}
	if st.Size() > maxLocalPlaylistBytes {
		messageBox(a.providerDialogOwner(), "RedPlay IPTV", "Playlist file is larger than 128 MB.", MB_OK|MB_ICONERROR)
		return
	}
	// A file and URL are two inputs to the same source. Selecting a file clears
	// the URL field rather than adding a mode switch, matching the supplied UI.
	setText(a.formURLEdit, "")
	a.formSelectedFile = path
	if strings.TrimSpace(getText(a.formNameEdit)) == "" {
		base := strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
		if strings.TrimSpace(base) != "" {
			setText(a.formNameEdit, base)
		}
	}
	if a.providerDialogHwnd != 0 {
		procInvalidateRect.Call(a.providerDialogHwnd, 0, 0)
	}
}

func managedPlaylistDir() string {
	return filepath.Join(nativeDataDir(), "Playlists")
}

func persistProviderPlaylistFile(providerID, src string) (string, error) {
	ext := strings.ToLower(filepath.Ext(src))
	if ext != ".m3u" && ext != ".m3u8" {
		return "", fmt.Errorf("unsupported playlist file type")
	}
	st, err := os.Stat(src)
	if err != nil {
		return "", err
	}
	if st.IsDir() {
		return "", fmt.Errorf("playlist path is a directory")
	}
	if st.Size() > maxLocalPlaylistBytes {
		return "", fmt.Errorf("playlist file is larger than 128 MB")
	}
	dir := managedPlaylistDir()
	if err := os.MkdirAll(dir, 0755); err != nil {
		return "", err
	}
	dst := filepath.Join(dir, providerID+ext)
	if strings.EqualFold(filepath.Clean(src), filepath.Clean(dst)) {
		return localFileURL(dst)
	}
	in, err := os.Open(src)
	if err != nil {
		return "", err
	}
	defer in.Close()
	tmp := dst + ".tmp"
	out, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0644)
	if err != nil {
		return "", err
	}
	_, copyErr := io.Copy(out, io.LimitReader(in, maxLocalPlaylistBytes+1))
	closeErr := out.Close()
	if copyErr != nil {
		_ = os.Remove(tmp)
		return "", copyErr
	}
	if closeErr != nil {
		_ = os.Remove(tmp)
		return "", closeErr
	}
	if info, err := os.Stat(tmp); err != nil || info.Size() > maxLocalPlaylistBytes {
		_ = os.Remove(tmp)
		if err != nil {
			return "", err
		}
		return "", fmt.Errorf("playlist file is larger than 128 MB")
	}
	_ = os.Remove(dst)
	if err := os.Rename(tmp, dst); err != nil {
		_ = os.Remove(tmp)
		return "", err
	}
	return localFileURL(dst)
}

func removeManagedPlaylistFile(rawURL string) {
	path, ok := providerFilePath(rawURL)
	if !ok {
		return
	}
	root, err := filepath.Abs(managedPlaylistDir())
	if err != nil {
		return
	}
	pathAbs, err := filepath.Abs(path)
	if err != nil {
		return
	}
	rel, err := filepath.Rel(root, pathAbs)
	if err != nil || rel == "." || rel == "" || rel == ".." || strings.HasPrefix(rel, ".."+string(os.PathSeparator)) {
		return
	}
	_ = os.Remove(pathAbs)
}

func cloneStringMap(in map[string]string) map[string]string {
	if len(in) == 0 {
		return map[string]string{}
	}
	out := make(map[string]string, len(in))
	for k, v := range in {
		out[k] = v
	}
	return out
}

func pointInRect(x, y int, rc RECT) bool {
	return x >= int(rc.Left) && x < int(rc.Right) && y >= int(rc.Top) && y < int(rc.Bottom)
}

func drawLine(hdc uintptr, x1, y1, x2, y2 int, color uintptr, width int) {
	pen, _, _ := procCreatePen.Call(PS_SOLID, uintptr(width), color)
	oldPen, _, _ := procSelectObject.Call(hdc, pen)
	procMoveToEx.Call(hdc, uintptr(x1), uintptr(y1), 0)
	procLineTo.Call(hdc, uintptr(x2), uintptr(y2))
	procSelectObject.Call(hdc, oldPen)
	procDeleteObject.Call(pen)
}

func drawDashedRoundRect(hdc uintptr, rc RECT, color uintptr, radius int) {
	pen, _, _ := procCreatePen.Call(PS_DASH, 1, color)
	oldPen, _, _ := procSelectObject.Call(hdc, pen)
	hollow, _, _ := procGetStockObject.Call(NULL_BRUSH)
	oldBrush, _, _ := procSelectObject.Call(hdc, hollow)
	procRoundRect.Call(hdc, uintptr(rc.Left), uintptr(rc.Top), uintptr(rc.Right), uintptr(rc.Bottom), uintptr(radius), uintptr(radius))
	procSelectObject.Call(hdc, oldBrush)
	procSelectObject.Call(hdc, oldPen)
	procDeleteObject.Call(pen)
}

func drawTVIcon(hdc uintptr, rc RECT, color uintptr) {
	cx := int((rc.Left + rc.Right) / 2)
	top := int(rc.Top) + 19
	left := int(rc.Left) + 17
	right := int(rc.Right) - 17
	bottom := int(rc.Bottom) - 15
	inner := RECT{Left: int32(left), Top: int32(top), Right: int32(right), Bottom: int32(bottom)}
	drawRoundRect(hdc, inner, rgb(255, 48, 72), color, 8)
	drawLine(hdc, cx, top, cx-8, top-9, color, 2)
	drawLine(hdc, cx, top, cx+8, top-9, color, 2)
	drawLine(hdc, cx-5, top+8, cx-5, bottom-8, color, 2)
	drawLine(hdc, cx-5, top+8, cx+9, (top+bottom)/2, color, 2)
	drawLine(hdc, cx+9, (top+bottom)/2, cx-5, bottom-8, color, 2)
}

func drawTagIcon(hdc uintptr, cx, cy int, color uintptr) {
	pts := [][2]int{{cx - 10, cy - 7}, {cx - 2, cy - 13}, {cx + 11, cy}, {cx - 1, cy + 12}, {cx - 10, cy + 4}, {cx - 10, cy - 7}}
	for i := 0; i+1 < len(pts); i++ {
		drawLine(hdc, pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1], color, 2)
	}
	// Small tag hole.
	drawRoundRect(hdc, RECT{Left: int32(cx - 5), Top: int32(cy - 6), Right: int32(cx - 1), Bottom: int32(cy - 2)}, rgb(14, 20, 29), color, 2)
}

func drawLinkIcon(hdc uintptr, cx, cy int, color uintptr) {
	pen, _, _ := procCreatePen.Call(PS_SOLID, 2, color)
	oldPen, _, _ := procSelectObject.Call(hdc, pen)
	hollow, _, _ := procGetStockObject.Call(NULL_BRUSH)
	oldBrush, _, _ := procSelectObject.Call(hdc, hollow)
	procEllipse.Call(hdc, uintptr(cx-16), uintptr(cy-8), uintptr(cx-2), uintptr(cy+6))
	procEllipse.Call(hdc, uintptr(cx+1), uintptr(cy-6), uintptr(cx+15), uintptr(cy+8))
	procSelectObject.Call(hdc, oldBrush)
	procSelectObject.Call(hdc, oldPen)
	procDeleteObject.Call(pen)
	drawLine(hdc, cx-4, cy+4, cx+4, cy-4, color, 2)
}

func drawFileIcon(hdc uintptr, cx, top int, color uintptr) {
	left, right, bottom := cx-20, cx+20, top+50
	drawLine(hdc, left, top, cx+7, top, color, 3)
	drawLine(hdc, cx+7, top, right, top+13, color, 3)
	drawLine(hdc, right, top+13, right, bottom, color, 3)
	drawLine(hdc, right, bottom, left, bottom, color, 3)
	drawLine(hdc, left, bottom, left, top, color, 3)
	drawLine(hdc, cx+7, top, cx+7, top+13, color, 3)
	drawLine(hdc, cx+7, top+13, right, top+13, color, 3)
}

func (a *App) showProviderForm(on bool) {
	if on {
		a.openProviderDialog()
		return
	}
	if a.providerDialogHwnd != 0 {
		h := a.providerDialogHwnd
		a.providerDialogHwnd = 0
		procDestroyWindow.Call(h)
		return
	}
	a.providerDialogDestroyed(0)
}

func (a *App) openProviderDialog() {
	if a.providerDialogHwnd != 0 {
		procSetFocus.Call(a.formNameEdit)
		return
	}

	a.providerFormOpen = true
	procEnableWindow.Call(a.hwnd, 0)

	var owner RECT
	if ok, _, _ := procGetWindowRect.Call(a.hwnd, uintptr(unsafe.Pointer(&owner))); ok == 0 {
		owner = RECT{Left: 100, Top: 100, Right: 100 + providerDialogWidth, Bottom: 100 + providerDialogHeight}
	}
	dw, dh := providerDialogWidth, providerDialogHeight
	x := int(owner.Left) + (int(owner.Right-owner.Left)-dw)/2
	y := int(owner.Top) + (int(owner.Bottom-owner.Top)-dh)/2

	// Keep the custom window wholly on the current monitor without changing the
	// existing owner/modal semantics.
	mon, _, _ := procMonitorFromWindow.Call(a.hwnd, MONITOR_DEFAULTTONEAREST)
	if mon != 0 {
		mi := MONITORINFO{CbSize: uint32(unsafe.Sizeof(MONITORINFO{}))}
		if ok, _, _ := procGetMonitorInfoW.Call(mon, uintptr(unsafe.Pointer(&mi))); ok != 0 {
			workW := int(mi.RcWork.Right - mi.RcWork.Left)
			workH := int(mi.RcWork.Bottom - mi.RcWork.Top)
			if dw > workW-24 {
				dw = workW - 24
			}
			if dh > workH-24 {
				dh = workH - 24
			}
			if x < int(mi.RcWork.Left)+12 {
				x = int(mi.RcWork.Left) + 12
			}
			if y < int(mi.RcWork.Top)+12 {
				y = int(mi.RcWork.Top) + 12
			}
			if x+dw > int(mi.RcWork.Right)-12 {
				x = int(mi.RcWork.Right) - 12 - dw
			}
			if y+dh > int(mi.RcWork.Bottom)-12 {
				y = int(mi.RcWork.Bottom) - 12 - dh
			}
		}
	}

	hinst, _, _ := procGetModuleHandleW.Call(0)
	caption := "Add IPTV provider"
	if a.editingProvider >= 0 && a.editingProvider < len(a.state.Providers) {
		caption = "Edit IPTV provider"
	}
	style := uintptr(WS_POPUP | WS_VISIBLE | WS_CLIPCHILDREN)
	exStyle := uintptr(WS_EX_CONTROLPARENT)
	hwnd, _, _ := procCreateWindowExW.Call(
		exStyle,
		uintptr(unsafe.Pointer(utf16p("RedPlayProviderDialog"))),
		uintptr(unsafe.Pointer(utf16p(caption))),
		style,
		uintptr(x), uintptr(y), uintptr(dw), uintptr(dh),
		a.hwnd, 0, hinst, 0,
	)
	if hwnd == 0 {
		a.providerFormOpen = false
		procEnableWindow.Call(a.hwnd, 1)
		messageBox(a.hwnd, "RedPlay IPTV", "Could not open the provider editor.", MB_OK|MB_ICONERROR)
		return
	}

	a.providerDialogHwnd = hwnd
	enableDarkMode(hwnd)
	loadAppIcon(hwnd)
	procShowWindow.Call(hwnd, SW_SHOW)
	procUpdateWindow.Call(hwnd)
	procSetFocus.Call(a.formNameEdit)
}

func (a *App) providerDialogDestroyed(hwnd uintptr) {
	if hwnd != 0 && a.providerDialogHwnd != 0 && a.providerDialogHwnd != hwnd {
		return
	}
	a.providerDialogHwnd = 0
	a.providerFormOpen = false
	a.formTitle = 0
	a.formSubtitle = 0
	a.formNameLabel = 0
	a.formNameEdit = 0
	a.formURLLabel = 0
	a.formURLEdit = 0
	a.formEPGLabel = 0
	a.formEPGEdit = 0
	a.formUALabel = 0
	a.formUAEdit = 0
	a.formRefererLabel = 0
	a.formRefererEdit = 0
	a.formChooseFile = 0
	a.formClose = 0
	a.formSave = 0
	a.formCancel = 0
	a.formSelectedFile = ""
	a.formPreservedEPG = ""
	a.formPreservedHeaders = nil
	a.editingProvider = -1

	if a.hwnd != 0 {
		procEnableWindow.Call(a.hwnd, 1)
		procSetFocus.Call(a.hwnd)
		procInvalidateRect.Call(a.hwnd, 0, 1)
	}
}

func (a *App) providerDialogOwner() uintptr {
	if a.providerDialogHwnd != 0 {
		return a.providerDialogHwnd
	}
	return a.hwnd
}
