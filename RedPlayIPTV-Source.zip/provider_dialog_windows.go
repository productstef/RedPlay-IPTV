//go:build windows

package main

import "unsafe"

const (
	providerDialogWidth  = 720
	providerDialogHeight = 500
)

// providerDialogWndProc owns the provider editor as a real top-level owned
// window. It is intentionally not drawn as child controls over videoHost:
// mpv owns native child windows of its own, and cross-child z-order is not a
// reliable way to implement a modal editor on Windows.
func providerDialogWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	a := gApp
	if a == nil {
		r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
		return r
	}

	switch msg {
	case WM_CREATE:
		a.createProviderDialogControls(hwnd)
		return 0
	case WM_SIZE:
		a.layoutProviderDialog(hwnd)
		return 0
	case WM_COMMAND:
		switch int(loWord(wParam)) {
		case idAddSave:
			if int(hiWord(wParam)) == BN_CLICKED {
				a.saveNewProvider()
				return 0
			}
		case idAddCancel:
			if int(hiWord(wParam)) == BN_CLICKED {
				a.showProviderForm(false)
				return 0
			}
		}
	case WM_DRAWITEM:
		return a.drawCustomButton(lParam)
	case WM_CTLCOLOREDIT, WM_CTLCOLORLISTBOX:
		procSetTextColor.Call(wParam, rgb(232, 237, 242))
		procSetBkColor.Call(wParam, rgb(14, 20, 29))
		return a.fieldBrush
	case WM_CTLCOLORSTATIC:
		procSetTextColor.Call(wParam, rgb(218, 225, 233))
		procSetBkColor.Call(wParam, rgb(10, 15, 23))
		return a.panelBrush
	case WM_CTLCOLORBTN:
		procSetTextColor.Call(wParam, rgb(230, 235, 240))
		procSetBkMode.Call(wParam, TRANSPARENT)
		return a.panelBrush
	case WM_CLOSE:
		a.showProviderForm(false)
		return 0
	case WM_DESTROY:
		a.providerDialogDestroyed(hwnd)
		return 0
	case WM_ERASEBKGND:
		return 1
	}

	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func (a *App) createProviderDialogControls(hwnd uintptr) {
	base := uintptr(WS_CHILD | WS_VISIBLE | WS_TABSTOP)
	label := uintptr(WS_CHILD | WS_VISIBLE | SS_LEFT)
	btn := uintptr(WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_OWNERDRAW)

	title := "Add IPTV provider"
	if a.editingProvider >= 0 && a.editingProvider < len(a.state.Providers) {
		title = "Edit IPTV provider"
	}

	a.formTitle = createControl(0, "STATIC", title, label, 0, 0, 300, 26, hwnd, 0)
	a.formNameLabel = createControl(0, "STATIC", "Name", label, 0, 0, 180, 22, hwnd, 0)
	a.formNameEdit = createControl(WS_EX_CLIENTEDGE, "EDIT", "", base|ES_AUTOHSCROLL, 0, 0, 500, 30, hwnd, idAddName)
	a.formURLLabel = createControl(0, "STATIC", "M3U / M3U8 playlist URL", label, 0, 0, 300, 22, hwnd, 0)
	a.formURLEdit = createControl(WS_EX_CLIENTEDGE, "EDIT", "", base|ES_AUTOHSCROLL, 0, 0, 500, 30, hwnd, idAddURL)
	a.formEPGLabel = createControl(0, "STATIC", "EPG URL (optional - auto detected from M3U)", label, 0, 0, 430, 22, hwnd, 0)
	a.formEPGEdit = createControl(WS_EX_CLIENTEDGE, "EDIT", "", base|ES_AUTOHSCROLL, 0, 0, 500, 30, hwnd, idAddEPG)
	a.formUALabel = createControl(0, "STATIC", "User-Agent (optional)", label, 0, 0, 260, 22, hwnd, 0)
	a.formUAEdit = createControl(WS_EX_CLIENTEDGE, "EDIT", "", base|ES_AUTOHSCROLL, 0, 0, 500, 30, hwnd, idAddUserAgent)
	a.formRefererLabel = createControl(0, "STATIC", "Referer (optional)", label, 0, 0, 260, 22, hwnd, 0)
	a.formRefererEdit = createControl(WS_EX_CLIENTEDGE, "EDIT", "", base|ES_AUTOHSCROLL, 0, 0, 500, 30, hwnd, idAddReferer)
	a.formSave = createControl(0, "BUTTON", "Save provider", btn, 0, 0, 128, 34, hwnd, idAddSave)
	a.formCancel = createControl(0, "BUTTON", "Cancel", btn, 0, 0, 92, 34, hwnd, idAddCancel)

	setFont(a.formTitle, a.fontSection)
	for _, h := range []uintptr{a.formNameLabel, a.formURLLabel, a.formEPGLabel, a.formUALabel, a.formRefererLabel, a.formNameEdit, a.formURLEdit, a.formEPGEdit, a.formUAEdit, a.formRefererEdit} {
		setFont(h, a.fontBody)
	}
	setFont(a.formSave, a.fontButton)
	setFont(a.formCancel, a.fontButton)
	for _, h := range []uintptr{a.formNameEdit, a.formURLEdit, a.formEPGEdit, a.formUAEdit, a.formRefererEdit} {
		setDarkTheme(h)
	}

	if a.editingProvider >= 0 && a.editingProvider < len(a.state.Providers) {
		p := a.state.Providers[a.editingProvider]
		setText(a.formNameEdit, p.Name)
		setText(a.formURLEdit, p.URL)
		setText(a.formEPGEdit, p.EPGURL)
		setText(a.formUAEdit, p.Headers["User-Agent"])
		setText(a.formRefererEdit, p.Headers["Referer"])
	}

	a.layoutProviderDialog(hwnd)
}

func (a *App) layoutProviderDialog(hwnd uintptr) {
	if hwnd == 0 {
		return
	}
	var rc RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	w := int(rc.Right - rc.Left)
	if w <= 0 {
		return
	}
	pad := 24
	fieldW := maxInt(220, w-pad*2)

	move(a.formTitle, pad, 18, fieldW, 28)
	move(a.formNameLabel, pad, 58, fieldW, 20)
	move(a.formNameEdit, pad, 80, fieldW, 30)
	move(a.formURLLabel, pad, 121, fieldW, 20)
	move(a.formURLEdit, pad, 143, fieldW, 30)
	move(a.formEPGLabel, pad, 184, fieldW, 20)
	move(a.formEPGEdit, pad, 206, fieldW, 30)
	move(a.formUALabel, pad, 247, fieldW, 20)
	move(a.formUAEdit, pad, 269, fieldW, 30)
	move(a.formRefererLabel, pad, 310, fieldW, 20)
	move(a.formRefererEdit, pad, 332, fieldW, 30)

	buttonY := 390
	move(a.formCancel, w-pad-92, buttonY, 92, 34)
	move(a.formSave, w-pad-92-12-128, buttonY, 128, 34)
	procInvalidateRect.Call(hwnd, 0, 1)
}

func (a *App) showProviderForm(on bool) {
	if on {
		a.openProviderDialog()
		return
	}
	if a.providerDialogHwnd != 0 {
		h := a.providerDialogHwnd
		a.providerDialogHwnd = 0
		procDestroyWindow.Call(h)
		return
	}
	a.providerDialogDestroyed(0)
}

func (a *App) openProviderDialog() {
	if a.providerDialogHwnd != 0 {
		procSetFocus.Call(a.formNameEdit)
		return
	}

	a.providerFormOpen = true
	procEnableWindow.Call(a.hwnd, 0)

	var owner RECT
	if ok, _, _ := procGetWindowRect.Call(a.hwnd, uintptr(unsafe.Pointer(&owner))); ok == 0 {
		owner = RECT{Left: 100, Top: 100, Right: 100 + providerDialogWidth, Bottom: 100 + providerDialogHeight}
	}
	x := int(owner.Left) + maxInt(0, (int(owner.Right-owner.Left)-providerDialogWidth)/2)
	y := int(owner.Top) + maxInt(0, (int(owner.Bottom-owner.Top)-providerDialogHeight)/2)

	hinst, _, _ := procGetModuleHandleW.Call(0)
	caption := "Add IPTV provider"
	if a.editingProvider >= 0 && a.editingProvider < len(a.state.Providers) {
		caption = "Edit IPTV provider"
	}
	style := uintptr(WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_VISIBLE)
	exStyle := uintptr(WS_EX_DLGMODALFRAME | WS_EX_CONTROLPARENT)
	hwnd, _, _ := procCreateWindowExW.Call(
		exStyle,
		uintptr(unsafe.Pointer(utf16p("RedPlayProviderDialog"))),
		uintptr(unsafe.Pointer(utf16p(caption))),
		style,
		uintptr(x), uintptr(y), providerDialogWidth, providerDialogHeight,
		a.hwnd, 0, hinst, 0,
	)
	if hwnd == 0 {
		a.providerFormOpen = false
		procEnableWindow.Call(a.hwnd, 1)
		messageBox(a.hwnd, "RedPlay IPTV", "Could not open the provider editor.", MB_OK|MB_ICONERROR)
		return
	}

	a.providerDialogHwnd = hwnd
	enableDarkMode(hwnd)
	loadAppIcon(hwnd)
	procShowWindow.Call(hwnd, SW_SHOW)
	procUpdateWindow.Call(hwnd)
	procSetFocus.Call(a.formNameEdit)
}

func (a *App) providerDialogDestroyed(hwnd uintptr) {
	if hwnd != 0 && a.providerDialogHwnd != 0 && a.providerDialogHwnd != hwnd {
		return
	}
	a.providerDialogHwnd = 0
	a.providerFormOpen = false
	a.formTitle = 0
	a.formNameLabel = 0
	a.formNameEdit = 0
	a.formURLLabel = 0
	a.formURLEdit = 0
	a.formEPGLabel = 0
	a.formEPGEdit = 0
	a.formUALabel = 0
	a.formUAEdit = 0
	a.formRefererLabel = 0
	a.formRefererEdit = 0
	a.formSave = 0
	a.formCancel = 0
	a.editingProvider = -1

	if a.hwnd != 0 {
		procEnableWindow.Call(a.hwnd, 1)
		procSetFocus.Call(a.hwnd)
		procInvalidateRect.Call(a.hwnd, 0, 1)
	}
}

func (a *App) providerDialogOwner() uintptr {
	if a.providerDialogHwnd != 0 {
		return a.providerDialogHwnd
	}
	return a.hwnd
}
