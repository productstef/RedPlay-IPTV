module redplay/native

go 1.23
