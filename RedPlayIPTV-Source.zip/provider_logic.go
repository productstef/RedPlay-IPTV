package main

import (
	"fmt"
	"net/url"
	"path/filepath"
	"runtime"
	"strings"
)

func normalizeProviderURL(raw string) (string, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "", fmt.Errorf("URL is empty")
	}
	u, err := url.Parse(raw)
	if err != nil {
		return "", fmt.Errorf("invalid URL")
	}
	u.Scheme = strings.ToLower(u.Scheme)
	if u.Scheme == "file" {
		path, ok := providerFilePath(raw)
		if !ok || strings.TrimSpace(path) == "" {
			return "", fmt.Errorf("invalid local playlist path")
		}
		return localFileURL(path)
	}
	if u.Host == "" {
		return "", fmt.Errorf("invalid URL")
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return "", fmt.Errorf("URL must start with http:// or https://")
	}
	u.Host = strings.ToLower(u.Host)
	u.Fragment = ""
	return u.String(), nil
}

// localFileURL converts a local path into a stable file:// URL that can be
// persisted in the same Provider.URL field as remote playlists.
func localFileURL(path string) (string, error) {
	path = strings.TrimSpace(path)
	if path == "" {
		return "", fmt.Errorf("file path is empty")
	}
	abs, err := filepath.Abs(path)
	if err != nil {
		return "", err
	}
	slash := filepath.ToSlash(filepath.Clean(abs))
	// Windows drive-letter file URLs use file:///C:/... rather than file://C:/...
	if len(slash) >= 2 && slash[1] == ':' && !strings.HasPrefix(slash, "/") {
		slash = "/" + slash
	}
	u := &url.URL{Scheme: "file", Path: slash}
	return u.String(), nil
}

// providerFilePath returns a platform path for a persisted file:// provider.
func providerFilePath(raw string) (string, bool) {
	u, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || strings.ToLower(u.Scheme) != "file" {
		return "", false
	}
	p, err := url.PathUnescape(u.Path)
	if err != nil || strings.TrimSpace(p) == "" {
		return "", false
	}
	// url.Parse keeps the leading slash from file:///C:/...; Win32 paths do not.
	if runtime.GOOS == "windows" && len(p) >= 3 && p[0] == '/' && p[2] == ':' {
		p = p[1:]
	}
	return filepath.Clean(filepath.FromSlash(p)), true
}

func findProviderByURL(providers []Provider, raw string) (int, bool) {
	want, err := normalizeProviderURL(raw)
	if err != nil {
		return -1, false
	}
	for i, p := range providers {
		got, err := normalizeProviderURL(p.URL)
		if err == nil && got == want {
			return i, true
		}
	}
	return -1, false
}

func nextProviderName(providers []Provider) string {
	used := make(map[string]bool, len(providers))
	for _, p := range providers {
		used[strings.ToLower(strings.TrimSpace(p.Name))] = true
	}
	for i := 1; ; i++ {
		name := fmt.Sprintf("Provider %d", i)
		if !used[strings.ToLower(name)] {
			return name
		}
	}
}
