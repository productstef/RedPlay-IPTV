package main

import (
	"fmt"
	"net/url"
	"strings"
)

func normalizeProviderURL(raw string) (string, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "", fmt.Errorf("URL is empty")
	}
	u, err := url.Parse(raw)
	if err != nil || u.Host == "" {
		return "", fmt.Errorf("invalid URL")
	}
	u.Scheme = strings.ToLower(u.Scheme)
	if u.Scheme != "http" && u.Scheme != "https" {
		return "", fmt.Errorf("URL must start with http:// or https://")
	}
	u.Host = strings.ToLower(u.Host)
	u.Fragment = ""
	return u.String(), nil
}

func findProviderByURL(providers []Provider, raw string) (int, bool) {
	want, err := normalizeProviderURL(raw)
	if err != nil {
		return -1, false
	}
	for i, p := range providers {
		got, err := normalizeProviderURL(p.URL)
		if err == nil && got == want {
			return i, true
		}
	}
	return -1, false
}

func nextProviderName(providers []Provider) string {
	used := make(map[string]bool, len(providers))
	for _, p := range providers {
		used[strings.ToLower(strings.TrimSpace(p.Name))] = true
	}
	for i := 1; ; i++ {
		name := fmt.Sprintf("Provider %d", i)
		if !used[strings.ToLower(name)] {
			return name
		}
	}
}
