package main

import (
	"testing"
	"time"
)

func TestLibrarySeekShouldHideAfterTwoSeconds(t *testing.T) {
	start := time.Unix(100, 0)
	if librarySeekShouldHide(start.Add(1999*time.Millisecond), start, false) {
		t.Fatal("seek bar hid before two seconds")
	}
	if !librarySeekShouldHide(start.Add(2*time.Second), start, false) {
		t.Fatal("seek bar did not hide at two seconds")
	}
}

func TestLibrarySeekDoesNotHideWhileDragging(t *testing.T) {
	start := time.Unix(100, 0)
	if librarySeekShouldHide(start.Add(10*time.Second), start, true) {
		t.Fatal("seek bar must remain visible while dragging")
	}
}

func TestLibrarySeekMovementResetsDeadline(t *testing.T) {
	start := time.Unix(100, 0)
	moved := start.Add(1500 * time.Millisecond)
	if librarySeekShouldHide(moved.Add(1500*time.Millisecond), moved, false) {
		t.Fatal("deadline was not reset by activity")
	}
	if !librarySeekShouldHide(moved.Add(2*time.Second), moved, false) {
		t.Fatal("seek bar should hide two seconds after the latest activity")
	}
}
