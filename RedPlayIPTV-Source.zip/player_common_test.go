package main

import (
	"strings"
	"testing"
)

func TestMPVHeaderArgs(t *testing.T) {
	a := mpvHeaderArgs(map[string]string{"User-Agent": "TestUA", "Referer": "http://portal/", "Cookie": "a=b", "Authorization": "Bearer x"})
	joined := strings.Join(a, "\n")
	for _, want := range []string{"--user-agent=TestUA", "--referrer=http://portal/", "Cookie: a=b", "Authorization: Bearer x"} {
		if !strings.Contains(joined, want) {
			t.Fatalf("missing %q in %v", want, a)
		}
	}
}

func TestPreferredAudioPolicy(t *testing.T) {
	cases := []struct {
		name        string
		tracks      []MPVTrack
		want        int
		switchTrack bool
	}{
		{"keep Bulgarian selected", []MPVTrack{{ID: 1, Type: "audio", Lang: "bul", Selected: true}, {ID: 2, Type: "audio", Lang: "eng"}}, 0, false},
		{"keep English selected", []MPVTrack{{ID: 1, Type: "audio", Lang: "eng", Selected: true}, {ID: 2, Type: "audio", Lang: "bul"}}, 0, false},
		{"foreign selected chooses English", []MPVTrack{{ID: 1, Type: "audio", Lang: "deu", Selected: true}, {ID: 2, Type: "audio", Lang: "eng"}}, 2, true},
		{"foreign default chooses English", []MPVTrack{{ID: 1, Type: "audio", Lang: "ita", Default: true}, {ID: 7, Type: "audio", Lang: "en"}}, 7, true},
		{"no English leaves default", []MPVTrack{{ID: 1, Type: "audio", Lang: "deu", Selected: true}}, 0, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			id, ok := preferredAudioTrackID(tc.tracks)
			if ok != tc.switchTrack || id != tc.want {
				t.Fatalf("id=%d ok=%v", id, ok)
			}
		})
	}
}

func TestPreferredBulgarianSubtitle(t *testing.T) {
	id, ok := preferredBulgarianSubtitleID([]MPVTrack{{ID: 3, Type: "sub", Lang: "eng"}, {ID: 9, Type: "sub", Lang: "bg"}})
	if !ok || id != 9 {
		t.Fatalf("id=%d ok=%v", id, ok)
	}
}

func TestPreferredSubtitleTrackID(t *testing.T) {
	cases := []struct {
		name        string
		tracks      []MPVTrack
		want        int
		switchTrack bool
	}{
		{"keep selected subtitle", []MPVTrack{{ID: 1, Type: "sub", Lang: "eng", Selected: true}, {ID: 2, Type: "sub", Lang: "bg"}}, 0, false},
		{"prefer Bulgarian", []MPVTrack{{ID: 1, Type: "sub", Lang: "eng"}, {ID: 2, Type: "sub", Lang: "bg"}}, 2, true},
		{"fallback to English", []MPVTrack{{ID: 3, Type: "sub", Lang: "eng"}, {ID: 4, Type: "sub", Lang: "spa"}}, 3, true},
		{"fallback to default", []MPVTrack{{ID: 5, Type: "sub", Lang: "spa", Default: true}, {ID: 6, Type: "sub", Lang: "ita"}}, 5, true},
		{"fallback to first", []MPVTrack{{ID: 7, Type: "sub", Lang: "ita"}, {ID: 8, Type: "sub", Lang: "spa"}}, 7, true},
		{"no subtitles", []MPVTrack{{ID: 9, Type: "audio", Lang: "eng"}}, 0, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			id, ok := preferredSubtitleTrackID(tc.tracks)
			if ok != tc.switchTrack || id != tc.want {
				t.Fatalf("id=%d ok=%v", id, ok)
			}
		})
	}
}
