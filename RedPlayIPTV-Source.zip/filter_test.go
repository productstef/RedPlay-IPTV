package main

import (
	"fmt"
	"testing"
	"time"
)

func TestBuildChannelListItems(t *testing.T) {
	chs := []Channel{{Name: "BNT 1", Group: "BG", URL: "http://x/1"}, {Name: "Nova TV", Group: "BG", URL: "http://x/2"}, {Name: "CNN", Group: "News", URL: "http://x/3"}}
	fav := map[string]bool{channelKey(chs[1]): true}
	got := buildChannelListItems(chs, "BG", "tv", false, fav)
	if len(got) != 1 || got[0].Index != 1 || got[0].Label != "★ Nova TV" {
		t.Fatalf("unexpected filter result: %#v", got)
	}
}

func TestBuildChannelListItemsLargePlaylist(t *testing.T) {
	chs := make([]Channel, 50000)
	for i := range chs {
		chs[i] = Channel{Name: fmt.Sprintf("Channel %05d", i), Group: fmt.Sprintf("Group %02d", i%40), URL: fmt.Sprintf("http://example.test/live/%d", i)}
	}
	start := time.Now()
	got := buildChannelListItems(chs, "Group 07", "channel", false, nil)
	if len(got) != 1250 {
		t.Fatalf("got %d entries, want 1250", len(got))
	}
	if time.Since(start) > 2*time.Second {
		t.Fatalf("filter is unexpectedly slow: %v", time.Since(start))
	}
}

func TestBuildChannelListItemsCanBeCancelled(t *testing.T) {
	chs := make([]Channel, 10000)
	for i := range chs {
		chs[i] = Channel{Name: fmt.Sprintf("Channel %05d", i), URL: fmt.Sprintf("http://example.test/%d", i)}
	}
	checks := 0
	got := buildChannelListItemsCancelable(chs, "", "channel", false, nil, func() bool {
		checks++
		return checks >= 2
	})
	if got != nil {
		t.Fatalf("cancelled filter returned %d items", len(got))
	}
	if checks < 2 {
		t.Fatalf("cancellation callback was not polled: %d", checks)
	}
}
