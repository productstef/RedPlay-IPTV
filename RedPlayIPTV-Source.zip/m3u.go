package main

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"net/url"
	"regexp"
	"strings"
	"unicode/utf8"
)

func decodePlaylistText(s string) string {
	raw := []byte(s)
	if len(raw) >= 2 && ((raw[0] == 0xff && raw[1] == 0xfe) || (raw[0] == 0xfe && raw[1] == 0xff)) {
		le := raw[0] == 0xff
		runes := make([]rune, 0, (len(raw)-2)/2)
		for i := 2; i+1 < len(raw); i += 2 {
			var u uint16
			if le {
				u = uint16(raw[i]) | uint16(raw[i+1])<<8
			} else {
				u = uint16(raw[i])<<8 | uint16(raw[i+1])
			}
			if u == 0 {
				continue
			}
			runes = append(runes, rune(u))
		}
		return string(runes)
	}
	if utf8.ValidString(s) {
		return s
	}
	// Common legacy encoding for Bulgarian/Russian IPTV lists: Windows-1251.
	return decodeWindows1251(raw)
}

func decodeWindows1251(raw []byte) string {
	table := []rune{
		'Ђ', 'Ѓ', '‚', 'ѓ', '„', '…', '†', '‡', '€', '‰', 'Љ', '‹', 'Њ', 'Ќ', 'Ћ', 'Џ',
		'ђ', '‘', '’', '“', '”', '•', '–', '—', '�', '™', 'љ', '›', 'њ', 'ќ', 'ћ', 'џ',
		'\u00a0', 'Ў', 'ў', 'Ј', '¤', 'Ґ', '¦', '§', 'Ё', '©', 'Є', '«', '¬', '\u00ad', '®', 'Ї',
		'°', '±', 'І', 'і', 'ґ', 'µ', '¶', '·', 'ё', '№', 'є', '»', 'ј', 'Ѕ', 'ѕ', 'ї',
	}
	var b strings.Builder
	for _, by := range raw {
		if by < 0x80 {
			b.WriteByte(by)
			continue
		}
		if by >= 0xC0 {
			b.WriteRune(rune('А') + rune(by-0xC0))
			continue
		}
		idx := int(by) - 0x80
		if idx >= 0 && idx < len(table) {
			b.WriteRune(table[idx])
		} else {
			b.WriteRune('�')
		}
	}
	return b.String()
}

func extinfComma(line string) int {
	quote := byte(0)
	for i := 0; i < len(line); i++ {
		c := line[i]
		if quote != 0 {
			if c == quote {
				quote = 0
			}
			continue
		}
		if c == '"' || c == '\'' {
			quote = c
			continue
		}
		if c == ',' {
			return i
		}
	}
	return -1
}

var attrRE = regexp.MustCompile(`([A-Za-z0-9_-]+)=(?:"([^"]*)"|'([^']*)'|([^\s]+))`)

func parseAttrs(s string) map[string]string {
	out := map[string]string{}
	for _, m := range attrRE.FindAllStringSubmatch(s, -1) {
		v := m[2]
		if v == "" {
			v = m[3]
		}
		if v == "" {
			v = m[4]
		}
		out[strings.ToLower(m[1])] = v
	}
	return out
}

func safeHeaders(in map[string]string) map[string]string {
	allowed := map[string]string{
		"user-agent": "User-Agent", "referer": "Referer", "referrer": "Referer", "origin": "Origin",
		"cookie": "Cookie", "authorization": "Authorization", "accept-language": "Accept-Language",
	}
	out := map[string]string{}
	for k, v := range in {
		ck, ok := allowed[strings.ToLower(strings.TrimSpace(k))]
		if !ok || len(v) > 8192 || strings.TrimSpace(v) == "" {
			continue
		}
		out[ck] = strings.TrimSpace(v)
	}
	return out
}

func mergeHeaders(a, b map[string]string) map[string]string {
	out := map[string]string{}
	for k, v := range a {
		out[k] = v
	}
	for k, v := range b {
		out[k] = v
	}
	return out
}

func parseHeaderPairs(s string) map[string]string {
	out := map[string]string{}
	s = strings.ReplaceAll(s, "|", "&")
	if vals, err := url.ParseQuery(s); err == nil {
		for k, v := range vals {
			if len(v) > 0 {
				out[k] = v[len(v)-1]
			}
		}
	}
	return safeHeaders(out)
}

func splitStreamURLHeaders(raw string) (string, map[string]string) {
	// IPTV providers often append request headers to a stream URL: URL|User-Agent=...&Referer=...
	parts := strings.SplitN(strings.TrimSpace(raw), "|", 2)
	if len(parts) == 1 {
		return parts[0], map[string]string{}
	}
	return parts[0], parseHeaderPairs(parts[1])
}

func resolveURL(base, raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return ""
	}
	u, err := url.Parse(raw)
	if err != nil {
		return raw
	}
	if u.IsAbs() || base == "" {
		return u.String()
	}
	b, err := url.Parse(base)
	if err != nil {
		return raw
	}
	return b.ResolveReference(u).String()
}

func firstEPGURL(raw string) string {
	for _, s := range regexp.MustCompile(`[;,]`).Split(raw, -1) {
		if s = strings.TrimSpace(s); s != "" {
			return s
		}
	}
	return ""
}

func ParseM3U(text, baseURL string) Playlist {
	pl, _ := ParseM3UContext(context.Background(), text, baseURL)
	return pl
}

// ParseM3UContext is the provider-load path. Unlike the compatibility wrapper
// above it is cancellable, so switching/deleting a provider does not leave a
// large stale playlist parse consuming CPU in the background.
func ParseM3UContext(ctx context.Context, text, baseURL string) (Playlist, error) {
	if err := ctx.Err(); err != nil {
		return Playlist{}, err
	}
	text = decodePlaylistText(text)
	if err := ctx.Err(); err != nil {
		return Playlist{}, err
	}
	text = strings.TrimPrefix(text, "\ufeff")
	sc := bufio.NewScanner(strings.NewReader(text))
	buf := make([]byte, 64*1024)
	sc.Buffer(buf, 8*1024*1024)
	out := Playlist{}
	var pending *Channel
	var extGroup string
	lineNo := 0
	for sc.Scan() {
		lineNo++
		if lineNo&255 == 0 {
			if err := ctx.Err(); err != nil {
				return out, err
			}
		}
		line := strings.TrimSpace(strings.TrimSuffix(sc.Text(), "\r"))
		if line == "" {
			continue
		}
		if strings.HasPrefix(strings.ToUpper(line), "#EXTM3U") {
			a := parseAttrs(line)
			e := a["url-tvg"]
			if e == "" {
				e = a["x-tvg-url"]
			}
			if e != "" {
				out.EPGURL = resolveURL(baseURL, firstEPGURL(e))
			}
			continue
		}
		if strings.HasPrefix(strings.ToUpper(line), "#EXTINF:") {
			comma := extinfComma(line)
			meta, display := line, ""
			if comma >= 0 {
				meta = line[:comma]
				display = strings.TrimSpace(line[comma+1:])
			}
			a := parseAttrs(meta)
			name := display
			if name == "" {
				name = a["tvg-name"]
			}
			if name == "" {
				name = a["tvg-id"]
			}
			if name == "" {
				name = "Unnamed channel"
			}
			group := a["group-title"]
			if group == "" {
				group = extGroup
			}
			if group == "" {
				group = "Other"
			}
			id := a["tvg-id"]
			if id == "" {
				id = a["tvg-name"]
			}
			if id == "" {
				id = name
			}
			pending = &Channel{ID: id, Name: name, TVGID: a["tvg-id"], TVGName: a["tvg-name"], Logo: a["tvg-logo"], Group: group, Language: a["tvg-language"], Headers: map[string]string{}}
			continue
		}
		if strings.HasPrefix(strings.ToUpper(line), "#EXTGRP:") {
			extGroup = strings.TrimSpace(line[len("#EXTGRP:"):])
			if pending != nil && pending.Group == "Other" && extGroup != "" {
				pending.Group = extGroup
			}
			continue
		}
		if pending != nil && strings.HasPrefix(strings.ToUpper(line), "#EXTVLCOPT:") {
			opt := line[len("#EXTVLCOPT:"):]
			if i := strings.Index(opt, "="); i > 0 {
				k, v := strings.ToLower(strings.TrimSpace(opt[:i])), strings.TrimSpace(opt[i+1:])
				switch k {
				case "http-user-agent":
					pending.Headers = mergeHeaders(pending.Headers, safeHeaders(map[string]string{"User-Agent": v}))
				case "http-referrer", "http-referer":
					pending.Headers = mergeHeaders(pending.Headers, safeHeaders(map[string]string{"Referer": v}))
				case "http-origin":
					pending.Headers = mergeHeaders(pending.Headers, safeHeaders(map[string]string{"Origin": v}))
				case "http-cookie":
					pending.Headers = mergeHeaders(pending.Headers, safeHeaders(map[string]string{"Cookie": v}))
				}
			}
			continue
		}
		if pending != nil && strings.HasPrefix(strings.ToUpper(line), "#EXTHTTP:") {
			var m map[string]string
			if json.Unmarshal([]byte(strings.TrimSpace(line[len("#EXTHTTP:"):])), &m) == nil {
				pending.Headers = mergeHeaders(pending.Headers, safeHeaders(m))
			}
			continue
		}
		if pending != nil && strings.HasPrefix(strings.ToUpper(line), "#KODIPROP:INPUTSTREAM.ADAPTIVE.STREAM_HEADERS=") {
			if i := strings.Index(line, "="); i >= 0 {
				pending.Headers = mergeHeaders(pending.Headers, parseHeaderPairs(line[i+1:]))
			}
			continue
		}
		if strings.HasPrefix(line, "#") {
			continue
		}
		if pending != nil {
			rawURL, h := splitStreamURLHeaders(line)
			pending.URL = resolveURL(baseURL, rawURL)
			pending.Headers = mergeHeaders(pending.Headers, h)
			out.Channels = append(out.Channels, *pending)
			pending = nil
		}
	}
	if err := sc.Err(); err != nil {
		return out, fmt.Errorf("read M3U: %w", err)
	}
	if err := ctx.Err(); err != nil {
		return out, err
	}
	return out, nil
}

func normalizeName(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	var b strings.Builder
	space := false
	for _, r := range s {
		ok := (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || (r >= 'а' && r <= 'я') || r == 'ъ' || r == 'ь' || r == 'ѝ'
		if ok {
			b.WriteRune(r)
			space = false
		} else if !space {
			b.WriteByte(' ')
			space = true
		}
	}
	return strings.Join(strings.Fields(b.String()), " ")
}

func channelKey(c Channel) string {
	if c.TVGID != "" {
		return "id:" + c.TVGID
	}
	return "url:" + c.URL
}
