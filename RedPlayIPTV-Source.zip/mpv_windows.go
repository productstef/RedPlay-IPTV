//go:build windows

package main

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type MPVPlayer struct {
	lifecycleMu sync.Mutex
	mu          sync.Mutex
	ipcMu       sync.Mutex
	cmd         *exec.Cmd
	pipe        string
	exe         string
	requestID   int64
	volume      int
	muted       bool
	current     Channel
	done        chan struct{}
	job         uintptr
}

func NewMPVPlayer() *MPVPlayer { return &MPVPlayer{volume: 80} }

func (p *MPVPlayer) detachCurrent() (*exec.Cmd, string, chan struct{}, uintptr) {
	p.mu.Lock()
	cmd, pipe, done, job := p.cmd, p.pipe, p.done, p.job
	p.cmd = nil
	p.pipe = ""
	p.exe = ""
	p.current = Channel{}
	p.done = nil
	p.job = 0
	p.mu.Unlock()
	return cmd, pipe, done, job
}

func terminateDetached(cmd *exec.Cmd, job uintptr) {
	if cmd != nil && cmd.Process != nil {
		_ = cmd.Process.Kill()
	}
	closeWinHandle(job)
}

// Abort is intentionally IPC-free. It is safe to invoke from shutdown and
// provider-switch paths because it never waits for a named-pipe response.
func (p *MPVPlayer) Abort() {
	cmd, _, _, job := p.detachCurrent()
	terminateDetached(cmd, job)
}

func (p *MPVPlayer) CurrentToken() string {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.pipe
}

// AbortIfToken prevents an asynchronous cleanup request for an old channel
// from killing a newer mpv process that started before the goroutine ran.
func (p *MPVPlayer) AbortIfToken(token string) {
	if token == "" {
		return
	}
	var cmd *exec.Cmd
	var job uintptr
	p.mu.Lock()
	if p.pipe == token && p.cmd != nil {
		cmd, job = p.cmd, p.job
		p.cmd = nil
		p.pipe = ""
		p.exe = ""
		p.current = Channel{}
		p.done = nil
		p.job = 0
	}
	p.mu.Unlock()
	if cmd != nil {
		terminateDetached(cmd, job)
	}
}

func (p *MPVPlayer) Start(ctx context.Context, exe string, hwnd uintptr, ch Channel, headers map[string]string, volume, subtitleSize int) error {
	// Serialize complete player transitions. Without this, rapid channel changes
	// can interleave Start/Stop and overwrite the active cmd/pipe/job tuple.
	p.lifecycleMu.Lock()
	defer p.lifecycleMu.Unlock()

	// Channel replacement should be immediate, not a graceful IPC shutdown.
	// Killing the previous mpv also closes its server pipe and releases old IPC.
	oldCmd, _, _, oldJob := p.detachCurrent()
	terminateDetached(oldCmd, oldJob)

	select {
	case <-ctx.Done():
		return ctx.Err()
	default:
	}
	if hwnd == 0 {
		return fmt.Errorf("video host is not ready")
	}
	pipe := `\\.\pipe\redplay-mpv-` + strconv.Itoa(os.Getpid()) + "-" + strconv.FormatInt(time.Now().UnixNano(), 10)
	subtitleSize = normalizeSubtitleSize(subtitleSize)
	args := []string{
		"--no-config", "--no-terminal", "--idle=no", "--keep-open=no", "--force-window=no",
		"--osc=no", "--osd-level=0", "--input-default-bindings=no", "--input-vo-keyboard=no",
		"--hwdec=auto-safe", "--vo=gpu-next,gpu", "--audio-display=no", "--cache=yes", "--cache-secs=15",
		"--volume=" + strconv.Itoa(volume), "--sub-font-size=" + strconv.Itoa(subtitleSize), "--sub-ass-override=force",
		"--wid=" + strconv.FormatUint(uint64(hwnd), 10), "--input-ipc-server=" + pipe,
		"--title=RedPlay IPTV", "--audio-client-name=RedPlay IPTV",
	}
	args = append(args, mpvHeaderArgs(headers)...)
	args = append(args, ch.URL)
	cmd := hiddenCommandContext(ctx, exe, args...)
	cmd.Dir = filepath.Dir(exe)
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("could not start native player: %w", err)
	}
	done := make(chan struct{})
	job, _ := makeKillJob(cmd.Process.Pid)
	p.mu.Lock()
	p.cmd, p.pipe, p.exe, p.current, p.volume, p.done, p.job = cmd, pipe, exe, ch, volume, done, job
	p.muted = false
	p.mu.Unlock()
	go func(c *exec.Cmd, d chan struct{}) {
		_ = c.Wait()
		close(d)
		var jobToClose uintptr
		p.mu.Lock()
		if p.cmd == c {
			p.cmd = nil
			p.pipe = ""
			p.done = nil
			jobToClose = p.job
			p.job = 0
		}
		p.mu.Unlock()
		closeWinHandle(jobToClose)
	}(cmd, done)
	if err := p.waitPipe(ctx, cmd, pipe, 6*time.Second); err != nil {
		// Only the owner that successfully detaches this exact process closes
		// its job handle. If the wait goroutine already cleared it, it owns cleanup.
		var jobToClose uintptr
		owned := false
		p.mu.Lock()
		if p.cmd == cmd {
			p.cmd = nil
			p.pipe = ""
			p.done = nil
			jobToClose = p.job
			p.job = 0
			owned = true
		}
		p.mu.Unlock()
		if owned {
			terminateDetached(cmd, jobToClose)
		}
		return fmt.Errorf("native player IPC failed: %w", err)
	}
	return nil
}

func (p *MPVPlayer) waitPipe(ctx context.Context, expected *exec.Cmd, pipe string, timeout time.Duration) error {
	end := time.Now().Add(timeout)
	for time.Now().Before(end) {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}
		p.mu.Lock()
		running := p.cmd == expected && p.pipe == pipe
		p.mu.Unlock()
		if !running {
			return fmt.Errorf("player exited during startup")
		}
		if f, err := os.OpenFile(pipe, os.O_RDWR, 0); err == nil {
			_ = f.Close()
			return nil
		}
		t := time.NewTimer(75 * time.Millisecond)
		select {
		case <-ctx.Done():
			t.Stop()
			return ctx.Err()
		case <-t.C:
		}
	}
	return fmt.Errorf("timed out waiting for player")
}

func (p *MPVPlayer) Stop() {
	p.lifecycleMu.Lock()
	defer p.lifecycleMu.Unlock()

	cmd, pipe, done, job := p.detachCurrent()
	if cmd == nil {
		return
	}
	if pipe != "" {
		p.ipcMu.Lock()
		_, _ = mpvPipeCommand(pipe, []any{"quit"}, 500*time.Millisecond, atomic.AddInt64(&p.requestID, 1))
		p.ipcMu.Unlock()
	}
	if done != nil {
		select {
		case <-done:
			closeWinHandle(job)
			return
		case <-time.After(700 * time.Millisecond):
		}
	}
	terminateDetached(cmd, job)
}

func (p *MPVPlayer) IsRunning() bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.cmd != nil
}

func mpvPipeCommand(pipe string, command []any, timeout time.Duration, reqID int64) (any, error) {
	type response struct {
		Data      any    `json:"data"`
		Error     string `json:"error"`
		RequestID int64  `json:"request_id"`
	}
	type commandResult struct {
		v any
		e error
	}

	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	resultCh := make(chan commandResult, 1)
	var fileMu sync.Mutex
	var active *os.File

	setActive := func(f *os.File) bool {
		fileMu.Lock()
		defer fileMu.Unlock()
		if ctx.Err() != nil {
			return false
		}
		active = f
		return true
	}
	clearActive := func(f *os.File) {
		fileMu.Lock()
		if active == f {
			active = nil
		}
		fileMu.Unlock()
	}
	cancelActive := func() {
		fileMu.Lock()
		f := active
		active = nil
		fileMu.Unlock()
		if f != nil {
			// CancelIoEx cancels a pending ReadFile even when it originated on a
			// different goroutine/thread. Closing alone is not a reliable cancel.
			procCancelIoEx.Call(f.Fd(), 0)
			_ = f.Close()
		}
	}

	go func() {
		var f *os.File
		for {
			if err := ctx.Err(); err != nil {
				resultCh <- commandResult{nil, err}
				return
			}
			var err error
			f, err = os.OpenFile(pipe, os.O_RDWR, 0)
			if err == nil {
				break
			}
			select {
			case <-ctx.Done():
				resultCh <- commandResult{nil, ctx.Err()}
				return
			case <-time.After(30 * time.Millisecond):
			}
		}
		if !setActive(f) {
			_ = f.Close()
			resultCh <- commandResult{nil, ctx.Err()}
			return
		}
		defer func() {
			clearActive(f)
			_ = f.Close()
		}()
		_ = f.SetDeadline(time.Now().Add(timeout))

		payload, _ := json.Marshal(map[string]any{"command": command, "request_id": reqID})
		if _, err := f.Write(append(payload, '\n')); err != nil {
			resultCh <- commandResult{nil, err}
			return
		}
		sc := bufio.NewScanner(f)
		sc.Buffer(make([]byte, 64*1024), 4*1024*1024)
		for sc.Scan() {
			if err := ctx.Err(); err != nil {
				resultCh <- commandResult{nil, err}
				return
			}
			var r response
			if json.Unmarshal(sc.Bytes(), &r) != nil || r.RequestID != reqID {
				continue
			}
			if r.Error != "" && r.Error != "success" {
				resultCh <- commandResult{nil, fmt.Errorf("mpv: %s", r.Error)}
				return
			}
			resultCh <- commandResult{r.Data, nil}
			return
		}
		if err := ctx.Err(); err != nil {
			resultCh <- commandResult{nil, err}
		} else if err := sc.Err(); err != nil {
			resultCh <- commandResult{nil, err}
		} else {
			resultCh <- commandResult{nil, fmt.Errorf("mpv IPC closed")}
		}
	}()

	select {
	case r := <-resultCh:
		return r.v, r.e
	case <-ctx.Done():
		cancelActive()
		return nil, fmt.Errorf("mpv IPC timeout")
	}
}

func (p *MPVPlayer) command(cmd ...any) (any, error) {
	// Snapshot the current pipe before waiting for the IPC lane. After acquiring
	// it, verify the player is still the same so a stale click cannot affect a
	// newly started channel.
	p.mu.Lock()
	pipe := p.pipe
	running := p.cmd != nil
	p.mu.Unlock()
	if !running || pipe == "" {
		return nil, fmt.Errorf("player is not running")
	}
	p.ipcMu.Lock()
	defer p.ipcMu.Unlock()
	p.mu.Lock()
	stillCurrent := p.cmd != nil && p.pipe == pipe
	p.mu.Unlock()
	if !stillCurrent {
		return nil, fmt.Errorf("player changed")
	}
	return mpvPipeCommand(pipe, cmd, 1200*time.Millisecond, atomic.AddInt64(&p.requestID, 1))
}
func (p *MPVPlayer) setProp(name string, v any) error {
	_, e := p.command("set_property", name, v)
	return e
}
func (p *MPVPlayer) TogglePause() error { _, e := p.command("cycle", "pause"); return e }
func (p *MPVPlayer) ToggleMute() error  { _, e := p.command("cycle", "mute"); return e }
func (p *MPVPlayer) SeekAbsolute(seconds float64) error {
	if seconds < 0 {
		seconds = 0
	}
	_, e := p.command("seek", seconds, "absolute+exact")
	return e
}
func (p *MPVPlayer) SetVolume(v int) error {
	if v < 0 {
		v = 0
	}
	if v > 100 {
		v = 100
	}
	p.mu.Lock()
	p.volume = v
	p.mu.Unlock()
	return p.setProp("volume", v)
}
func (p *MPVPlayer) SetSubtitleSize(v int) error {
	return p.setProp("sub-font-size", normalizeSubtitleSize(v))
}
func (p *MPVPlayer) SelectAudio(id int) error    { return p.setProp("aid", id) }
func (p *MPVPlayer) SelectSubtitle(id int) error { return p.setProp("sid", id) }
func (p *MPVPlayer) DisableSubtitles() error     { return p.setProp("sid", "no") }
func (p *MPVPlayer) AddSubtitle(rawURL, title, lang string) error {
	if title == "" {
		title = "External subtitle"
	}
	if lang == "" {
		lang = "und"
	}
	_, e := p.command("sub-add", rawURL, "auto", title, lang)
	return e
}

func asInt(v any) int {
	switch x := v.(type) {
	case float64:
		return int(x)
	case int:
		return x
	case json.Number:
		n, _ := x.Int64()
		return int(n)
	}
	return 0
}
func asString(v any) string {
	if s, ok := v.(string); ok {
		return s
	}
	return ""
}
func asBool(v any) bool { b, _ := v.(bool); return b }

func (p *MPVPlayer) Tracks() ([]MPVTrack, error) {
	data, err := p.command("get_property", "track-list")
	if err != nil {
		return nil, err
	}
	arr, ok := data.([]any)
	if !ok {
		return nil, fmt.Errorf("unexpected track-list")
	}
	out := make([]MPVTrack, 0, len(arr))
	for _, v := range arr {
		m, ok := v.(map[string]any)
		if !ok {
			continue
		}
		out = append(out, MPVTrack{ID: asInt(m["id"]), Type: asString(m["type"]), Lang: asString(m["lang"]), Title: asString(m["title"]), Codec: asString(m["codec"]), Selected: asBool(m["selected"]), Default: asBool(m["default"]), Forced: asBool(m["forced"])})
	}
	return out, nil
}

func (p *MPVPlayer) ApplyLanguagePolicy(tracks []MPVTrack, autoSubs bool) {
	if id, ok := preferredAudioTrackID(tracks); ok {
		_ = p.SelectAudio(id)
	}
	if autoSubs {
		if id, ok := preferredSubtitleTrackID(tracks); ok {
			_ = p.SelectSubtitle(id)
		}
	}
}

func (p *MPVPlayer) Property(name string) (any, error) { return p.command("get_property", name) }
func (p *MPVPlayer) Diagnostics() string {
	names := []string{"file-format", "video-codec", "audio-codec-name", "width", "height", "estimated-vf-fps", "demuxer-cache-duration", "paused-for-cache", "aid", "sid"}
	var b strings.Builder
	b.WriteString("Player: native mpv " + mpvEngineVersion + "\r\n")
	for _, n := range names {
		if v, e := p.Property(n); e == nil {
			b.WriteString(n + ": " + fmt.Sprint(v) + "\r\n")
		}
	}
	if tr, e := p.Tracks(); e == nil {
		b.WriteString("tracks:\r\n")
		for _, t := range tr {
			b.WriteString(fmt.Sprintf("  %s #%d lang=%s title=%s codec=%s selected=%v default=%v\r\n", t.Type, t.ID, t.Lang, t.Title, t.Codec, t.Selected, t.Default))
		}
	}
	return b.String()
}
