package main

import (
	"context"
	"errors"
	"strings"
	"testing"
)

func TestParseDirectMPEGTSProvider(t *testing.T) {
	s := `#EXTM3U url-tvg="http://example.test/epg.xml"
#EXTINF:-1 tvg-id="bnt1" tvg-name="BNT 1" group-title="BG",BNT 1
#EXTVLCOPT:http-user-agent=IPTVClient/1.0
http://provider.test:4300/live/user/pass/101.ts
#EXTINF:-1 tvg-id="movie" group-title="Movies",Movie HLS
http://provider.test/live/movie/index.m3u8|Referer=http%3A%2F%2Fportal.test%2F
`
	p := ParseM3U(s, "http://provider.test/list.m3u")
	if len(p.Channels) != 2 {
		t.Fatalf("channels=%d", len(p.Channels))
	}
	if p.Channels[0].URL != "http://provider.test:4300/live/user/pass/101.ts" {
		t.Fatal(p.Channels[0].URL)
	}
	if p.Channels[0].Headers["User-Agent"] != "IPTVClient/1.0" {
		t.Fatal(p.Channels[0].Headers)
	}
	if p.Channels[1].Headers["Referer"] != "http://portal.test/" {
		t.Fatal(p.Channels[1].Headers)
	}
	if p.EPGURL != "http://example.test/epg.xml" {
		t.Fatal(p.EPGURL)
	}
}
func TestRelativeURLs(t *testing.T) {
	p := ParseM3U("#EXTM3U x-tvg-url=\"epg.xml\"\n#EXTINF:-1,One\nlive/1.ts\n", "http://x.test/base/list.m3u")
	if p.EPGURL != "http://x.test/base/epg.xml" || p.Channels[0].URL != "http://x.test/base/live/1.ts" {
		t.Fatalf("%+v", p)
	}
}

func TestChannelNameWithComma(t *testing.T) {
	p := ParseM3U("#EXTM3U\n#EXTINF:-1 tvg-id=\"x\",News, HD\nhttp://x.test/1.ts\n", "http://x.test/list.m3u")
	if len(p.Channels) != 1 || p.Channels[0].Name != "News, HD" {
		t.Fatalf("name=%q", p.Channels[0].Name)
	}
}

func TestWindows1251Playlist(t *testing.T) {
	// "БНТ" in CP1251 is C1 CD D2.
	raw := string([]byte("#EXTM3U\n#EXTINF:-1,")) + string([]byte{0xC1, 0xCD, 0xD2}) + "\nhttp://x.test/1.ts\n"
	p := ParseM3U(raw, "http://x.test/list.m3u")
	if len(p.Channels) != 1 || p.Channels[0].Name != "БНТ" {
		t.Fatalf("decoded name=%q", p.Channels[0].Name)
	}
}

func TestUTF16LEPlaylist(t *testing.T) {
	src := "#EXTM3U\n#EXTINF:-1,БНТ 1\nhttp://x.test/1.ts\n"
	raw := []byte{0xff, 0xfe}
	for _, r := range src {
		raw = append(raw, byte(r), byte(r>>8))
	}
	p := ParseM3U(string(raw), "http://x.test/list.m3u")
	if len(p.Channels) != 1 || p.Channels[0].Name != "БНТ 1" {
		t.Fatalf("utf16 decode: %+v", p.Channels)
	}
}

func TestDirectLiveURLWithoutExtension(t *testing.T) {
	s := "#EXTM3U\n#EXTINF:-1 group-title=\"Live\",Live channel\nhttp://provider.test:4300/mpg/user/pass/501\n"
	p := ParseM3U(s, "http://provider.test:4300/mpg/user/pass/playlist.m3u")
	if len(p.Channels) != 1 {
		t.Fatalf("channels=%d", len(p.Channels))
	}
	if p.Channels[0].URL != "http://provider.test:4300/mpg/user/pass/501" {
		t.Fatalf("url=%s", p.Channels[0].URL)
	}
}

func TestParseM3UContextCancellation(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, err := ParseM3UContext(ctx, strings.Repeat("#EXTINF:-1,One\nhttp://x.test/1.ts\n", 1000), "http://x.test/list.m3u")
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("expected context cancellation, got %v", err)
	}
}
