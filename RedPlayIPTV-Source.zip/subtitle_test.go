package main

import "testing"

func TestWesternSubtitleMaster(t *testing.T) {
	master := `#EXTM3U
#EXT-X-VERSION:3
#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="Bulgarian",LANGUAGE="bg",DEFAULT=YES,AUTOSELECT=YES,FORCED=NO,URI="index_vtt.m3u8"
#EXT-X-STREAM-INF:BANDWIDTH=10000000,SUBTITLES="subs"
index.m3u8`
	got := ParseHLSSubtitleRenditions(master, "http://media.example.test/live/western/western.m3u8")
	if len(got) != 1 {
		t.Fatalf("expected 1 subtitle, got %d", len(got))
	}
	if got[0].Lang != "bg" || got[0].URL != "http://media.example.test/live/western/index_vtt.m3u8" || !got[0].Default {
		t.Fatalf("bad rendition: %+v", got[0])
	}
}
