package main

import (
	"bufio"
	"compress/gzip"
	"context"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"time"
)

var netClient = &http.Client{Timeout: 90 * time.Second, Transport: &http.Transport{Proxy: http.ProxyFromEnvironment, DialContext: (&net.Dialer{Timeout: 12 * time.Second, KeepAlive: 30 * time.Second}).DialContext, TLSHandshakeTimeout: 12 * time.Second, MaxIdleConns: 32, IdleConnTimeout: 60 * time.Second}}

func FetchText(ctx context.Context, rawURL string, headers map[string]string, limit int64) (string, error) {
	if path, ok := providerFilePath(rawURL); ok {
		if limit <= 0 {
			limit = 256 << 20
		}
		f, err := os.Open(path)
		if err != nil {
			return "", err
		}
		defer f.Close()
		lr := &io.LimitedReader{R: f, N: limit + 1}
		b, err := io.ReadAll(lr)
		if err != nil {
			return "", err
		}
		if int64(len(b)) > limit {
			return "", fmt.Errorf("response exceeds %d bytes", limit)
		}
		return string(b), nil
	}
	req, e := http.NewRequestWithContext(ctx, http.MethodGet, rawURL, nil)
	if e != nil {
		return "", e
	}
	req.Header.Set("Accept", "*/*")
	for k, v := range safeHeaders(headers) {
		req.Header.Set(k, v)
	}
	if req.Header.Get("User-Agent") == "" {
		req.Header.Set("User-Agent", "RedPlay-IPTV/0.5.2")
	}
	resp, e := netClient.Do(req)
	if e != nil {
		return "", e
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", fmt.Errorf("server returned %s", resp.Status)
	}
	if limit <= 0 {
		limit = 256 << 20
	}
	lr := &io.LimitedReader{R: resp.Body, N: limit + 1}
	b, e := io.ReadAll(lr)
	if e != nil {
		return "", e
	}
	if int64(len(b)) > limit {
		return "", fmt.Errorf("response exceeds %d bytes", limit)
	}
	return string(b), nil
}

// OpenURL opens a remote resource with the same safe provider headers used by playlists.
// The caller must close the returned body.
func OpenURL(ctx context.Context, rawURL string, headers map[string]string) (io.ReadCloser, error) {
	if path, ok := providerFilePath(rawURL); ok {
		f, err := os.Open(path)
		if err != nil {
			return nil, err
		}
		br := bufio.NewReaderSize(f, 32*1024)
		if sig, _ := br.Peek(2); len(sig) == 2 && sig[0] == 0x1f && sig[1] == 0x8b {
			gz, err := gzip.NewReader(br)
			if err != nil {
				f.Close()
				return nil, fmt.Errorf("gzip stream: %w", err)
			}
			return &multiReadCloser{Reader: gz, closers: []io.Closer{gz, f}}, nil
		}
		return &multiReadCloser{Reader: br, closers: []io.Closer{f}}, nil
	}
	req, e := http.NewRequestWithContext(ctx, http.MethodGet, rawURL, nil)
	if e != nil {
		return nil, e
	}
	req.Header.Set("Accept", "*/*")
	for k, v := range safeHeaders(headers) {
		req.Header.Set(k, v)
	}
	if req.Header.Get("User-Agent") == "" {
		req.Header.Set("User-Agent", "RedPlay-IPTV/0.5.2")
	}
	resp, e := netClient.Do(req)
	if e != nil {
		return nil, e
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		resp.Body.Close()
		return nil, fmt.Errorf("server returned %s", resp.Status)
	}
	// Go transparently decompresses Content-Encoding:gzip. Some XMLTV servers,
	// however, serve a raw .gz file without that header. Detect gzip magic too.
	br := bufio.NewReaderSize(resp.Body, 32*1024)
	if sig, _ := br.Peek(2); len(sig) == 2 && sig[0] == 0x1f && sig[1] == 0x8b {
		gz, err := gzip.NewReader(br)
		if err != nil {
			resp.Body.Close()
			return nil, fmt.Errorf("gzip stream: %w", err)
		}
		return &multiReadCloser{Reader: gz, closers: []io.Closer{gz, resp.Body}}, nil
	}
	return &multiReadCloser{Reader: br, closers: []io.Closer{resp.Body}}, nil
}

type multiReadCloser struct {
	io.Reader
	closers []io.Closer
}

func (m *multiReadCloser) Close() error {
	var first error
	for _, c := range m.closers {
		if err := c.Close(); err != nil && first == nil {
			first = err
		}
	}
	return first
}
