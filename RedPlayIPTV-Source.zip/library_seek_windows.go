//go:build windows

package main

import (
	"context"
	"fmt"
	"math"
	"sync/atomic"
	"time"
	"unsafe"
)

const (
	librarySeekLeftPad  = 62
	librarySeekRightPad = 62
)

func numericFloat(v any) (float64, bool) {
	switch x := v.(type) {
	case float64:
		if math.IsNaN(x) || math.IsInf(x, 0) {
			return 0, false
		}
		return x, true
	case float32:
		f := float64(x)
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return 0, false
		}
		return f, true
	case int:
		return float64(x), true
	case int64:
		return float64(x), true
	case int32:
		return float64(x), true
	}
	return 0, false
}

func formatSeekClock(seconds float64) string {
	if seconds < 0 || math.IsNaN(seconds) || math.IsInf(seconds, 0) {
		seconds = 0
	}
	total := int(seconds + 0.5)
	h := total / 3600
	m := (total % 3600) / 60
	s := total % 60
	if h > 0 {
		return fmt.Sprintf("%d:%02d:%02d", h, m, s)
	}
	return fmt.Sprintf("%02d:%02d", m, s)
}

func (a *App) resetLibrarySeek() {
	a.librarySeekPos = 0
	a.librarySeekDuration = 0
	a.librarySeekDragging = false
	a.librarySeekDragPos = 0
	a.librarySeekHaveMouse = false
	a.librarySeekLastActivity = time.Now()
	a.librarySeekVisible = a.libraryPlaying != nil
	if a.libraryPlaying != nil && a.libraryPlaying.Duration > 0 {
		a.librarySeekDuration = a.libraryPlaying.Duration.Seconds()
	}
	if a.hwnd != 0 {
		if a.libraryPlaying != nil {
			procKillTimer.Call(a.hwnd, 3)
			procSetTimer.Call(a.hwnd, 3, 100, 0)
		} else {
			procKillTimer.Call(a.hwnd, 3)
		}
	}
	if a.librarySeekHwnd != 0 {
		procInvalidateRect.Call(a.librarySeekHwnd, 0, 1)
	}
}

func (a *App) noteLibrarySeekActivity() {
	if a.libraryPlaying == nil {
		return
	}
	a.librarySeekLastActivity = time.Now()
	if !a.librarySeekVisible {
		a.librarySeekVisible = true
		a.layout()
	}
}

func pointInScreenRect(pt POINT, rc RECT) bool {
	return pt.X >= rc.Left && pt.X < rc.Right && pt.Y >= rc.Top && pt.Y < rc.Bottom
}

// updateLibrarySeekAutoHide polls the cursor instead of relying on WM_MOUSEMOVE.
// mpv owns a child window inside videoHost, so mouse movement over the actual
// video surface is not guaranteed to reach RedPlay's main Win32 window.
func (a *App) updateLibrarySeekAutoHide() {
	if a.libraryPlaying == nil {
		if a.librarySeekVisible {
			a.librarySeekVisible = false
			show(a.librarySeekHwnd, false)
		}
		return
	}

	now := time.Now()
	var pt POINT
	if ok, _, _ := procGetCursorPos.Call(uintptr(unsafe.Pointer(&pt))); ok != 0 {
		if !a.librarySeekHaveMouse {
			a.librarySeekLastMouse = pt
			a.librarySeekHaveMouse = true
		} else if pt.X != a.librarySeekLastMouse.X || pt.Y != a.librarySeekLastMouse.Y {
			a.librarySeekLastMouse = pt
			var wr RECT
			if got, _, _ := procGetWindowRect.Call(a.hwnd, uintptr(unsafe.Pointer(&wr))); got != 0 && pointInScreenRect(pt, wr) {
				a.librarySeekLastActivity = now
				if !a.librarySeekVisible {
					a.librarySeekVisible = true
					a.layout()
				}
			}
		}
	}

	if a.librarySeekDragging {
		a.librarySeekLastActivity = now
		if !a.librarySeekVisible {
			a.librarySeekVisible = true
			a.layout()
		}
		return
	}

	if a.librarySeekVisible && librarySeekShouldHide(now, a.librarySeekLastActivity, false) {
		a.librarySeekVisible = false
		show(a.librarySeekHwnd, false)
	}
}

func (a *App) finishLibrarySeekUpdate() {
	a.mu.Lock()
	r := a.pendingLibrarySeek
	a.mu.Unlock()
	if r.gen != atomic.LoadInt64(&a.playGen) || a.libraryPlaying == nil {
		return
	}
	if r.duration > 0 {
		a.librarySeekDuration = r.duration
	}
	if !a.librarySeekDragging && r.position >= 0 {
		a.librarySeekPos = r.position
	}
	if a.librarySeekDuration > 0 && a.librarySeekPos > a.librarySeekDuration {
		a.librarySeekPos = a.librarySeekDuration
	}
	if a.librarySeekHwnd != 0 {
		procInvalidateRect.Call(a.librarySeekHwnd, 0, 0)
	}
}

func (a *App) librarySeekPollLoop(ctx context.Context, gen int64) {
	ticker := time.NewTicker(500 * time.Millisecond)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
		if gen != atomic.LoadInt64(&a.playGen) {
			return
		}
		posValue, posErr := a.player.Property("time-pos")
		if posErr != nil {
			continue
		}
		pos, ok := numericFloat(posValue)
		if !ok {
			continue
		}
		duration := 0.0
		if durationValue, err := a.player.Property("duration"); err == nil {
			if v, ok := numericFloat(durationValue); ok {
				duration = v
			}
		}
		if gen != atomic.LoadInt64(&a.playGen) || ctx.Err() != nil {
			return
		}
		a.mu.Lock()
		a.pendingLibrarySeek = asyncLibrarySeekResult{gen: gen, position: pos, duration: duration}
		a.mu.Unlock()
		post(a.hwnd, msgLibrarySeek, 0, 0)
	}
}

func librarySeekTrackBounds(hwnd uintptr) (RECT, int, int) {
	var rc RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
	left := librarySeekLeftPad
	right := int(rc.Right-rc.Left) - librarySeekRightPad
	if right < left+40 {
		left = 48
		right = maxInt(left+40, int(rc.Right-rc.Left)-48)
	}
	return rc, left, right
}

func (a *App) seekSecondsAtX(hwnd uintptr, x int) float64 {
	_, left, right := librarySeekTrackBounds(hwnd)
	if x < left {
		x = left
	}
	if x > right {
		x = right
	}
	duration := a.librarySeekDuration
	if duration <= 0 && a.libraryPlaying != nil && a.libraryPlaying.Duration > 0 {
		duration = a.libraryPlaying.Duration.Seconds()
	}
	if duration <= 0 || right <= left {
		return 0
	}
	return duration * float64(x-left) / float64(right-left)
}

func (a *App) commitLibrarySeek(seconds float64) {
	if a.libraryPlaying == nil || a.librarySeekDuration <= 0 {
		return
	}
	if seconds < 0 {
		seconds = 0
	}
	if seconds > a.librarySeekDuration {
		seconds = a.librarySeekDuration
	}
	a.librarySeekPos = seconds
	if a.librarySeekHwnd != 0 {
		procInvalidateRect.Call(a.librarySeekHwnd, 0, 0)
	}
	target := seconds
	a.runLatestPlayerAction("Seek", &a.seekActionGen, func() error {
		return a.player.SeekAbsolute(target)
	})
}

func librarySeekWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	a := gApp
	if a == nil {
		r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
		return r
	}
	switch msg {
	case WM_PAINT:
		a.paintLibrarySeek(hwnd)
		return 0
	case WM_ERASEBKGND:
		return 1
	case WM_LBUTTONDOWN:
		a.noteLibrarySeekActivity()
		if a.libraryPlaying == nil || a.librarySeekDuration <= 0 {
			return 0
		}
		a.librarySeekDragging = true
		a.librarySeekDragPos = a.seekSecondsAtX(hwnd, int(int16(loWord(lParam))))
		procSetCapture.Call(hwnd)
		procInvalidateRect.Call(hwnd, 0, 0)
		return 0
	case WM_MOUSEMOVE:
		if a.librarySeekDragging {
			a.noteLibrarySeekActivity()
			a.librarySeekDragPos = a.seekSecondsAtX(hwnd, int(int16(loWord(lParam))))
			procInvalidateRect.Call(hwnd, 0, 0)
			return 0
		}
	case WM_LBUTTONUP:
		if a.librarySeekDragging {
			a.noteLibrarySeekActivity()
			target := a.seekSecondsAtX(hwnd, int(int16(loWord(lParam))))
			a.librarySeekDragPos = target
			a.librarySeekDragging = false
			procReleaseCapture.Call()
			a.commitLibrarySeek(target)
			return 0
		}
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func (a *App) paintLibrarySeek(hwnd uintptr) {
	var ps PAINTSTRUCT
	hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	defer procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))

	rc, left, right := librarySeekTrackBounds(hwnd)
	fillSolid(hdc, rc, rgb(8, 12, 18))

	position := a.librarySeekPos
	if a.librarySeekDragging {
		position = a.librarySeekDragPos
	}
	duration := a.librarySeekDuration
	if duration <= 0 && a.libraryPlaying != nil && a.libraryPlaying.Duration > 0 {
		duration = a.libraryPlaying.Duration.Seconds()
	}
	if duration > 0 && position > duration {
		position = duration
	}

	if a.fontSmall != 0 {
		procSelectObject.Call(hdc, a.fontSmall)
	}
	drawTextRect(hdc, RECT{Left: 5, Top: 4, Right: int32(left - 5), Bottom: rc.Bottom - 3}, formatSeekClock(position), rgb(224, 232, 240), DT_RIGHT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)
	drawTextRect(hdc, RECT{Left: int32(right + 5), Top: 4, Right: rc.Right - 5, Bottom: rc.Bottom - 3}, formatSeekClock(duration), rgb(166, 180, 194), DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)

	midY := int(rc.Bottom-rc.Top) / 2
	bar := RECT{Left: int32(left), Top: int32(midY - 3), Right: int32(right), Bottom: int32(midY + 3)}
	drawRoundRect(hdc, bar, rgb(48, 58, 70), rgb(48, 58, 70), 6)

	knobX := left
	if duration > 0 && right > left {
		frac := position / duration
		if frac < 0 {
			frac = 0
		}
		if frac > 1 {
			frac = 1
		}
		knobX = left + int(frac*float64(right-left))
		progress := RECT{Left: int32(left), Top: int32(midY - 3), Right: int32(knobX), Bottom: int32(midY + 3)}
		if progress.Right > progress.Left {
			drawRoundRect(hdc, progress, rgb(255, 59, 72), rgb(255, 59, 72), 6)
		}
	}
	knob := RECT{Left: int32(knobX - 6), Top: int32(midY - 6), Right: int32(knobX + 6), Bottom: int32(midY + 6)}
	drawRoundRect(hdc, knob, rgb(245, 247, 250), rgb(255, 59, 72), 12)
}
