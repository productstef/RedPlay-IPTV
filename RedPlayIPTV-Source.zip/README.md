# RedPlay IPTV 0.6.2

A native Windows x64 IPTV player. The UI is Win32 and does not use Edge, WebView2,
Chrome, Chromium, Electron, Tauri, localhost web pages, or a browser media stack.

## Playback

RedPlay launches a verified portable mpv 0.41.0 media engine as an embedded native
video child window and controls it through a local Windows named pipe. This gives
native FFmpeg/mpv support for HTTP MPEG-TS, HLS, HEVC/H.265, H.264, AV1, AAC,
AC3/EAC3 and other formats supported by the pinned mpv build without transcoding.

On first run RedPlay downloads the official mpv Windows x64 CI asset, verifies its
SHA-256, extracts it with zip-slip protection and self-checks `mpv.exe`. No media
player or browser runtime needs to be installed on the PC beforehand.

Pinned engine:
- mpv 0.41.0 official Windows x64 MinGW CI release
- SHA-256: a49811c0752c108b8260636f9c6f6fcb97406641c98b30f1e7b500dfb20177de

The official MinGW release can contain a nested portable zip. RedPlay explicitly
handles both flat and nested official package layouts.

## 0.5.2 stability hardening

This release is based on a fresh audit of both 0.5.1 source branches. The later
0.5.1 package had unintentionally lost some of the earlier Stability branch's
UI protections, so 0.5.2 consolidates those fixes and hardens the lifecycle
around them.

- The Win32 UI/message pump is permanently locked to one OS thread with
  `runtime.LockOSThread`, matching Win32's thread-affine message-queue model.
- Pause, Mute, Volume, Audio and Subtitle IPC never wait on the UI thread.
- Player Start/Stop transitions are serialized so rapid channel changes cannot
  overwrite or cross-clean another mpv process/pipe/job tuple.
- Stale IPC commands verify the active player token after acquiring the IPC lane
  and are rejected if the channel changed in the meantime.
- Timed-out named-pipe reads are actively interrupted with Windows `CancelIoEx`.
- Provider changes invalidate old playback, EPG, filtering and provider-load
  generations before the new provider becomes interactive.
- Obsolete provider/EPG/track workers are prevented from overwriting newer
  pending results.
- Search/filter computation is debounced and performed off the Win32 UI thread;
  list rows are inserted in small batches to keep the message pump responsive.
- M3U and XMLTV parsing is cancellable when a provider changes.
- Legacy Windows-1251/Latin-1 XMLTV conversion is streaming rather than reading
  the complete EPG into RAM before parsing.
- State persistence is snapshotted/debounced off the UI thread and can recover
  from a valid `.tmp` or `.bak` if the primary state file is missing/corrupt.
- Closing the app never waits for graceful mpv IPC; the Windows Job Object is the
  hard process-cleanup guarantee.
- A UI watchdog writes `%LOCALAPPDATA%\RedPlay IPTV\redplay-hang.log` with all Go
  goroutine stacks if the message loop stops responding for more than 7 seconds.


## 0.5.6 UI / responsiveness

- Added a real video fullscreen mode with an in-player fullscreen button.
- `F11` toggles fullscreen from any focused control; `Esc` exits fullscreen.
- Fullscreen uses a borderless monitor-sized native window and expands the existing mpv video host; playback is not restarted.
- Removed the unused Series, Favorites and Recordings navigation buttons.
- Responsive breakpoints prioritize video: the decorative navigation rail collapses first, then the detailed right rail.
- When the right rail is hidden, Audio and Subtitle selectors move below the player controls instead of disappearing.
- On very narrow player widths, less-essential Favorite/Details and separate volume +/- controls collapse to prevent overlap.
- Now Playing / Up Next cards remove their thumbnail gutter when space is tight.

## IPTV features

- Unlimited remote M3U/M3U8 provider records
- Direct HTTP MPEG-TS/live channel URLs, including custom ports and URLs without extensions
- HLS playback
- Provider and per-channel User-Agent / Referer / Origin / Cookie / Authorization headers
- Relative channel and EPG URLs
- Windows-1251 and UTF-16 playlists
- Persistent providers, favorites, last provider and settings
- XMLTV auto-discovery from `url-tvg` and `x-tvg-url`
- Streaming XMLTV parser, timezone and timezone-less timestamps
- Raw `.gz` XMLTV support and Windows-1251 XMLTV support
- Exact `tvg-id` matching, with unambiguous normalized-name fallback
- Now/Next and full guide
- Native audio/subtitle track selectors
- Bulgarian subtitle auto-selection
- HLS `#EXT-X-MEDIA:TYPE=SUBTITLES` discovery and Bulgarian WebVTT fallback
- Native playback diagnostics

## State

State is stored at `%LOCALAPPDATA%\RedPlay IPTV\state.json` using atomic-ish
`tmp -> state` replacement with a `.bak` rollback copy. Browser-era RedPlay state
keys are migrated so existing providers and favorites are retained when possible.

## Security and lifecycle

- No browser runtime dependency
- No local HTTP server
- One RedPlay instance per Windows user
- mpv child process is assigned to a Windows Job Object with KILL_ON_JOB_CLOSE
- mpv is also stopped gracefully through JSON IPC on normal app exit
- Provider input is parsed as data and never executed
- Media engine archive checksum is pinned and verified before extraction

The installer is unsigned, so Windows SmartScreen may show an Unknown publisher warning.

## 0.5.7 universal subtitle size

- Adds only subtitle-edit UI elements to the existing 0.5.6 layout: an inline global size control next to/below the subtitle selector.
- Default text-subtitle size is 40, adjustable from 24 to 60 in steps of 2.
- The size is stored in the existing per-user state and applied to mpv at startup and live over IPC without restarting the stream.
- mpv text subtitle styling is forced so the global size wins over source text-subtitle styling. Image-based bitmap subtitles are unaffected.
- All non-subtitle functionality and the existing responsive/fullscreen layout behavior are otherwise unchanged.


## 0.6.1 built-in channels and Add Provider fix

- Western and Star Wars are seeded as default providers for fresh installs and are migrated once for existing users that do not already have them.
- Add Provider hides the embedded mpv video host while the modal is open so video cannot cover the form.
- Add Provider validates HTTP(S) playlist/EPG URLs and prevents duplicate playlist URLs.
- GitHub updater remains enabled through the in-app Check for updates control.
