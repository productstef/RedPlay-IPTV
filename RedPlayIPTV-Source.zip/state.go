package main

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sync"
)

var stateMu sync.Mutex

const currentDefaultsVersion = 1

func statePath() string {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		if d, e := os.UserConfigDir(); e == nil {
			base = d
		} else {
			base = os.TempDir()
		}
	}
	d := filepath.Join(base, "RedPlay IPTV")
	_ = os.MkdirAll(d, 0755)
	return filepath.Join(d, "state.json")
}

func builtInProviders() []Provider {
	return []Provider{
		{ID: "builtin-western", Name: "Western", URL: "http://92.5.59.81/western/playlist.m3u"},
		{ID: "builtin-starwars", Name: "Star Wars", URL: "http://92.5.59.81/starwars.m3u"},
	}
}

func defaultState() AppState {
	providers := builtInProviders()
	last := ""
	if len(providers) > 0 {
		last = providers[0].ID
	}
	return AppState{Providers: providers, Favorites: []string{}, LastProvider: last, Settings: defaultSettings(), DefaultsVersion: currentDefaultsVersion}
}

func mergeBuiltInProviders(s *AppState) {
	if s == nil {
		return
	}
	for _, builtin := range builtInProviders() {
		if _, ok := findProviderByURL(s.Providers, builtin.URL); ok {
			continue
		}
		duplicateID := false
		for _, p := range s.Providers {
			if p.ID == builtin.ID {
				duplicateID = true
				break
			}
		}
		if !duplicateID {
			s.Providers = append(s.Providers, builtin)
		}
	}
	if s.LastProvider == "" && len(s.Providers) > 0 {
		s.LastProvider = s.Providers[0].ID
	}
}

func readJSONMap(path string) (map[string]json.RawMessage, error) {
	b, e := os.ReadFile(path)
	if os.IsNotExist(e) {
		return map[string]json.RawMessage{}, nil
	}
	if e != nil {
		return nil, e
	}
	if len(b) == 0 {
		return map[string]json.RawMessage{}, nil
	}
	var m map[string]json.RawMessage
	if e = json.Unmarshal(b, &m); e != nil {
		return nil, e
	}
	return m, nil
}

func LoadState() (AppState, error) {
	stateMu.Lock()
	defer stateMu.Unlock()
	path := statePath()
	var m map[string]json.RawMessage
	var firstErr error
	// Primary is authoritative. A fully written .tmp is newer than .bak if a
	// crash happened between renames, so prefer it as the second recovery source.
	for _, candidate := range []string{path, path + ".tmp", path + ".bak"} {
		loaded, err := readJSONMap(candidate)
		if err == nil && len(loaded) > 0 {
			m = loaded
			firstErr = nil
			break
		}
		if err != nil && firstErr == nil {
			firstErr = err
		}
	}
	if m == nil {
		if firstErr != nil {
			return defaultState(), firstErr
		}
		m = map[string]json.RawMessage{}
	}
	s := defaultState()
	persistedDefaultsVersion := currentDefaultsVersion
	if len(m) > 0 {
		persistedDefaultsVersion = 0
	}
	// Native format if present.
	if raw := m["redplay.native.state.v1"]; len(raw) > 0 {
		var meta struct {
			DefaultsVersion int `json:"defaultsVersion"`
		}
		_ = json.Unmarshal(raw, &meta)
		persistedDefaultsVersion = meta.DefaultsVersion
		_ = json.Unmarshal(raw, &s)
	}
	// Migrate/merge the browser-era persistent keys to avoid losing playlists.
	if raw := m["redplay.providers.v1"]; len(raw) > 0 {
		var v []Provider
		if json.Unmarshal(raw, &v) == nil && len(v) > 0 {
			s.Providers = v
		}
	}
	if raw := m["redplay.favorites.v1"]; len(raw) > 0 {
		var v []string
		if json.Unmarshal(raw, &v) == nil {
			s.Favorites = v
		}
	}
	if raw := m["redplay.lastProvider.v1"]; len(raw) > 0 {
		var v string
		if json.Unmarshal(raw, &v) == nil {
			s.LastProvider = v
		}
	}
	if raw := m["redplay.settings.v1"]; len(raw) > 0 {
		var v Settings
		if json.Unmarshal(raw, &v) == nil {
			if v.Volume > 0 {
				s.Settings.Volume = v.Volume
			}
			if v.PreferredAudio != "" {
				s.Settings.PreferredAudio = v.PreferredAudio
			}
			if v.PreferredSubtitle != "" {
				s.Settings.PreferredSubtitle = v.PreferredSubtitle
			}
			if v.SubtitleSize > 0 {
				s.Settings.SubtitleSize = v.SubtitleSize
			}
			s.Settings.AutoSubtitles = v.AutoSubtitles
			s.Settings.AutoLastProvider = v.AutoLastProvider
		}
	}
	if persistedDefaultsVersion < currentDefaultsVersion {
		mergeBuiltInProviders(&s)
	}
	s.DefaultsVersion = currentDefaultsVersion
	if s.Settings.Volume < 0 || s.Settings.Volume > 100 {
		s.Settings.Volume = 80
	}
	if s.Settings.PreferredAudio == "" {
		s.Settings.PreferredAudio = "bg-en"
	}
	if s.Settings.PreferredSubtitle == "" {
		s.Settings.PreferredSubtitle = "bg"
	}
	s.Settings.SubtitleSize = normalizeSubtitleSize(s.Settings.SubtitleSize)
	return s, nil
}

func writeSynced(path string, b []byte) error {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0644)
	if e != nil {
		return e
	}
	_, e = f.Write(b)
	if e == nil {
		e = f.Sync()
	}
	ce := f.Close()
	if e != nil {
		return e
	}
	return ce
}

func saveStateLocked(s AppState) error {
	path := statePath()
	m, _ := readJSONMap(path)
	if m == nil {
		m = map[string]json.RawMessage{}
	}
	put := func(k string, v any) error {
		b, e := json.Marshal(v)
		if e != nil {
			return e
		}
		m[k] = b
		return nil
	}
	if e := put("redplay.native.state.v1", s); e != nil {
		return e
	}
	_ = put("redplay.providers.v1", s.Providers)
	_ = put("redplay.favorites.v1", s.Favorites)
	_ = put("redplay.lastProvider.v1", s.LastProvider)
	_ = put("redplay.settings.v1", s.Settings)
	b, e := json.MarshalIndent(m, "", "  ")
	if e != nil {
		return e
	}
	tmp := path + ".tmp"
	bak := path + ".bak"
	_ = os.Remove(tmp)
	if e = writeSynced(tmp, b); e != nil {
		return e
	}
	_ = os.Remove(bak)
	hadOld := false
	if _, e = os.Stat(path); e == nil {
		hadOld = true
		if e = os.Rename(path, bak); e != nil {
			_ = os.Remove(tmp)
			return e
		}
	}
	if e = os.Rename(tmp, path); e != nil {
		if hadOld {
			_ = os.Rename(bak, path)
		}
		_ = os.Remove(tmp)
		return e
	}
	return nil
}

func SaveState(s AppState) error {
	stateMu.Lock()
	defer stateMu.Unlock()
	return saveStateLocked(s)
}

// TrySaveState is reserved for shutdown paths. It never waits behind another
// persistence operation, which keeps WM_CLOSE from stalling on disk I/O contention.
func TrySaveState(s AppState) error {
	if !stateMu.TryLock() {
		return nil
	}
	defer stateMu.Unlock()
	return saveStateLocked(s)
}

func ValidateState(s AppState) error {
	for _, p := range s.Providers {
		if p.ID == "" || p.Name == "" || p.URL == "" {
			return errors.New("provider has missing id/name/url")
		}
	}
	return nil
}

// cloneAppState creates an immutable snapshot that can safely be persisted
// from a background goroutine while the UI continues to mutate its live state.
func cloneAppState(s AppState) AppState {
	out := s
	out.Providers = make([]Provider, len(s.Providers))
	for i, p := range s.Providers {
		out.Providers[i] = p
		if p.Headers != nil {
			out.Providers[i].Headers = make(map[string]string, len(p.Headers))
			for k, v := range p.Headers {
				out.Providers[i].Headers[k] = v
			}
		}
	}
	out.Favorites = append([]string(nil), s.Favorites...)
	return out
}
