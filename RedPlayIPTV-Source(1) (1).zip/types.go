package main

import "time"

type Provider struct {
	ID        string            `json:"id"`
	Name      string            `json:"name"`
	URL       string            `json:"url"`
	EPGURL    string            `json:"epgUrl,omitempty"`
	Headers   map[string]string `json:"headers,omitempty"`
	CreatedAt int64             `json:"createdAt,omitempty"`
}

type Channel struct {
	ID       string            `json:"id"`
	Name     string            `json:"name"`
	TVGID    string            `json:"tvgId,omitempty"`
	TVGName  string            `json:"tvgName,omitempty"`
	Logo     string            `json:"logo,omitempty"`
	Group    string            `json:"group,omitempty"`
	Language string            `json:"language,omitempty"`
	URL      string            `json:"url"`
	Headers  map[string]string `json:"headers,omitempty"`
}

type Playlist struct {
	Channels []Channel
	EPGURL   string
}

type Programme struct {
	ChannelID string    `json:"channel"`
	Start     time.Time `json:"start"`
	Stop      time.Time `json:"stop"`
	Title     string    `json:"title"`
	SubTitle  string    `json:"subTitle,omitempty"`
	Desc      string    `json:"desc,omitempty"`
	Category  string    `json:"category,omitempty"`
}

type EPGData struct {
	DisplayNames map[string][]string
	Programmes   map[string][]Programme
	NameToIDs    map[string][]string
}

type Settings struct {
	Volume            int    `json:"volume"`
	PreferredAudio    string `json:"preferredAudio"`
	PreferredSubtitle string `json:"preferredSubtitle"`
	SubtitleSize      int    `json:"subtitleSize"`
	AutoSubtitles     bool   `json:"autoSubtitles"`
	AutoLastProvider  bool   `json:"autoLastProvider"`
}

const (
	defaultSubtitleSize = 40
	minSubtitleSize     = 24
	maxSubtitleSize     = 60
	subtitleSizeStep    = 2
)

func normalizeSubtitleSize(v int) int {
	if v == 0 {
		return defaultSubtitleSize
	}
	if v < minSubtitleSize {
		return minSubtitleSize
	}
	if v > maxSubtitleSize {
		return maxSubtitleSize
	}
	return v
}

type AppState struct {
	Providers    []Provider `json:"providers"`
	Favorites    []string   `json:"favorites"`
	LastProvider string     `json:"lastProvider"`
	Settings     Settings   `json:"settings"`
}

func defaultSettings() Settings {
	return Settings{Volume: 80, PreferredAudio: "bg-en", PreferredSubtitle: "bg", SubtitleSize: defaultSubtitleSize, AutoSubtitles: true, AutoLastProvider: true}
}
